# Experimental only.
<#
.SYNOPSIS
Imports 1,000 prepared synthetic records directly or through PSU automation.
.PARAMETER Pass
Evidence pass containing import-fixture.json.
.PARAMETER Method
Prepared per-row commands or a single JSONB recordset statement. Both commit once.
.NOTES
Fixture decoding and batch JSON preparation precede DatabaseMs, and are included
in ScriptMs and the external client clock. Resets only the dedicated batch table.
#>
param(
    [Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]{1,24}$')][string] $Pass,
    [ValidateSet('rows','rows-set')][string] $Method = 'rows-set'
)
$scriptDuration = Measure-Command {
    . "$PSScriptRoot/Postgres.ps1"
    $output = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
    $fixture = @(Get-Content "$output/import-fixture.json" -Raw | ConvertFrom-Json)
    $json = ConvertTo-Json -InputObject @($fixture.Record) -Depth 5 -Compress
    $connection = Open-PostgresDatabase (Get-PostgresDatabaseName $Pass n10000-p256) -Pooling
    try {
        $null = Invoke-PostgresSql $connection 'TRUNCATE batch_records'
        $databaseDuration = Measure-Command { $result = Write-PostgresBatch $connection $fixture $Method batch_records -BatchJson $json }
    } finally { $connection.Dispose() }
}
[pscustomobject]@{ Affected=$result.Affected; DatabaseMs=$databaseDuration.TotalMilliseconds; ScriptMs=$scriptDuration.TotalMilliseconds; Method=$Method; PowerShell="$($PSVersionTable.PSVersion)" } | ConvertTo-Json -Compress
