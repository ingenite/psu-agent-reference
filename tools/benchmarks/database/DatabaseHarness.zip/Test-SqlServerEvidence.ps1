# Experimental only.
<#
.SYNOPSIS
Checks completeness and successful assertions in a retained SQL Server pass.
.PARAMETER Pass
Completed seven-repetition pass with direct, followup, concurrency and operations.
.NOTES
Checks saved evidence independently of the temporary database installation.
Does not rerun SQL or certify production durability. Fails on missing, duplicate,
failed or nonpositive measurements and missing preview restoration.
#>
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]{1,24}$')][string] $Pass)
$ErrorActionPreference = 'Stop'
$root = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
$specifications = @(
    @{ File='direct/reads.jsonl'; Count=600; Keys=@('Shape','Case','Mode','Block'); Time='ClientMs' },
    @{ File='direct/writes.jsonl'; Count=192; Keys=@('Shape','Case','Block'); Time='ClientMs' },
    @{ File='followup/endpoints.jsonl'; Count=168; Keys=@('Shape','Case','Block'); Time='ClientMs' },
    @{ File='followup/imports.jsonl'; Count=32; Keys=@('Location','Method','Block'); Time='ClientMs' },
    @{ File='concurrency/bursts.jsonl'; Count=20; Keys=@('Readers','Writers','Block'); Time='WallMs' }
)
$results = @(foreach ($specification in $specifications) {
    $samples = @(Get-Content "$root/$($specification.File)" | ConvertFrom-Json)
    if ($samples.Count -ne $specification.Count) { throw "Wrong count: $($specification.File)" }
    if (@($samples | Where-Object { !$_.Correct -or $_.($specification.Time) -le 0 }).Count) { throw 'Failed or invalid sample' }
    $groups = @($samples | Group-Object -Property $specification.Keys)
    if (@($groups | Where-Object Count -ne 1).Count) { throw 'Duplicate sample identity' }
    $caseKeys = @($specification.Keys | Where-Object { $_ -ne 'Block' })
    foreach ($group in ($samples | Group-Object -Property $caseKeys)) {
        $blocks = @($group.Group.Block | Sort-Object)
        $expectedLast = if ($specification.File -like 'concurrency/*') { 3 } else { 7 }
        if (($blocks -join ',') -ne ((0..$expectedLast) -join ',')) { throw 'Incomplete measured blocks' }
        if (@($group.Group | Where-Object { $_.Warmup -ne ($_.Block -eq 0) }).Count) { throw 'Incorrect warm-up flag' }
    }
    [pscustomobject]@{ File=$specification.File; Samples=$samples.Count; Measured=@($samples | Where-Object { !$_.Warmup }).Count; Correct=$true }
})
$bursts = @(Get-Content "$root/concurrency/bursts.jsonl" | ConvertFrom-Json)
$operations = 0
foreach ($burst in $bursts) {
    $workers = @(Get-Content "$root/concurrency/$($burst.WorkersFile)" -Raw | ConvertFrom-Json)
    if ($workers.Count -ne ($burst.Readers+$burst.Writers) -or $burst.Iterations -ne 200 -or $burst.AllWorkersOverlapMs -le 0) { throw 'Invalid concurrency shape/overlap' }
    foreach ($worker in $workers) {
        if ($worker.Samples.Count -ne 200 -or @($worker.Samples | Where-Object { $_.Error -or $_.TotalMs -le 0 }).Count) { throw 'Failed worker sample' }
        $rows = if ($worker.Role -eq 'writer') { 10 } else { 20 }
        if (@($worker.Samples | Where-Object Rows -ne $rows).Count) { throw 'Wrong useful result count' }
        $operations += $worker.Samples.Count
    }
}
if ($operations -ne 11200) { throw 'Wrong complete concurrency operation count' }
$checks = Get-Content "$root/operations/checks.json" -Raw | ConvertFrom-Json
foreach ($name in 'Rollback','RowLocks','ReadCommitted','RepeatableRead','Integrity','BackupRestore','Reopen') {
    if (!$checks.$name.Correct) { throw "Missing or failed operational check: $name" }
}
foreach ($property in $checks.PSObject.Properties) {
    if (!$property.Value.Correct) { throw "Operational check failed: $($property.Name)" }
}
if (!(Test-Path "$root/preview-backup/restored.txt")) { throw 'Preview restoration missing' }
foreach ($file in 'endpoints.ps1','scripts.ps1') {
    if ((Get-FileHash "$root/preview-backup/$file").Hash -ne (Get-FileHash "C:/dev-psu/Repository/.universal/$file").Hash) { throw "Preview differs: $file" }
}
if (Test-Path C:/dev-psu/sqlserver-benchmark-password.txt) { throw 'Temporary demonstration password file remains' }
if (Test-Path C:/dev-psu/sqlserver-benchmark-login.txt) { throw 'Temporary demonstration login file remains' }
$required = 'server-before.json','host.json','metadata.json','operations/backup.bak','followup/metadata.json'
foreach ($file in $required) { if (!(Test-Path "$root/$file")) { throw "Missing evidence: $file" } }
$retainedChecks=@()
if (Test-Path "$root/retained") {
    foreach ($shape in 'n1000-p256','n10000-p256','n10000-p2048') {
        $retained=Get-Content "$root/retained/$shape-checks-schema.json" -Raw | ConvertFrom-Json
        if (!$retained.Correct -or !$retained.BackupVerified -or $retained.CheckdbDiagnosticRows -ne 0 -or !(Test-Path "$root/retained/$shape.bak")) { throw 'Incomplete retained database checks' }
        $retainedChecks+=[pscustomobject]@{Shape=$shape;RowsChecked=$retained.RowsChecked;DocumentsChecked=$retained.DocumentsChecked;Correct=$true}
    }
}
$metadata=Get-Content "$root/metadata.json" -Raw | ConvertFrom-Json
if ($metadata.Protocol -eq 'review-corrected-v2') {
    foreach ($burst in $bursts) {
        $directory = Split-Path "$root/concurrency/$($burst.WorkersFile)"
        $reset = Get-Content "$directory/warmup-reset.json" -Raw | ConvertFrom-Json
        if (!$reset.Correct -or !$reset.AllWorkersReady -or !$reset.RoleSpecific -or $reset.OperationsPerWorker -ne 10 -or $reset.BeforeReset -ne (100*$burst.Writers) -or $reset.AfterReset -ne 0) { throw 'Invalid role-specific warm-up/reset evidence' }
        foreach ($worker in @(Get-Content "$root/concurrency/$($burst.WorkersFile)" -Raw | ConvertFrom-Json)) {
            if ($worker.WarmupOperations -ne 10 -or $worker.WarmupRole -ne $worker.Role) { throw 'Missing worker warm-up evidence' }
        }
    }
    $paired = @(Get-Content "$root/direct/reads.jsonl" | ConvertFrom-Json | Where-Object { $_.Mode -eq 'reuse' -and $_.Case -in 'document-filter-index','document-filter-scan' })
    if ($paired.Count -ne 48) { throw 'Missing paired index observations' }
    foreach ($pair in $paired | Group-Object Shape,Block) {
        if ($pair.Count -ne 2 -or @($pair.Group.Case | Sort-Object -Unique).Count -ne 2 -or @($pair.Group.PairPosition | Sort-Object -Unique).Count -ne 2 -or @($pair.Group | Where-Object ConditionWarmups -ne 10).Count) { throw 'Invalid index pair' }
        $expectedOrder = if ($pair.Group[0].Block % 2) { 'scan,indexed' } else { 'indexed,scan' }
        if (@($pair.Group | Where-Object PairOrder -ne $expectedOrder).Count) { throw 'Incorrect counterbalanced index order' }
    }
}
if ($metadata.Authentication -eq 'Sql') {
    $directIdentity=Get-Content "$root/benchmark-identity.json" -Raw | ConvertFrom-Json
    $endpointIdentity=Get-Content "$root/followup/endpoint-identity.json" -Raw | ConvertFrom-Json
    $jobIdentity=Get-Content "$root/followup/job-identity.json" -Raw | ConvertFrom-Json
    foreach ($identity in @($directIdentity,$endpointIdentity,$jobIdentity)) {
        $expectedLogin = if ($metadata.BenchmarkLogin) { $metadata.BenchmarkLogin } else { 'par_benchmark_sql' }
        if ($identity.authentication -ne 'SQL' -or $identity.sysadmin -ne 0 -or $identity.login_name -ne $expectedLogin) { throw 'SQL benchmark identity mismatch' }
    }
}
$result = @{ Pass=$Pass; Correct=$true; Files=$results; ConcurrentOperationsIncludingWarmups=$operations; OperationalChecks=@($checks.PSObject.Properties).Count; PreviewRestored=$true; CredentialFilesCreated=($metadata.Authentication -eq 'Sql'); TemporaryCredentialRemoved=$true; RetainedDatabases=$retainedChecks }
$result | ConvertTo-Json -Depth 8 | Set-Content "$root/validation.json"
Write-Output "SQL Server evidence complete and checked: $root/validation.json"


