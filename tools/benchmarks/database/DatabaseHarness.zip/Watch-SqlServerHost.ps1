# Experimental only.
<#
.SYNOPSIS
Samples host counters and SQL Server/PowerShell/PSU processes once per second.
.PARAMETER OutputDirectory
Existing evidence directory. Sampling ends when monitor-stop.txt exists.
.NOTES
CPU is cumulative; shared working sets may be counted repeatedly. These samples
cannot attribute individual short operations to a resource bottleneck.
#>
param([Parameter(Mandatory)][string] $OutputDirectory)
$ErrorActionPreference = 'Stop'
Set-Content "$OutputDirectory/monitor-ready.txt" $PID
while (!(Test-Path "$OutputDirectory/monitor-stop.txt")) {
    $counters = Get-Counter '\Processor(_Total)\% Processor Time','\Memory\Available MBytes','\PhysicalDisk(_Total)\Avg. Disk sec/Transfer'
    @{
        Utc = (Get-Date).ToUniversalTime().ToString('o')
        Counters = @($counters.CounterSamples | Select-Object Path,CookedValue)
        Processes = @(Get-Process pwsh,Universal.Server,sqlservr -ErrorAction SilentlyContinue | Select-Object Id,ProcessName,CPU,WorkingSet64,PrivateMemorySize64)
    } | ConvertTo-Json -Depth 5 -Compress | Add-Content "$OutputDirectory/monitoring.jsonl"
}


