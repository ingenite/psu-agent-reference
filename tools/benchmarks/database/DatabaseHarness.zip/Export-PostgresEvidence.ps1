# Experimental only.
<#
.SYNOPSIS
Summarizes retained PostgreSQL evidence without a database dependency.
.PARAMETER Pass
Completed pass; Test-PostgresEvidence must have succeeded first.
.PARAMETER Replace
Allows overwriting a PostgresEvidence.json that holds a different pass.
.PARAMETER SkipPortable
Writes only the pass's summary.json and leaves PostgresEvidence.json unchanged.
.NOTES
Replaces summary.json and the portable PostgresEvidence.json only. A portable
file from another pass is kept unless Replace is set. Warm-ups are
excluded. P95 is nearest rank. Burst wall intervals count once. Raw per-request
samples, query plans, monitoring and historical sources remain in tools/output.
#>
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]{1,24}$')][string] $Pass, [switch] $Replace, [switch] $SkipPortable)
$ErrorActionPreference = 'Stop'
function Get-Distribution {
    param([double[]] $Values)
    $sorted = @($Values | Sort-Object)
    if (!$sorted.Count) { throw 'No distribution observations' }
    $middle = [int]($sorted.Count / 2)
    $median = if ($sorted.Count % 2) { $sorted[[int](($sorted.Count-1)/2)] } else { ($sorted[$middle-1]+$sorted[$middle])/2 }
    $rank = 1
    while ($rank -lt (0.95*$sorted.Count)) { $rank++ }
    [pscustomobject]@{ N=$sorted.Count; Min=$sorted[0]; Median=$median; P95=$sorted[$rank-1]; Max=$sorted[-1] }
}
$root = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
$validation = Get-Content "$root/validation.json" -Raw | ConvertFrom-Json
if (!$validation.Correct) { throw 'Evidence validation required' }
$reads = @(Get-Content "$root/direct/reads.jsonl" | ConvertFrom-Json | Where-Object { !$_.Warmup })
$writes = @(Get-Content "$root/direct/writes.jsonl" | ConvertFrom-Json | Where-Object { !$_.Warmup })
$endpoints = @(Get-Content "$root/followup/endpoints.jsonl" | ConvertFrom-Json | Where-Object { !$_.Warmup })
$imports = @(Get-Content "$root/followup/imports.jsonl" | ConvertFrom-Json | Where-Object { !$_.Warmup })
$bursts = @(Get-Content "$root/concurrency/bursts.jsonl" | ConvertFrom-Json | Where-Object { !$_.Warmup })
$psu = Get-Content "$root/followup/metadata.json" -Raw | ConvertFrom-Json
$summary = [ordered]@{
    Pass=$Pass; MeasuredUtc=(Get-Date).ToUniversalTime().ToString('o')
    Status='SQLite and PostgreSQL measured locally; SQL Server unmeasured. Experimental only.'
    Units='milliseconds except counts, bytes and operations/second'
    Statistics='Warm-ups excluded. Median, observed range and nearest-rank P95. Burst requests are correlated; one wall interval per burst.'
    Fixture=@{ Seed=1108; Shapes=@('1000 records / 256 ASCII characters','10000 records / 256 ASCII characters','10000 records / 2048 ASCII characters'); Generator='DatabaseFixture.ps1, identical arithmetic fields/JSON to SQLite'; MeasuredBlocks=7; WarmupsPerSequentialCase=1; MeasuredBurstBlocks=3; OperationsPerWorker=200 }
    Boundaries=@{ Direct='Native Measure-Command around helper call/return, SQL, object construction and owned-connection disposal; serialization and checks follow clock'; Endpoint='HTTP response plus JSON-to-object parsing; pooled database connection in handler'; Import='Whole script locally, or submit + 50ms completion polling + pipeline retrieval; fixture decoding and batch JSON preparation included'; Burst='One earliest-worker-start to latest-worker-end wall interval, including between-operation driver work' }
    Host=Get-Content "$root/host.json" -Raw | ConvertFrom-Json
    Server=Get-Content "$root/server-before.json" -Raw | ConvertFrom-Json
    Metadata=Get-Content "$root/metadata.json" -Raw | ConvertFrom-Json
    Psu=@{ Utc=$psu.Utc; Version=$psu.Version; Settings=$psu.Settings; Environments=@($psu.Environments | Select-Object name,version,maxRunspaces,persistentRunspace); PreviewHashes=$psu.PreviewHashes }
    Validation=$validation
    Evidence=@{ Root="tools/output/database/$Pass"; Archive="tools/output/database/$Pass-evidence.zip"; Manifest='manifest.json SHA256 per file'; Sources='direct/source, followup/source, concurrency/source, operations/source, retained/source'; Exclusions=@('postgres-smoke','followup-initial','preview-backup-initial'); Preservation='Three measured database custom dumps and SQL schemas; operational dump restored and field-checked; archive is independent of installed server' }
    Reads=@($reads | Group-Object Shape,Case,Mode | ForEach-Object {
        $first=$_.Group[0]
        [pscustomobject]@{ Shape=$first.Shape; Case=$first.Case; Mode=$first.Mode; ClientMs=Get-Distribution $_.Group.ClientMs; Rows=$first.Rows; JsonCharacters=$first.JsonCharacters }
    })
    Writes=@($writes | Group-Object Shape,Case | ForEach-Object {
        $first=$_.Group[0]
        [pscustomobject]@{ Shape=$first.Shape; Case=$first.Case; ClientMs=Get-Distribution $_.Group.ClientMs; Rows=$first.Rows }
    })
    Endpoints=@($endpoints | Group-Object Shape,Case | ForEach-Object {
        $first=$_.Group[0]
        [pscustomobject]@{ Shape=$first.Shape; Case=$first.Case; ClientMs=Get-Distribution $_.Group.ClientMs; HttpMs=Get-Distribution $_.Group.HttpMs; ParseMs=Get-Distribution $_.Group.ParseMs; HandlerMs=Get-Distribution $_.Group.HandlerMs; ResponseBytes=Get-Distribution $_.Group.Bytes; PowerShell=$first.PowerShell }
    })
    Imports=@($imports | Group-Object Location,Method | ForEach-Object {
        $first=$_.Group[0]
        [pscustomobject]@{ Location=$first.Location; Method=$first.Method; ClientMs=Get-Distribution $_.Group.ClientMs; DatabaseMs=Get-Distribution $_.Group.Result.DatabaseMs; ScriptMs=Get-Distribution $_.Group.Result.ScriptMs; Rows=1000 }
    })
    Bursts=@($bursts | Group-Object Readers,Writers | ForEach-Object {
        $first=$_.Group[0]
        $workers=@($_.Group | ForEach-Object { Get-Content "$root/concurrency/$($_.WorkersFile)" -Raw | ConvertFrom-Json })
        [pscustomobject]@{ Readers=$first.Readers; Writers=$first.Writers; Bursts=$_.Count; OperationsPerBurst=$first.Operations; WallMs=Get-Distribution $_.Group.WallMs; AllWorkersOverlapMs=Get-Distribution $_.Group.AllWorkersOverlapMs
            OperationsPerSecond=Get-Distribution @($_.Group | ForEach-Object { 1000*$_.Operations/$_.WallMs })
            Roles=@($workers | Group-Object Role | ForEach-Object { [pscustomobject]@{ Role=$_.Name; ClientMs=Get-Distribution $_.Group.Samples.TotalMs; Errors=@($_.Group.Samples | Where-Object Error).Count } }) }
    })
    Operations=Get-Content "$root/operations/checks.json" -Raw | ConvertFrom-Json
    Storage=@(Get-ChildItem "$root/direct/*-conditions.json" | ForEach-Object { $condition=Get-Content $_ -Raw | ConvertFrom-Json; [pscustomobject]@{ Shape=$condition.Shape; Relations=$condition.Storage } })
    Monitoring=@(foreach ($phase in 'direct','followup','concurrency') {
        $samples=@(Get-Content "$root/$phase/monitoring.jsonl" | ConvertFrom-Json)
        [pscustomobject]@{ Phase=$phase; Samples=$samples.Count; FirstUtc=$samples[0].Utc; LastUtc=$samples[-1].Utc
            Counters=@($samples.Counters | Group-Object Path | ForEach-Object { [pscustomobject]@{ Path=$_.Name; Values=Get-Distribution $_.Group.CookedValue } })
            Processes=@($samples.Processes | Group-Object Id | ForEach-Object { [pscustomobject]@{ Id=$_.Group[0].Id; Name=$_.Group[0].ProcessName; CpuSecondsObserved=$_.Group[-1].CPU-$_.Group[0].CPU; PeakPrivateBytes=($_.Group.PrivateMemorySize64 | Measure-Object -Maximum).Maximum; PeakWorkingSetBytes=($_.Group.WorkingSet64 | Measure-Object -Maximum).Maximum } }) }
    })
    Limitations=@(
        'Same workstation/storage but later, unpaired provider passes; no universal ranking or isolated engine timings.',
        'Warm synthetic tables of at most 10,000 records; ASCII x payloads compress unusually well with PostgreSQL TOAST. No production size or capacity estimate.',
        'PostgreSQL JSONB normalization differs from SQLite JSON text. Expression B-tree indexes, not GIN; scan phase removes only the expression index and runs separately.',
        'Direct outer clocks use native Measure-Command; SQLite used an explicit Stopwatch. Serialization is outside direct read clocks. No measured subtraction of harness overhead.',
        'PostgreSQL defaults include 128 MiB shared buffers plus OS cache and per-operation memory; SQLite used 8 MiB private cache per connection. Memory budgets were not equalized.',
        'Pooled PostgreSQL endpoints differ from unpooled SQLite endpoints. PG direct new/reuse/pooled modes expose the connection choice.',
        'Per-row writes prepare once and send one request per row; set variants send one request using JSONB recordsets or an integer key array. Batch JSON is prebuilt for database clocks, inside whole-import clocks.',
        'No PostgreSQL endpoint concurrency, cold-cache, remote-host, sustained-capacity, frontend, crash/power-loss, PITR, HA, production-identity or SQL Server tests.',
        'One-second resource samples cannot attribute individual requests; working sets can double-count shared memory. Agent/tool activity was not isolated or controlled during PostgreSQL passes.',
        'Initial incomplete followup and smoke passes are excluded; historical source snapshots retain the pre-import integer-conversion fix for direct measurements.'
    )
}
if (Test-Path "$root/psu-condition.json") { $summary.PsuCondition=Get-Content "$root/psu-condition.json" -Raw | ConvertFrom-Json }
$summary | ConvertTo-Json -Depth 35 | Set-Content "$root/summary.json"
if ($SkipPortable) {
    Write-Output "PostgreSQL summary only: $root/summary.json"
    return
}
if (!$Replace -and (Test-Path "$PSScriptRoot/PostgresEvidence.json")) {
    $existingPass = (Get-Content "$PSScriptRoot/PostgresEvidence.json" -Raw | ConvertFrom-Json).Pass
    if ($existingPass -ne $Pass) { throw "PostgresEvidence.json holds pass $existingPass; use -Replace to overwrite it" }
}
Copy-Item "$root/summary.json" "$PSScriptRoot/PostgresEvidence.json" -Force
Write-Output "Portable PostgreSQL evidence: $PSScriptRoot/PostgresEvidence.json"
