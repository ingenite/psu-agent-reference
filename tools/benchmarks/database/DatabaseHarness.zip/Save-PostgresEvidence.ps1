# Experimental only.
<#
.SYNOPSIS
Retains measured PostgreSQL databases, schema, final sources and a hashed evidence archive.
.PARAMETER Pass
Completed pass. Creates retained/ and a sibling evidence ZIP once.
.PARAMETER Bin
Native PostgreSQL tools directory.
.PARAMETER SkipPortable
Keeps the pass summary but leaves the committed PostgresEvidence.json unchanged.
.NOTES
Requires PGPASSWORD, native pg_dump/pg_restore, Windows diagnostics and the dev-psu
API token. Saves no password or token. Does not uninstall PostgreSQL. The archive
and portable summary survive uninstalling the temporary server. No database is
modified. Run Test-PostgresEvidence and Export-PostgresEvidence again after this
command only if code or evidence changes; repackage deliberately in a new file.
#>
param(
    [Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]{1,24}$')][string] $Pass,
    [string] $Bin = 'C:/Program Files/PostgreSQL/18/bin',
    [switch] $SkipPortable
)
. "$PSScriptRoot/Postgres.ps1"
$root = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
$output = "$root/retained"
$archive = "$root-evidence.zip"
if ((Test-Path $output) -or (Test-Path $archive)) { throw 'Retained package already exists' }
New-Item "$output/source" -ItemType Directory -Force | Out-Null
Copy-Item "$PSScriptRoot/*Postgres*.ps1","$PSScriptRoot/DatabaseFixture.ps1" "$output/source"
Copy-Item "$PSScriptRoot/../DatabaseProviders.md" "$output"
@{
    PgDump = & "$Bin/pg_dump.exe" --version
    PgRestore = & "$Bin/pg_restore.exe" --version
    PgAmcheck = & "$Bin/pg_amcheck.exe" --version
    Provider = Get-Item C:/dev-psu/Npgsql.dll,C:/dev-psu/Microsoft.Extensions.Logging.Abstractions.dll | Select-Object Name,@{Name='Version';Expression={$_.VersionInfo.FileVersion}}
    ProviderHashes = @(Get-FileHash C:/dev-psu/Npgsql.dll,C:/dev-psu/Microsoft.Extensions.Logging.Abstractions.dll | Select-Object Path,Hash)
    DataPaths = @(Get-Item 'C:/Program Files/PostgreSQL/18/data','C:/Program Files/PostgreSQL/18/data/pg_wal' | Select-Object FullName,LinkType,Target)
    PostgreSQLProcesses = @(Get-Process postgres -ErrorAction SilentlyContinue | Select-Object Id,CPU,PrivateMemorySize64,WorkingSet64)
} | ConvertTo-Json -Depth 8 | Set-Content "$output/final-conditions.json"
foreach ($shape in 'n1000-p256','n10000-p256','n10000-p2048') {
    $database = Get-PostgresDatabaseName $Pass $shape
    & "$Bin/pg_dump.exe" -w -h 127.0.0.1 -p 5432 -U par_benchmark -d $database -F c -f "$output/$shape.dump" 2> "$output/$shape-dump.log"
    if ($LASTEXITCODE) { throw 'Measured database dump failed' }
    & "$Bin/pg_dump.exe" -w -h 127.0.0.1 -p 5432 -U par_benchmark -d $database --schema-only --no-owner --no-privileges -f "$output/$shape-schema.sql" 2> "$output/$shape-schema.log"
    if ($LASTEXITCODE) { throw 'Schema dump failed' }
    & "$Bin/pg_restore.exe" --list "$output/$shape.dump" > "$output/$shape-contents.txt"
    if ($LASTEXITCODE) { throw 'Dump listing failed' }
}
$configuration = Get-Content C:/dev-psu/appsettings.json -Raw | ConvertFrom-Json
$token = Get-Secret -Name dev-psu-codex-mgmt-api -AsPlainText
$headers = @{ Authorization="Bearer $token" }
$settings = @(Invoke-RestMethod http://127.0.0.1:5100/api/v1/settings -Headers $headers -MaximumRedirection 0)[0]
$environments = Invoke-RestMethod http://127.0.0.1:5100/api/v1/environment -Headers $headers -MaximumRedirection 0
@{
    SystemLogLevel=$configuration.SystemLogLevel; ApiSecurity=$configuration.Api.SecurityModel
    HangfireWorkerCount=$configuration.HangfireWorkerCount
    Settings=$settings | Select-Object concurrentJobLimit,maxJobMemory,scriptBaseFolder,gitSyncEnabled
    Environments=@($environments | Select-Object name,version,maxRunspaces,persistentRunspace)
    Runtime=@{
        Harness=(Get-Content "$PSHOME/pwsh.runtimeconfig.json" -Raw | ConvertFrom-Json).runtimeOptions
        PsuServer=(Get-Content C:/dev-psu/Universal.Server.runtimeconfig.json -Raw | ConvertFrom-Json).runtimeOptions
        PsuJob=(Get-Content C:/dev-psu/pwsh.runtimeconfig.json -Raw | ConvertFrom-Json).runtimeOptions
    }
} | ConvertTo-Json -Depth 12 | Set-Content "$root/psu-condition.json"
& "$PSScriptRoot/Test-PostgresEvidence.ps1" -Pass $Pass
& "$PSScriptRoot/Export-PostgresEvidence.ps1" -Pass $Pass -SkipPortable:$SkipPortable
Copy-Item "$root/summary.json" "$output/summary.json"
$resolved = (Resolve-Path $root).Path
Get-ChildItem $root -File -Recurse | Sort-Object FullName | ForEach-Object {
    [pscustomobject]@{ File=$_.FullName.Substring($resolved.Length+1).Replace('\','/'); Bytes=$_.Length; Sha256=(Get-FileHash $_.FullName).Hash }
} | ConvertTo-Json -Depth 5 | Set-Content "$root/manifest.json"
Compress-Archive -LiteralPath $root -DestinationPath $archive -CompressionLevel Optimal
Get-FileHash $archive | Select-Object Path,Hash | ConvertTo-Json | Set-Content "$archive.sha256.json"
Write-Output "Retained PostgreSQL evidence: $archive"
