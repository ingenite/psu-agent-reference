# Experimental only; use on the dedicated dev-psu instance.
<#
.SYNOPSIS
Returns a constrained synthetic SQL Server read from an authenticated endpoint.
.PARAMETER RequestJson
Object containing Pass, Shape and Case. No connection string or SQL is accepted.
.NOTES
Uses explicit TCP loopback and pooled connections. SQL mode reads the temporary
demonstration credential file; Windows mode uses the PSU process identity.
#>
param([Parameter(Mandatory)][string] $RequestJson)
$duration = Measure-Command {
    . "$PSScriptRoot/SqlServer.ps1"
    $request = $RequestJson | ConvertFrom-Json
    $database = Get-SqlServerDatabaseName $request.Pass $request.Shape
    if ($request.Case -notin 'identity','row-key','document-key','row-filter','document-filter-index','row-seek','row-projection','document-projection') { throw 'Invalid benchmark case' }
    $count = if ($request.Shape -eq 'n1000-p256') { 1000 } else { 10000 }
    if ($request.Case -eq 'identity') {
        $connection=Open-SqlServerDatabase $database -Pooling
        try { $result=[pscustomobject]@{ Records=@(Invoke-SqlServerSql $connection "SELECT ORIGINAL_LOGIN() AS login_name,IS_SRVROLEMEMBER('sysadmin') AS sysadmin,IS_MEMBER('db_owner') AS db_owner,CONNECTIONPROPERTY('auth_scheme') AS authentication,CONNECTIONPROPERTY('net_transport') AS transport"); Engine=$connection.ServerVersion } } finally { $connection.Dispose() }
    } else { $result = Read-SqlServerRecord -Database $database -Case $request.Case -Count $count -Pooling }
}
[pscustomobject]@{ Result=$result; HandlerMs=$duration.TotalMilliseconds; PowerShell="$($PSVersionTable.PSVersion)"; Engine=$result.Engine }

