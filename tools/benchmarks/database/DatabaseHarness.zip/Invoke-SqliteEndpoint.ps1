# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Runs a constrained synthetic database operation for the authenticated development endpoint.
.PARAMETER RequestJson
JSON object containing Pass, Shape and Case. Only existing benchmark files are opened.
.NOTES
Use only on the dedicated dev-psu instance. This is not a production API contract.
#>
param([Parameter(Mandatory)][string] $RequestJson)
# Owner approved .NET Stopwatch and SQLite APIs for this SQLite experiment.
$handlerTimer = [System.Diagnostics.Stopwatch]::StartNew()
. "$PSScriptRoot/Sqlite.ps1"
$request = $RequestJson | ConvertFrom-Json
if ($request.Pass -notmatch '^[a-zA-Z0-9-]+$' -or $request.Shape -notin 'n1000-p256','n10000-p256','n10000-p2048') { throw 'Invalid benchmark database' }
if ($request.Case -notin 'row-key','document-key','row-filter','document-filter-index','row-seek','increment','row-projection','document-projection') { throw 'Invalid benchmark case' }
$database = "C:/repos/psu-agent-reference/tools/output/database/$($request.Pass)/$($request.Shape).db"
$count = if ($request.Shape -eq 'n1000-p256') { 1000 } else { 10000 }
if ($request.Case -eq 'increment') {
    $connection = Open-BenchmarkDatabase $database
    try { $result = Invoke-BenchmarkIncrement $connection } finally { $connection.Dispose() }
} else { $result = Read-BenchmarkRecord -Path $database -Case $request.Case -Count $count -SkipSerialization }
[pscustomobject]@{ Result = $result; HandlerMs = $handlerTimer.Elapsed.TotalMilliseconds; PowerShell = "$($PSVersionTable.PSVersion)"; Engine = $result.Engine }
