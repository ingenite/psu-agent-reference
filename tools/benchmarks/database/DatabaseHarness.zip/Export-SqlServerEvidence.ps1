# Experimental only.
<#
.SYNOPSIS
Summarizes retained SQL Server evidence without a database dependency.
.PARAMETER Pass
Completed pass; Test-SqlServerEvidence must have succeeded first.
.PARAMETER Replace
Allows overwriting a portable file that holds a different pass.
.PARAMETER SkipPortable
Writes only the pass's summary.json and leaves the portable files unchanged.
.NOTES
Replaces summary.json and the pass's portable evidence only. Corrected protocol
passes use SqlServerReviewedEvidence.json, preserving SqlServerEvidence.json.
A portable file from another pass is kept unless Replace is set. Warm-ups are
excluded. P95 is nearest rank. Burst wall intervals count once. Raw per-request
samples, query plans, monitoring and historical sources remain in tools/output.
#>
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]{1,24}$')][string] $Pass, [switch] $Replace, [switch] $SkipPortable)
$ErrorActionPreference = 'Stop'
function Get-Distribution {
    param([double[]] $Values)
    $sorted = @($Values | Sort-Object)
    if (!$sorted.Count) { throw 'No distribution observations' }
    $middle = [int]($sorted.Count / 2)
    $median = if ($sorted.Count % 2) { $sorted[[int](($sorted.Count-1)/2)] } else { ($sorted[$middle-1]+$sorted[$middle])/2 }
    $rank = 1
    while ($rank -lt (0.95*$sorted.Count)) { $rank++ }
    [pscustomobject]@{ N=$sorted.Count; Min=$sorted[0]; Median=$median; P95=$sorted[$rank-1]; Max=$sorted[-1] }
}
$root = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
$validation = Get-Content "$root/validation.json" -Raw | ConvertFrom-Json
if (!$validation.Correct) { throw 'Evidence validation required' }
$metadata = Get-Content "$root/metadata.json" -Raw | ConvertFrom-Json
$reads = @(Get-Content "$root/direct/reads.jsonl" | ConvertFrom-Json | Where-Object { !$_.Warmup })
$writes = @(Get-Content "$root/direct/writes.jsonl" | ConvertFrom-Json | Where-Object { !$_.Warmup })
$endpoints = @(Get-Content "$root/followup/endpoints.jsonl" | ConvertFrom-Json | Where-Object { !$_.Warmup })
$imports = @(Get-Content "$root/followup/imports.jsonl" | ConvertFrom-Json | Where-Object { !$_.Warmup })
$bursts = @(Get-Content "$root/concurrency/bursts.jsonl" | ConvertFrom-Json | Where-Object { !$_.Warmup })
$psu = Get-Content "$root/followup/metadata.json" -Raw | ConvertFrom-Json
$summary = [ordered]@{
    Pass=$Pass; MeasuredUtc=(Get-Date).ToUniversalTime().ToString('o')
    Status='SQLite, PostgreSQL and SQL Server measured locally. Experimental only.'
    Units='milliseconds except counts, bytes and operations/second'
    Statistics='Warm-ups excluded. Median, observed range and nearest-rank P95. Burst requests are correlated; one wall interval per burst.'
    Fixture=@{ Seed=1108; Shapes=@('1000 records / 256 ASCII characters','10000 records / 256 ASCII characters','10000 records / 2048 ASCII characters'); Generator='DatabaseFixture.ps1, identical arithmetic fields/JSON to SQLite'; MeasuredBlocks=7; WarmupsPerSequentialCase=1; MeasuredBurstBlocks=3; OperationsPerWorker=200 }
    Boundaries=@{ Direct='Native Measure-Command around helper call/return, SQL, object construction and owned-connection disposal; serialization and checks follow clock'; Endpoint='HTTP response plus JSON-to-object parsing; pooled database connection in handler'; Import='Whole script locally, or submit + 50ms completion polling + pipeline retrieval; fixture decoding and batch JSON preparation included'; Burst='One earliest-worker-start to latest-worker-end wall interval, including between-operation driver work' }
    Host=Get-Content "$root/host.json" -Raw | ConvertFrom-Json
    Server=Get-Content "$root/server-before.json" -Raw | ConvertFrom-Json
    Metadata=Get-Content "$root/metadata.json" -Raw | ConvertFrom-Json
    Protocol=@{ Version=$metadata.Protocol; WorkerWarmupOperations=$metadata.WorkerWarmupOperations; IndexComparison=$metadata.IndexComparison }
    Psu=@{ Utc=$psu.Utc; Version=$psu.Version; Settings=$psu.Settings; Environments=@($psu.Environments | Select-Object name,version,maxRunspaces,persistentRunspace); PreviewHashes=$psu.PreviewHashes }
    Authentication=@{ WorkloadMode=(Get-Content "$root/metadata.json" -Raw | ConvertFrom-Json).Authentication; DiscoveryUsesWindowsAdministrator=$true; Direct=$(if (Test-Path "$root/benchmark-identity.json") { Get-Content "$root/benchmark-identity.json" -Raw | ConvertFrom-Json }); Endpoint=$(if (Test-Path "$root/followup/endpoint-identity.json") { Get-Content "$root/followup/endpoint-identity.json" -Raw | ConvertFrom-Json }); Job=$(if (Test-Path "$root/followup/job-identity.json") { Get-Content "$root/followup/job-identity.json" -Raw | ConvertFrom-Json }) }
    Validation=$validation
    Evidence=@{ Root="tools/output/database/$Pass"; Archive="tools/output/database/$Pass-evidence.zip"; Manifest='manifest.json SHA256 per file'; Sources='direct/source, followup/source, concurrency/source, operations/source, retained/source'; Exclusions=@('sqlserver-discovery','sqlserver-setup-initial'); Preservation='Checksum COPY_ONLY native backups of all three measured databases; operational backup actually restored and field-checked; source/schema metadata retained independently of installed server' }
    Reads=@($reads | Group-Object Shape,Case,Mode | ForEach-Object {
        $first=$_.Group[0]
        [pscustomobject]@{ Shape=$first.Shape; Case=$first.Case; Mode=$first.Mode; ClientMs=Get-Distribution $_.Group.ClientMs; Rows=$first.Rows; JsonCharacters=$first.JsonCharacters }
    })
    Writes=@($writes | Group-Object Shape,Case | ForEach-Object {
        $first=$_.Group[0]
        [pscustomobject]@{ Shape=$first.Shape; Case=$first.Case; ClientMs=Get-Distribution $_.Group.ClientMs; Rows=$first.Rows }
    })
    Endpoints=@($endpoints | Group-Object Shape,Case | ForEach-Object {
        $first=$_.Group[0]
        [pscustomobject]@{ Shape=$first.Shape; Case=$first.Case; ClientMs=Get-Distribution $_.Group.ClientMs; HttpMs=Get-Distribution $_.Group.HttpMs; ParseMs=Get-Distribution $_.Group.ParseMs; HandlerMs=Get-Distribution $_.Group.HandlerMs; ResponseBytes=Get-Distribution $_.Group.Bytes; PowerShell=$first.PowerShell }
    })
    Imports=@($imports | Group-Object Location,Method | ForEach-Object {
        $first=$_.Group[0]
        [pscustomobject]@{ Location=$first.Location; Method=$first.Method; ClientMs=Get-Distribution $_.Group.ClientMs; DatabaseMs=Get-Distribution $_.Group.Result.DatabaseMs; ScriptMs=Get-Distribution $_.Group.Result.ScriptMs; Rows=1000 }
    })
    Bursts=@($bursts | Group-Object Readers,Writers | ForEach-Object {
        $first=$_.Group[0]
        $workers=@($_.Group | ForEach-Object { Get-Content "$root/concurrency/$($_.WorkersFile)" -Raw | ConvertFrom-Json })
        [pscustomobject]@{ Readers=$first.Readers; Writers=$first.Writers; Bursts=$_.Count; OperationsPerBurst=$first.Operations; WallMs=Get-Distribution $_.Group.WallMs; AllWorkersOverlapMs=Get-Distribution $_.Group.AllWorkersOverlapMs
            OperationsPerSecond=Get-Distribution @($_.Group | ForEach-Object { 1000*$_.Operations/$_.WallMs })
            Roles=@($workers | Group-Object Role | ForEach-Object { [pscustomobject]@{ Role=$_.Name; ClientMs=Get-Distribution $_.Group.Samples.TotalMs; Errors=@($_.Group.Samples | Where-Object Error).Count } }) }
    })
    Operations=Get-Content "$root/operations/checks.json" -Raw | ConvertFrom-Json
    Storage=@(Get-ChildItem "$root/direct/*-conditions.json" | ForEach-Object { $condition=Get-Content $_ -Raw | ConvertFrom-Json; [pscustomobject]@{ Shape=$condition.Shape; Relations=$condition.Storage } })
    Monitoring=@(foreach ($phase in 'direct','followup','concurrency') {
        $samples=@(Get-Content "$root/$phase/monitoring.jsonl" | ConvertFrom-Json)
        [pscustomobject]@{ Phase=$phase; Samples=$samples.Count; FirstUtc=$samples[0].Utc; LastUtc=$samples[-1].Utc
            Counters=@($samples.Counters | Group-Object Path | ForEach-Object { [pscustomobject]@{ Path=$_.Name; Values=Get-Distribution $_.Group.CookedValue } })
            Processes=@($samples.Processes | Group-Object Id | ForEach-Object { [pscustomobject]@{ Id=$_.Group[0].Id; Name=$_.Group[0].ProcessName; CpuSamples=@($_.Group | Where-Object { $null -ne $_.CPU }).Count; CpuSecondsObserved=$(if (@($_.Group | Where-Object { $null -ne $_.CPU }).Count -ge 2) { $_.Group[-1].CPU-$_.Group[0].CPU } else { $null }); PeakPrivateBytes=($_.Group.PrivateMemorySize64 | Measure-Object -Maximum).Maximum; PeakWorkingSetBytes=($_.Group.WorkingSet64 | Measure-Object -Maximum).Maximum } }) }
    })
    Limitations=@(
        'Separate warm local provider passes on the same host/storage; neither paired trials nor isolated engine speed.',
        'At most 10,000 synthetic records, repeated ASCII x payloads. SQL Server uses uncompressed Unicode JSON text and rows; PostgreSQL uses JSONB with unusually effective TOAST compression.',
        'SQL Server uses JSON text, typed nonpersisted computed columns and B-tree indexes; native SQL Server 2025 JSON type/JSON indexes were not measured. Corrected passes counterbalance paired index-present/absent reuse reads and warm each condition ten times; historical passes used a separate scan phase.',
        'SQL Server document projection returns typed columns rather than constructing another JSON object in SQL; object mapping and complete fields remain inside the client boundary.',
        'Direct outer Measure-Command clocks include helper return and connection disposal; serialization/checks follow clocks. SQLite used Stopwatch. No subtraction of harness overhead.',
        'Memory/cache budgets and encryption differ. SQL Server defaults permit dynamic memory growth and use encrypted TCP trusting the local certificate; PostgreSQL used SSL disabled. Fresh connections include the selected authentication and TLS setup.',
        'SQL Server/PG endpoints use pooled connections; SQLite endpoints did not. SQL Server direct new/reuse/pooled modes expose the connection choice.',
        'Per-row writes send one prepared statement per row; OPENJSON set variants send one JSON request and commit once. Batch JSON is outside database timers and inside whole-import clocks. Work tables lack the main filter index.',
        'Authentication and identities are recorded separately for discovery and workloads. SQL login mode uses a non-sysadmin owner of dedicated databases; Windows baseline used sysadmin. Neither is a production least-privilege service identity. No remote host, frontend, sustained capacity, cold cache, crash, PITR or HA testing.',
        'No SQL Server endpoint concurrency. Default read committed used locks with RCSI disabled; repeatable read held shared locks. Snapshot isolation was disabled and not tested.',
        'One-second host samples cannot attribute individual requests; sqlservr CPU values were unavailable under this diagnostic identity, so its CPU delta is null. Agent/tool activity was not isolated or given a paired SQL Server control.',
        'Seven sequential observations per case and three measured concurrency bursts support bounded choices, not capacity or precise tail estimates.'
    )
}
if (Test-Path "$root/psu-condition.json") { $summary.PsuCondition=Get-Content "$root/psu-condition.json" -Raw | ConvertFrom-Json }
$summary | ConvertTo-Json -Depth 35 | Set-Content "$root/summary.json"
if ($SkipPortable) {
    Write-Output "SQL Server summary only: $root/summary.json"
    return
}
$portableName = if ($metadata.Protocol -eq 'review-corrected-v2') { 'SqlServerReviewedEvidence.json' } else { 'SqlServerEvidence.json' }
if (!$Replace -and (Test-Path "$PSScriptRoot/$portableName")) {
    $existingPass = (Get-Content "$PSScriptRoot/$portableName" -Raw | ConvertFrom-Json).Pass
    if ($existingPass -ne $Pass) { throw "$portableName holds pass $existingPass; use -Replace to overwrite it" }
}
Copy-Item "$root/summary.json" "$PSScriptRoot/$portableName" -Force
Write-Output "Portable SQL Server evidence: $PSScriptRoot/$portableName"




