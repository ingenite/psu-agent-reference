# Experimental only; not reference material for creating production PSU resources.
# Owner approved Npgsql .NET connection/command/transaction/reader APIs for this
# PostgreSQL benchmark (2026-11-08 session). No package installation is required.
$ErrorActionPreference = 'Stop'
if (!('Npgsql.NpgsqlConnection' -as [type])) {
    Add-Type -Path C:/dev-psu/Microsoft.Extensions.Logging.Abstractions.dll
    Add-Type -Path C:/dev-psu/Npgsql.dll
}

function Get-PostgresDatabaseName {
    param([string] $Pass, [string] $Shape)
    if ($Pass -notmatch '^[a-zA-Z0-9-]{1,24}$' -or $Shape -notin 'n1000-p256','n10000-p256','n10000-p2048','operations','restore') { throw 'Invalid benchmark database name' }
    'par_pg_' + $Pass.Replace('-','_').ToLower() + '_' + $Shape.Replace('-','_')
}

function Get-PostgresPassword {
    $password = $env:PGPASSWORD
    if (!$password -and (Test-Path C:/dev-psu/postgres-benchmark-password.txt)) { $password = (Get-Content C:/dev-psu/postgres-benchmark-password.txt -Raw).Trim() }
    if (!$password) { throw 'Set PGPASSWORD to the disposable demonstration password' }
    $password
}

function Open-PostgresDatabase {
    param([string] $Database, [string] $Role = 'par_benchmark', [switch] $Pooling)
    if ($Database -ne 'postgres' -and $Database -notmatch '^par_pg_[a-z0-9_]+$') { throw 'Not a dedicated benchmark database' }
    $password = Get-PostgresPassword
    $builder = [Npgsql.NpgsqlConnectionStringBuilder]::new()
    $builder.Host = '127.0.0.1'; $builder.Port = 5432; $builder.Database = $Database
    $builder.Username = $Role; $builder.Password = $password; $builder.Pooling = [bool]$Pooling
    $builder.SslMode = 'Disable'; $builder.Timeout = 5; $builder.CommandTimeout = 5
    $builder.ApplicationName = 'PAR bounded database benchmark'
    $connection = [Npgsql.NpgsqlConnection]::new($builder.ConnectionString)
    $connection.Open()
    return ,$connection
}

function Invoke-PostgresSql {
    param($Connection, [string] $Sql)
    $command = $Connection.CreateCommand()
    try {
        $command.CommandText = $Sql
        $reader = $command.ExecuteReader()
        try {
            do {
                while ($reader.Read()) {
                    $row = [ordered]@{}
                    for ($column = 0; $column -lt $reader.FieldCount; $column++) { $row[$reader.GetName($column)] = $reader.GetValue($column) }
                    [pscustomobject]$row
                }
            } while ($reader.NextResult())
        } finally { $reader.Dispose() }
    } finally { $command.Dispose() }
}

function Initialize-PostgresDatabase {
    param([string] $Database, [array] $Fixture, [string] $AdministrativeRole)
    $admin = Open-PostgresDatabase postgres -Role $AdministrativeRole
    try { $null = Invoke-PostgresSql $admin "CREATE DATABASE $Database OWNER par_benchmark" } finally { $admin.Dispose() }
    $connection = Open-PostgresDatabase $Database
    try {
        $null = Invoke-PostgresSql $connection @'
CREATE TABLE records(Id integer PRIMARY KEY, Name text NOT NULL, Category text NOT NULL, Enabled integer NOT NULL, Cpu integer NOT NULL, Payload text NOT NULL, Revision integer NOT NULL);
CREATE TABLE documents(Id integer PRIMARY KEY, Body jsonb NOT NULL);
CREATE INDEX records_filter ON records(Category, Enabled, Id);
CREATE INDEX documents_filter ON documents((Body->>'Category'), ((Body->>'Enabled')::integer), Id);
CREATE TABLE batch_records (LIKE records INCLUDING CONSTRAINTS);
ALTER TABLE batch_records ADD PRIMARY KEY(Id);
CREATE TABLE batch_documents(Id integer PRIMARY KEY, Body jsonb NOT NULL);
'@
        $null = Write-PostgresBatch $connection $Fixture rows records
        $null = Write-PostgresBatch $connection $Fixture documents documents
        $null = Invoke-PostgresSql $connection 'VACUUM (ANALYZE) records'
        $null = Invoke-PostgresSql $connection 'VACUUM (ANALYZE) documents'
    } finally { $connection.Dispose() }
}

function Write-PostgresBatch {
    param($Connection, [array] $Fixture,
        [ValidateSet('rows','documents','refresh-rows','refresh-documents','rows-set','refresh-rows-set','refresh-documents-set')][string] $Kind,
        [ValidateSet('records','documents','batch_records','batch_documents')][string] $Table,
        [switch] $Autocommit, [string] $BatchJson)
    $transaction = $null
    $command = $Connection.CreateCommand()
    try {
        if (!$Autocommit) { $transaction = $Connection.BeginTransaction(); $command.Transaction = $transaction }
        $command.CommandText = switch ($Kind) {
            rows { "INSERT INTO $Table VALUES (@id,@name,@category,@enabled,@cpu,@payload,@revision)" }
            documents { "INSERT INTO $Table VALUES (@id,CAST(@body AS jsonb))" }
            refresh-rows { "UPDATE $Table SET Revision=Revision+1 WHERE Id=@id" }
            refresh-documents { "UPDATE $Table SET Body=jsonb_set(Body,'{Revision}',to_jsonb((Body->>'Revision')::integer+1)) WHERE Id=@id" }
            rows-set { "INSERT INTO $Table SELECT x.* FROM jsonb_to_recordset(CAST(@batch AS jsonb)) AS x(""Id"" integer,""Name"" text,""Category"" text,""Enabled"" integer,""Cpu"" integer,""Payload"" text,""Revision"" integer)" }
            refresh-rows-set { "UPDATE $Table SET Revision=Revision+1 WHERE Id=ANY(@ids)" }
            refresh-documents-set { "UPDATE $Table SET Body=jsonb_set(Body,'{Revision}',to_jsonb((Body->>'Revision')::integer+1)) WHERE Id=ANY(@ids)" }
        }
        if ($Kind -eq 'rows-set') {
            if (!$BatchJson) { throw 'Prepare BatchJson outside the database timer' }
            $null = $command.Parameters.AddWithValue('batch', $BatchJson)
        } elseif ($Kind -like '*-set') {
            $null = $command.Parameters.AddWithValue('ids', [int[]]$Fixture.Record.Id)
        } else {
            $null = $command.Parameters.AddWithValue('id', [int]0)
            if ($Kind -eq 'rows') {
                foreach ($name in 'name','category','payload') { $null = $command.Parameters.AddWithValue($name, '') }
                foreach ($name in 'enabled','cpu','revision') { $null = $command.Parameters.AddWithValue($name, [int]0) }
            } elseif ($Kind -eq 'documents') { $null = $command.Parameters.AddWithValue('body', '') }
        }
        $command.Prepare()
        $affected = 0
        if ($Kind -like '*-set') { $affected = $command.ExecuteNonQuery() }
        else {
            foreach ($item in $Fixture) {
                $command.Parameters['id'].Value = [int]$item.Record.Id
                if ($Kind -eq 'rows') {
                    foreach ($name in 'name','category','payload') { $command.Parameters[$name].Value = [string]$item.Record.$name }
                    # ConvertFrom-Json produces wider integers than the int4 SQL
                    # columns. Keep prepared parameter values consistent with int4.
                    foreach ($name in 'enabled','cpu','revision') { $command.Parameters[$name].Value = [int]$item.Record.$name }
                } elseif ($Kind -eq 'documents') { $command.Parameters['body'].Value = $item.Json }
                $affected += $command.ExecuteNonQuery()
            }
        }
        if ($transaction) { $transaction.Commit() }
        [pscustomobject]@{ Affected = $affected }
    } finally { $command.Dispose(); if ($transaction) { $transaction.Dispose() } }
}

function Get-PostgresQuery {
    param([string] $Case, [int] $Count)
    $fields = 'Id,Name,Category,Enabled,Cpu,Payload,Revision'
    switch ($Case) {
        row-key { "SELECT $fields FROM records WHERE Id=@id" }
        document-key { 'SELECT Body::text FROM documents WHERE Id=@id' }
        row-filter { "SELECT $fields FROM records WHERE Category=@category AND Enabled=1 ORDER BY Id" }
        document-filter-index { "SELECT Body::text FROM documents WHERE Body->>'Category'=@category AND (Body->>'Enabled')::integer=1 ORDER BY Id" }
        row-projection { 'SELECT Id,Name,Cpu FROM records WHERE Category=@category AND Enabled=1 ORDER BY Id' }
        document-projection { "SELECT jsonb_build_object('Id',Id,'Name',Body->>'Name','Cpu',(Body->>'Cpu')::integer)::text FROM documents WHERE Body->>'Category'=@category AND (Body->>'Enabled')::integer=1 ORDER BY Id" }
        row-offset { "SELECT $fields FROM records WHERE Category=@category AND Enabled=1 ORDER BY Id LIMIT 20 OFFSET $([int]($Count / 40))" }
        row-seek { "SELECT $fields FROM records WHERE Category=@category AND Enabled=1 AND Id>@after ORDER BY Id LIMIT 20" }
        default { throw "Unknown query: $Case" }
    }
}

function Read-PostgresRecord {
    param([string] $Database, [string] $Case, [int] $Count, $Connection, [switch] $Pooling)
    $ownsConnection = !$Connection
    if ($ownsConnection) { $Connection = Open-PostgresDatabase $Database -Pooling:$Pooling }
    $command = $Connection.CreateCommand()
    try {
        $command.CommandText = Get-PostgresQuery $Case $Count
        $null = $command.Parameters.AddWithValue('id', [int]($Count / 2))
        $null = $command.Parameters.AddWithValue('category', 'group-2')
        $null = $command.Parameters.AddWithValue('after', [int]($Count / 2))
        $reader = $command.ExecuteReader()
        try {
            $records = @(while ($reader.Read()) {
                if ($Case -like 'document-*') { $reader.GetString(0) | ConvertFrom-Json }
                elseif ($Case -eq 'row-projection') { [pscustomobject][ordered]@{ Id=$reader.GetInt32(0); Name=$reader.GetString(1); Cpu=$reader.GetInt32(2) } }
                else {
                    [pscustomobject][ordered]@{
                        Id=$reader.GetInt32(0); Name=$reader.GetString(1); Category=$reader.GetString(2)
                        Enabled=$reader.GetInt32(3); Cpu=$reader.GetInt32(4); Payload=$reader.GetString(5); Revision=$reader.GetInt32(6)
                    }
                }
            })
        } finally { $reader.Dispose() }
        [pscustomobject]@{ Records=$records; Engine=$Connection.ServerVersion }
    } finally { $command.Dispose(); if ($ownsConnection) { $Connection.Dispose() } }
}

function Invoke-PostgresIncrement {
    param($Connection)
    $transaction = $Connection.BeginTransaction()
    $command = $Connection.CreateCommand()
    try {
        $command.Transaction = $transaction
        # Lock rows in key order first; physical scan order let concurrent writers deadlock.
        $command.CommandText = 'UPDATE batch_records SET Revision=Revision+1 WHERE Id IN (SELECT Id FROM batch_records WHERE Id<=10 ORDER BY Id FOR UPDATE)'
        $affected = $command.ExecuteNonQuery()
        $transaction.Commit()
        [pscustomobject]@{ Affected=$affected; Engine=$Connection.ServerVersion }
    } finally { $command.Dispose(); $transaction.Dispose() }
}
