# Experimental only; not reference material for creating production PSU resources.
# Owner approved bundled SQLite .NET connection/command/transaction/reader APIs and
# Stopwatch/process instrumentation for this SQLite experiment (2026-11-08 session).
$ErrorActionPreference = 'Stop'
if (!('Microsoft.Data.Sqlite.SqliteConnection' -as [type])) {
    foreach ($assembly in 'SQLitePCLRaw.core','SQLitePCLRaw.provider.e_sqlite3','SQLitePCLRaw.batteries_v2','Microsoft.Data.Sqlite') {
        Add-Type -Path "C:/dev-psu/$assembly.dll"
    }
    [SQLitePCL.Batteries_V2]::Init()
}

function Open-BenchmarkDatabase {
    param([string] $Path, [switch] $Create, [ValidateSet('FULL','NORMAL')][string] $Sync = 'FULL')
    $connection = [Microsoft.Data.Sqlite.SqliteConnection]::new("Data Source=$Path;Mode=$(if ($Create) {'ReadWriteCreate'} else {'ReadWrite'});Pooling=False;Cache=Private;Default Timeout=5")
    $connection.Open()
    $command = $connection.CreateCommand()
    $command.CommandText = "PRAGMA synchronous=$Sync; PRAGMA foreign_keys=ON; PRAGMA cache_size=-8192; PRAGMA wal_autocheckpoint=1000;"
    $null = $command.ExecuteNonQuery()
    $command.Dispose()
    return ,$connection
}

function Invoke-BenchmarkSql {
    param($Connection, [string] $Sql)
    $command = $Connection.CreateCommand()
    try {
        $command.CommandText = $Sql
        $reader = $command.ExecuteReader()
        try {
            while ($reader.Read()) {
                $row = [ordered]@{}
                for ($column = 0; $column -lt $reader.FieldCount; $column++) { $row[$reader.GetName($column)] = $reader.GetValue($column) }
                [pscustomobject]$row
            }
        } finally { $reader.Dispose() }
    } finally { $command.Dispose() }
}

function New-BenchmarkFixture {
    param([int] $Count, [int] $PayloadSize, [int] $Seed = 1108)
    # Stable arithmetic fields and exact ASCII payload length; no live inventory.
    $payload = 'x' * $PayloadSize
    for ($id = 1; $id -le $Count; $id++) {
        $record = [pscustomobject][ordered]@{
            Id = $id; Name = 'process-{0:D6}' -f $id; Category = "group-$($id % 10)"
            Enabled = [int]($id % 4 -ne 0); Cpu = ($id * 37 + $Seed) % 1000
            Payload = $payload; Revision = 0
        }
        [pscustomobject]@{ Record = $record; Json = $record | ConvertTo-Json -Compress }
    }
}

function Initialize-BenchmarkDatabase {
    param([string] $Path, [array] $Fixture)
    if (Test-Path -LiteralPath $Path) { throw "Database already exists: $Path" }
    $connection = Open-BenchmarkDatabase -Path $Path -Create
    try {
        $null = Invoke-BenchmarkSql $connection @'
PRAGMA journal_mode=WAL;
CREATE TABLE records(Id INTEGER PRIMARY KEY, Name TEXT NOT NULL, Category TEXT NOT NULL, Enabled INTEGER NOT NULL, Cpu INTEGER NOT NULL, Payload TEXT NOT NULL, Revision INTEGER NOT NULL);
CREATE TABLE documents(Id INTEGER PRIMARY KEY, Body TEXT NOT NULL CHECK(json_valid(Body)));
CREATE INDEX records_filter ON records(Category, Enabled, Id);
CREATE INDEX documents_filter ON documents(json_extract(Body,'$.Category'), json_extract(Body,'$.Enabled'), Id);
CREATE TABLE batch_records AS SELECT * FROM records WHERE 0;
CREATE UNIQUE INDEX batch_records_key ON batch_records(Id);
CREATE TABLE batch_documents(Id INTEGER PRIMARY KEY, Body TEXT NOT NULL CHECK(json_valid(Body)));
'@
        $null = Write-BenchmarkBatch $connection $Fixture -Kind rows -Table records
        $null = Write-BenchmarkBatch $connection $Fixture -Kind documents -Table documents
        $null = Invoke-BenchmarkSql $connection 'ANALYZE; PRAGMA wal_checkpoint(TRUNCATE);'
    } finally { $connection.Dispose() }
}

function Write-BenchmarkBatch {
    param($Connection, [array] $Fixture, [ValidateSet('rows','documents','refresh-rows','refresh-documents')][string] $Kind,
        [ValidateSet('records','documents','batch_records','batch_documents')][string] $Table, [switch] $Autocommit)
    $timer = [System.Diagnostics.Stopwatch]::StartNew()
    $transaction = $null
    $command = $Connection.CreateCommand()
    try {
        if (!$Autocommit) { $transaction = $Connection.BeginTransaction(); $command.Transaction = $transaction }
        $command.CommandText = switch ($Kind) {
            rows { "INSERT INTO $Table VALUES (@id,@name,@category,@enabled,@cpu,@payload,@revision)" }
            documents { "INSERT INTO $Table VALUES (@id,@body)" }
            refresh-rows { "UPDATE $Table SET Revision=Revision+1 WHERE Id=@id" }
            refresh-documents { "UPDATE $Table SET Body=json_set(Body,'$.Revision',json_extract(Body,'$.Revision')+1) WHERE Id=@id" }
        }
        $null = $command.Parameters.AddWithValue('@id', 0)
        if ($Kind -eq 'rows') {
            foreach ($name in 'name','category','enabled','cpu','payload','revision') { $null = $command.Parameters.AddWithValue("@$name", '') }
        } elseif ($Kind -eq 'documents') { $null = $command.Parameters.AddWithValue('@body', '') }
        $command.Prepare()
        $affected = 0
        foreach ($item in $Fixture) {
            $record = $item.Record
            $command.Parameters['@id'].Value = $record.Id
            if ($Kind -eq 'rows') {
                foreach ($name in 'name','category','enabled','cpu','payload','revision') { $command.Parameters["@$name"].Value = $record.$name }
            } elseif ($Kind -eq 'documents') { $command.Parameters['@body'].Value = $item.Json }
            $affected += $command.ExecuteNonQuery()
        }
        $loopMs = $timer.Elapsed.TotalMilliseconds
        if ($transaction) { $transaction.Commit() }
        $commitMs = $timer.Elapsed.TotalMilliseconds - $loopMs
    } finally {
        $command.Dispose()
        if ($transaction) { $transaction.Dispose() }
    }
    [pscustomobject]@{ TotalMs = $timer.Elapsed.TotalMilliseconds; SetupAndLoopMs = $loopMs; CommitMs = $commitMs; Affected = $affected }
}

function Get-BenchmarkQuery {
    param([string] $Case, [int] $Count)
    $fields = 'Id,Name,Category,Enabled,Cpu,Payload,Revision'
    switch ($Case) {
        row-key { "SELECT $fields FROM records WHERE Id=@id" }
        document-key { 'SELECT Body FROM documents WHERE Id=@id' }
        row-filter { "SELECT $fields FROM records WHERE Category=@category AND Enabled=1 ORDER BY Id" }
        document-filter-scan { "SELECT Body FROM documents NOT INDEXED WHERE json_extract(Body,'$.Category')=@category AND json_extract(Body,'$.Enabled')=1 ORDER BY Id" }
        document-filter-index { "SELECT Body FROM documents WHERE json_extract(Body,'$.Category')=@category AND json_extract(Body,'$.Enabled')=1 ORDER BY Id" }
        row-projection { "SELECT Id,Name,Cpu FROM records WHERE Category=@category AND Enabled=1 ORDER BY Id" }
        document-projection { "SELECT json_object('Id',Id,'Name',json_extract(Body,'$.Name'),'Cpu',json_extract(Body,'$.Cpu')) AS Body FROM documents WHERE json_extract(Body,'$.Category')=@category AND json_extract(Body,'$.Enabled')=1 ORDER BY Id" }
        row-offset { "SELECT $fields FROM records WHERE Category=@category AND Enabled=1 ORDER BY Id LIMIT 20 OFFSET $([int]($Count / 40))" }
        row-seek { "SELECT $fields FROM records WHERE Category=@category AND Enabled=1 AND Id>@after ORDER BY Id LIMIT 20" }
        default { throw "Unknown query: $Case" }
    }
}

function Read-BenchmarkRecord {
    param([string] $Path, [string] $Case, [int] $Count, $Connection, [ValidateSet('FULL','NORMAL')][string] $Sync = 'FULL', [switch] $SkipSerialization)
    $timer = [System.Diagnostics.Stopwatch]::StartNew()
    $ownsConnection = !$Connection
    if ($ownsConnection) { $Connection = Open-BenchmarkDatabase -Path $Path -Sync $Sync }
    $engine = $Connection.ServerVersion
    $openMs = $timer.Elapsed.TotalMilliseconds
    $command = $Connection.CreateCommand()
    try {
        $command.CommandText = Get-BenchmarkQuery -Case $Case -Count $Count
        $null = $command.Parameters.AddWithValue('@id', [int]($Count / 2))
        $null = $command.Parameters.AddWithValue('@category', 'group-2')
        $null = $command.Parameters.AddWithValue('@after', [int]($Count / 2))
        $beforeExecute = $timer.Elapsed.TotalMilliseconds
        $reader = $command.ExecuteReader()
        $executeMs = $timer.Elapsed.TotalMilliseconds - $beforeExecute
        try {
            $records = @(while ($reader.Read()) {
                if ($Case -like 'document-*') { $reader.GetString(0) | ConvertFrom-Json }
                elseif ($Case -eq 'row-projection') { [pscustomobject][ordered]@{ Id = $reader.GetInt64(0); Name = $reader.GetString(1); Cpu = $reader.GetInt64(2) } }
                else {
                    [pscustomobject][ordered]@{
                        Id = $reader.GetInt64(0); Name = $reader.GetString(1); Category = $reader.GetString(2)
                        Enabled = $reader.GetInt64(3); Cpu = $reader.GetInt64(4); Payload = $reader.GetString(5); Revision = $reader.GetInt64(6)
                    }
                }
            })
            $fetchObjectMs = $timer.Elapsed.TotalMilliseconds - $beforeExecute - $executeMs
        } finally { $reader.Dispose() }
    } finally { $command.Dispose(); if ($ownsConnection) { $Connection.Dispose() } }
    $totalMs = $timer.Elapsed.TotalMilliseconds
    # Separate optional wire serialization; direct TotalMs ends at usable objects/close.
    $serializeMs = $null
    $characters = $null
    if (!$SkipSerialization) {
        $serializeTimer = [System.Diagnostics.Stopwatch]::StartNew()
        $json = ConvertTo-Json -InputObject $records -Depth 5 -Compress
        $serializeMs = $serializeTimer.Elapsed.TotalMilliseconds
        $characters = $json.Length
    }
    [pscustomobject]@{
        Metrics = [pscustomobject]@{ TotalMs = $totalMs; OpenConfigureMs = $openMs; ExecuteReaderMs = $executeMs; FetchObjectMs = $fetchObjectMs; SerializeMs = $serializeMs; JsonCharacters = $characters; Rows = $records.Count }
        Records = $records
        Engine = $engine
    }
}

function Assert-BenchmarkRecord {
    param([array] $Actual, [array] $Expected, [string[]] $Fields = @('Id','Name','Category','Enabled','Cpu','Payload','Revision'))
    if ($Actual.Count -ne $Expected.Count) { throw "Wrong record count: $($Actual.Count) / $($Expected.Count)" }
    for ($i = 0; $i -lt $Expected.Count; $i++) {
        foreach ($field in $Fields) {
            if ($Actual[$i].$field -cne $Expected[$i].$field) { throw "Wrong $field at index $i" }
        }
    }
}

function Invoke-BenchmarkIncrement {
    param($Connection)
    $timer = [System.Diagnostics.Stopwatch]::StartNew()
    $transaction = $Connection.BeginTransaction()
    $command = $Connection.CreateCommand()
    try {
        $command.Transaction = $transaction
        $command.CommandText = 'UPDATE batch_records SET Revision=Revision+1 WHERE Id<=10'
        $affected = $command.ExecuteNonQuery()
        $beforeCommit = $timer.Elapsed.TotalMilliseconds
        $transaction.Commit()
        [pscustomobject]@{ TotalMs = $timer.Elapsed.TotalMilliseconds; CommitMs = $timer.Elapsed.TotalMilliseconds - $beforeCommit; Affected = $affected; Engine = $Connection.ServerVersion }
    } finally { $command.Dispose(); $transaction.Dispose() }
}
