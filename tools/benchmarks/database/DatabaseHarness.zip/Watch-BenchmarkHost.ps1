# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Samples host counters and PowerShell/PSU process resources once per second until a stop file exists.
.PARAMETER OutputDirectory
Existing evidence directory. Writes monitoring.jsonl and monitor-ready.txt.
.NOTES
Read-only Windows diagnostics. Run in a separate process. Not per-query attribution;
process CPU is cumulative seconds and process working sets can double-count shared pages.
#>
param([Parameter(Mandatory)][string] $OutputDirectory)
$ErrorActionPreference = 'Stop'
Set-Content "$OutputDirectory/monitor-ready.txt" $PID
while (!(Test-Path "$OutputDirectory/monitor-stop.txt")) {
    $counters = Get-Counter '\Processor(_Total)\% Processor Time','\Memory\Available MBytes','\PhysicalDisk(_Total)\Avg. Disk sec/Transfer'
    @{ Utc = (Get-Date).ToUniversalTime().ToString('o')
        Counters = @($counters.CounterSamples | Select-Object Path,CookedValue)
        Processes = @(Get-Process pwsh,Universal.Server -ErrorAction SilentlyContinue | Select-Object Id,ProcessName,CPU,WorkingSet64,PrivateMemorySize64)
    } | ConvertTo-Json -Depth 5 -Compress | Add-Content "$OutputDirectory/monitoring.jsonl"
}
