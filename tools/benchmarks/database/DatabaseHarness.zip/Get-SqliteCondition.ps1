# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Records non-secret Windows, driver and dev-psu conditions for an existing SQLite pass.
.PARAMETER Pass
Existing tools/output/database pass. Writes host/provider/runtime/PSU condition files.
.NOTES
Read-only system/API discovery; requires access to Windows CIM/counters and the
designated dev-psu vault token. No credentials or credential-bearing responses are saved.
Run immediately after the direct pass and before PSU blocks. Logging/security overrides and Windows diagnostics are
reported separately from API defaults; a null worker override remains unknown.
#>
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]+$')][string] $Pass)
$ErrorActionPreference = 'Stop'
$root = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
if (!(Test-Path "$root/metadata.json")) { throw 'Pass does not exist' }
@{ Processor = Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors
    Computer = Get-CimInstance Win32_ComputerSystem | Select-Object TotalPhysicalMemory
    OS = Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber
    Disks = Get-Partition -DriveLetter C | Get-Disk | Select-Object Number,FriendlyName,BusType,Size
    Services = @(Get-CimInstance Win32_Service | Where-Object Name -match 'MSSQL|postgres' | Select-Object Name,State)
    OtherDatabaseProcesses = @(Get-Process sqlservr,postgres -ErrorAction SilentlyContinue | Select-Object Id,ProcessName)
    PowerPlan = powercfg /getactivescheme
    CounterProbe = (Get-Counter '\Processor(_Total)\% Processor Time','\Memory\Available MBytes','\PhysicalDisk(_Total)\Avg. Disk sec/Transfer').CounterSamples | Select-Object Path,CookedValue
} | ConvertTo-Json -Depth 6 | Set-Content "$root/host.json"
$configuration = Get-Content C:/dev-psu/appsettings.json -Raw | ConvertFrom-Json
@{ SystemLogLevel = $configuration.SystemLogLevel; HangfireWorkerCount = $configuration.HangfireWorkerCount
    ApiSecurity = $configuration.Api.SecurityModel; ConfigurationPath = 'C:/dev-psu/appsettings.json'
} | ConvertTo-Json | Set-Content "$root/psu-config-overrides.json"
$token = Get-Secret -Name dev-psu-codex-mgmt-api -AsPlainText
$headers = @{ Authorization = "Bearer $token" }
$response = Invoke-RestMethod http://127.0.0.1:5100/api/v1/settings -Headers $headers -MaximumRedirection 0
@($response)[0] | Select-Object logLevel,microsoftLogLevel,concurrentJobLimit,maxJobMemory,apiSecurityModel,scriptBaseFolder,gitSyncEnabled,repositoryPath |
    ConvertTo-Json | Set-Content "$root/psu-settings.json"
$listener = Get-NetTCPConnection -LocalPort 5100 -State Listen
Get-CimInstance Win32_Process | Where-Object ProcessId -eq $listener.OwningProcess | Select-Object ProcessId,ExecutablePath |
    ConvertTo-Json | Set-Content "$root/dev-psu-process.json"
@{ Harness = (Get-Content "$PSHOME/pwsh.runtimeconfig.json" -Raw | ConvertFrom-Json).runtimeOptions
    PsuServer = (Get-Content C:/dev-psu/Universal.Server.runtimeconfig.json -Raw | ConvertFrom-Json).runtimeOptions
    PsuJob = (Get-Content C:/dev-psu/pwsh.runtimeconfig.json -Raw | ConvertFrom-Json).runtimeOptions
} | ConvertTo-Json -Depth 8 | Set-Content "$root/runtime-conditions.json"
Get-Item C:/dev-psu/Microsoft.Data.Sqlite.dll,C:/dev-psu/e_sqlite3.dll,C:/dev-psu/SQLitePCLRaw.*.dll | Get-FileHash |
    Select-Object Path,Hash | ConvertTo-Json | Set-Content "$root/provider-hashes.json"
# Owner approved bundled SQLite .NET APIs for this SQLite experiment.
Add-Type -Path C:/dev-psu/System.Data.SQLite.dll
$connection = [System.Data.SQLite.SQLiteConnection]::new('Data Source=:memory:;')
$connection.Open()
$command = $connection.CreateCommand()
try {
    $command.CommandText = 'SELECT sqlite_version()'
    $version = $command.ExecuteScalar()
    $command.CommandText = "SELECT json_extract('{}','$.test')"
    $jsonAvailable = $true
    try { $null = $command.ExecuteScalar() } catch { $jsonAvailable = $false }
    @{ Provider = $connection.GetType().Assembly.FullName; Engine = $version; JsonExtractAvailable = $jsonAvailable; UsedForMeasurement = $false } |
        ConvertTo-Json | Set-Content "$root/driver-discovery.json"
} finally { $command.Dispose(); $connection.Dispose() }
Write-Output "Conditions recorded: $root"
