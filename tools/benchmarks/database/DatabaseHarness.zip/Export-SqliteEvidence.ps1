# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Exports a portable summary of a checked SQLite pass beside these scripts.
.PARAMETER Pass
Completed tools/output/database pass. Requires summary.json and evidence-checks.json.
.PARAMETER Replace
Allows overwriting a SqliteEvidence.json that holds a different pass.
.NOTES
Replaces SqliteEvidence.json, a reviewable summary without local account identifiers.
A portable file from another pass is kept unless Replace is set.
Full raw samples, historical source snapshots and diagnostics remain in the ignored pass.
#>
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]+$')][string] $Pass, [switch] $Replace)
$ErrorActionPreference = 'Stop'
$root = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
$summary = Get-Content "$root/summary.json" -Raw | ConvertFrom-Json
$checks = Get-Content "$root/evidence-checks.json" -Raw | ConvertFrom-Json
if (!$checks.Correct) { throw 'Evidence is not checked' }
$conditions = $summary.Conditions[0]
$followup = Get-Content "$root/followup/metadata.json" -Raw | ConvertFrom-Json
$integrated = $followup.Environments | Where-Object Name -eq Integrated
$portable = [ordered]@{
    Pass = $Pass; MeasuredUtc = $summary.Metadata.Utc; BaseCommit = $summary.Metadata.Commit
    Status = 'SQLite measured; SQL Server and PostgreSQL not measured. Experimental only.'
    SampleSelection = 'Sequential direct results use client-boundary/ outer clocks. Original root read/write samples and original direct projection samples remain retained stage evidence. Endpoint/import/burst/control samples are unchanged.'
    Units = $summary.Unit; Statistics = 'Warm-ups excluded; medians/observed ranges; nearest-rank P95. Burst request latencies are correlated. Rate uses one wall time per burst.'
    Host = @{ Processor = $summary.Host.Processor; MemoryBytes = $summary.Host.Computer.TotalPhysicalMemory; OS = $summary.Host.OS; Disks = $summary.Host.Disks; PowerPlan = $summary.Host.PowerPlan }
    Runtime = @{ HarnessPowerShell = $summary.Metadata.PowerShell; Configuration = $summary.RuntimeConditions; Psu = $followup.Version; PsuPowerShell = $summary.Endpoints[0].PowerShell; Engine = $conditions.Engine; Provider = $conditions.Provider }
    Configuration = @{ Connection = $summary.Metadata.Connection; Pragmas = $summary.Metadata.Pragmas; Psu = $summary.PsuSettings | Select-Object concurrentJobLimit,maxJobMemory,scriptBaseFolder,gitSyncEnabled; PsuLogging = $summary.PsuConfigOverrides.SystemLogLevel; PsuSecurity = $summary.PsuConfigOverrides.ApiSecurity; EnvironmentMaxRunspaces = $integrated.maxRunspaces; PersistentRunspace = $integrated.persistentRunspace }
    Fixture = 'Seed 1108; Id 1..N; Name process-N; Category group-(Id%10); Enabled Id%4!=0; Cpu (Id*37+1108)%1000; exact ASCII x payload; Revision=0. Shapes 1000/256, 10000/256, 10000/2048. Fixture and document JSON prepared outside database timers.'
    Boundaries = @('Sequential direct totals include helper invocation/return and owned-connection disposal; internal database/object stages are retained. Optional JSON serialization is measured separately after the client clock.', 'ExecuteReaderMs is not engine execution time: further SQL stepping and JSON parsing occur in FetchObjectMs.', 'Batch client clocks include the transaction helper call/return, setup, parameter assignment, execution and commit on an open connection.', 'Endpoint clients include HTTP transfer and JSON parsing; request JSON preparation and validation are outside timers. ResponseBytes is Invoke-WebRequest RawContentLength (body, excluding headers); compression was not separately audited.', 'Import ClientMs includes source file/JSON decoding, job startup/status polling and saved JSON result retrieval. CompletedMs stops when completion is observed (50ms polls).', 'Concurrency opens/warms independent processes before the gate. Burst wall time spans earliest actual start to latest finish, including between-operation driver work; per-operation clocks exclude sample recording.', 'Endpoint projection and initial reads ran in separate blocks; direction and body sizes support the result, not a paired latency estimate.')
    Reads = $summary.Reads; Writes = $summary.Writes; Endpoints = $summary.Endpoints; Imports = $summary.Imports; Bursts = $summary.Bursts; Projection = $summary.Projection; OrchestrationControl = $summary.OrchestrationControl
    Operations = $summary.Operations | Select-Object Snapshot,WriteLock,Rollback,Reopen,BackupVerification
    Storage = $summary.Files
    Monitoring = @($summary.Monitoring | ForEach-Object { $phase = $_; [pscustomobject]@{ Phase = $phase.Phase; Samples = $phase.Samples
        Counters = @($phase.Counters | ForEach-Object { [pscustomobject]@{ Counter = $_.Path.Substring($_.Path.IndexOf('\',2)); Values = $_.Values } })
        ProcessPeaks = @($phase.Processes | Group-Object Name | ForEach-Object { [pscustomobject]@{ Name = $_.Name; PeakOneProcessWorkingSetBytes = ($_.Group.PeakWorkingSetBytes | Measure-Object -Maximum).Maximum; PeakOneProcessPrivateBytes = ($_.Group.PeakPrivateBytes | Measure-Object -Maximum).Maximum } })
    } })
    EvidenceChecks = $checks
    Evidence = @{ Root = "tools/output/database/$Pass"; Archive = "$Pass-evidence.zip"; Snapshots = @('source','followup/source','projection/source','operations/source','client-boundary/source'); Summary = 'summary.json'; Raw = @('client-boundary/reads.jsonl','client-boundary/writes.jsonl','reads.jsonl','writes.jsonl','followup/endpoints.jsonl','followup/imports.jsonl','followup/bursts.jsonl','followup/*/workers.json','followup/control.jsonl','projection/samples.jsonl'); Diagnostics = @('n*-conditions.json','operations/checks.json','*/monitoring.jsonl','host.json','provider-hashes.json','runtime-conditions.json','psu-settings.json','psu-config-overrides.json','endpoint-auth-check.json','preview-backup/restored.txt') }
    Limitations = @('Warm local data on a shared workstation; largest fixture 10000 records/2048 payload characters; initial database files include both layouts and indexes, not per-table sizes.', 'No provider installation, server database, remote host, frontend, sustained capacity, cold cache, service-account isolation, crash/power-loss, restore into a running application, pooling, or index-maintenance write cost comparison.', 'All-writer bursts share the same ten keys. Mixed readers query another table in the same database, not changing records. No fairness guarantee; provider busy waits are included and no application retry is added.', 'The background activity control is a small synthetic approximation, not every agent/tool operation. One-second monitoring cannot attribute individual subsecond operations.', 'PSU endpoint wrapper loads the helper on each call. Integrated endpoints and fresh automation processes use a different PowerShell/.NET runtime from the direct harness. HTTP/driver/logging costs and contention were not individually isolated.', 'Expression indexes were checked by EXPLAIN QUERY PLAN. Batch writes use separately indexed work tables, so they do not measure maintaining the main JSON expression index.', 'Historical metadata Runtime and Settings projections were empty; runtime-conditions.json and psu-settings.json/psu-config-overrides.json supply the separately verified values. Null HangfireWorkerCount does not establish an active worker count.')
}
if (!$Replace -and (Test-Path "$PSScriptRoot/SqliteEvidence.json")) {
    $existingPass = (Get-Content "$PSScriptRoot/SqliteEvidence.json" -Raw | ConvertFrom-Json).Pass
    if ($existingPass -ne $Pass) { throw "SqliteEvidence.json holds pass $existingPass; use -Replace to overwrite it" }
}
$portable | ConvertTo-Json -Depth 25 | Set-Content "$PSScriptRoot/SqliteEvidence.json"
Write-Output "Portable evidence: $PSScriptRoot/SqliteEvidence.json"
