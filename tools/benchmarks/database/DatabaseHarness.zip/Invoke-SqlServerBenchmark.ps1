# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Creates dedicated SQL Server databases and measures checked useful PowerShell results.
.PARAMETER Pass
Existing pass created by Get-SqlServerCondition. Creates direct/ once.
.PARAMETER Repetitions
Shuffled measured blocks following one warm-up; default seven.
.NOTES
Creates dedicated par_sql_ databases through the Windows administrator. Set
PAR_SQL_AUTHENTICATION=Sql and SQLSERVER_BENCHMARK_PASSWORD for SQL login workloads;
otherwise Windows authentication is used unless the temporary credential file exists.
Existing databases are never overwritten. Uses bundled Microsoft.Data.SqlClient, explicit TCP
loopback, five-second command/connect timeouts and default durable settings.
Measure-Command clocks include helper call/return and owned connection disposal;
fixture preparation, JSON serialization and all field checks are outside clocks.
Index-present/absent reuse reads use counterbalanced pairs per block, with DDL,
statistics and ten checked warm-up reads per condition outside measurement.
#>
param(
    [Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]{1,24}$')][string] $Pass,
    [ValidateRange(1,15)][int] $Repetitions = 7
)
. "$PSScriptRoot/SqlServer.ps1"
. "$PSScriptRoot/DatabaseFixture.ps1"
$root = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
$output = "$root/direct"
if (!(Test-Path "$root/server-before.json") -or (Test-Path $output)) { throw 'Record conditions first; direct pass must be new' }
New-Item "$output/source" -ItemType Directory -Force | Out-Null
Copy-Item "$PSScriptRoot/*SqlServer*.ps1","$PSScriptRoot/DatabaseFixture.ps1" "$output/source"
$monitor = Start-Job -FilePath "$PSScriptRoot/Watch-SqlServerHost.ps1" -ArgumentList $output
Get-Random -SetSeed 1108 | Out-Null
try {
    while (!(Test-Path "$output/monitor-ready.txt")) {
        if ($monitor.State -eq 'Failed') { $monitor | Receive-Job; throw 'Monitor failed' }
        Start-Sleep -Milliseconds 25
    }
    foreach ($shape in @(@(1000,256),@(10000,256),@(10000,2048))) {
        $count,$size = $shape; $label = "n$count-p$size"
        $fixture = @(New-BenchmarkFixture $count $size)
        $filter = @($fixture.Record | Where-Object { $_.Category -eq 'group-2' -and $_.Enabled -eq 1 })
        $database = Get-SqlServerDatabaseName $Pass $label
        Initialize-SqlServerDatabase $database $fixture
        $connection = Open-SqlServerDatabase $database
        try {
            $cases = 'row-key','document-key','row-filter','document-filter-index','row-offset','row-seek','row-projection','document-projection'
            $conditions = [ordered]@{
                Database = $database; Shape = $label; Rows = $count; PayloadCharacters = $size
                Provider = $connection.GetType().Assembly.FullName
                Settings = @(Invoke-SqlServerSql $connection 'SELECT name,value,value_in_use FROM sys.configurations ORDER BY name')
                Identity = Invoke-SqlServerSql $connection "SELECT ORIGINAL_LOGIN() AS login_name,CONNECTIONPROPERTY('net_transport') AS transport,CONNECTIONPROPERTY('local_net_address') AS address,CONNECTIONPROPERTY('local_tcp_port') AS port,CONNECTIONPROPERTY('auth_scheme') AS authentication"
                DatabaseOptions = @(Invoke-SqlServerSql $connection 'SELECT name,compatibility_level,recovery_model_desc,page_verify_option_desc,delayed_durability_desc,is_read_committed_snapshot_on,snapshot_isolation_state_desc,is_accelerated_database_recovery_on FROM sys.databases WHERE database_id=DB_ID()')
                SessionOptions = @(Invoke-SqlServerSql $connection 'DBCC USEROPTIONS')
                Plans = @{}
            }
            foreach ($case in $cases) {
                $query=(Get-SqlServerQuery $case $count).Replace('@id',"$([int]($count/2))").Replace('@category',"N'group-2'").Replace('@after',"$([int]($count/2))")
                $conditions.Plans[$case]=@(Get-SqlServerPlan $connection $query)
            }
            foreach ($block in 0..$Repetitions) {
                $plan = @(foreach ($case in $cases) { foreach ($mode in 'reuse','new','pooled') { @{ Case=$case; Mode=$mode } } }) | Get-Random -Shuffle
                foreach ($entry in $plan) {
                    if ($entry.Case -eq 'document-filter-index' -and $entry.Mode -eq 'reuse') { continue }
                    $parameters = @{ Database=$database; Case=$entry.Case; Count=$count; Pooling=($entry.Mode -eq 'pooled') }
                    if ($entry.Mode -eq 'reuse') { $parameters.Connection = $connection }
                    $elapsed = Measure-Command { $result = Read-SqlServerRecord @parameters }
                    $serialization = Measure-Command { $json = ConvertTo-Json -InputObject $result.Records -Depth 5 -Compress }
                    $expected = switch -Wildcard ($entry.Case) {
                        '*-key' { @($fixture[[int]($count/2)-1].Record) }
                        row-offset { @($filter | Select-Object -Skip ([int]($count/40)) -First 20) }
                        row-seek { @($filter | Where-Object Id -gt ($count/2) | Select-Object -First 20) }
                        default { $filter }
                    }
                    $fields = if ($entry.Case -like '*-projection') { 'Id','Name','Cpu' } else { 'Id','Name','Category','Enabled','Cpu','Payload','Revision' }
                    Assert-BenchmarkRecord $result.Records @($expected) -Fields $fields
                    @{ Shape=$label; Case=$entry.Case; Mode=$entry.Mode; Block=$block; Warmup=($block -eq 0); ClientMs=$elapsed.TotalMilliseconds; SerializeMs=$serialization.TotalMilliseconds; JsonCharacters=$json.Length; Rows=$result.Records.Count; Correct=$true } |
                        ConvertTo-Json -Depth 5 -Compress | Add-Content "$output/reads.jsonl"
                }
            }
            # Counterbalanced pairs isolate index presence from a fixed phase order.
            $indexPresent = $true
            $conditions.IndexComparison = @()
            foreach ($block in 0..$Repetitions) {
                $order = if ($block % 2) { 'scan','indexed' } else { 'indexed','scan' }
                $position = 0
                foreach ($condition in $order) {
                    $position++
                    $wantIndex = $condition -eq 'indexed'
                    if ($wantIndex -ne $indexPresent) {
                        $sql = if ($wantIndex) { "CREATE INDEX documents_filter ON documents(Category,Enabled,Id)" } else { 'DROP INDEX documents_filter ON documents' }
                        $null = Invoke-SqlServerSql $connection $sql
                        $indexPresent = $wantIndex
                    }
                    $null = Invoke-SqlServerSql $connection 'UPDATE STATISTICS documents WITH FULLSCAN'
                    $case = if ($wantIndex) { 'document-filter-index' } else { 'document-filter-scan' }
                    if (!$wantIndex -and !$conditions.Plans.ContainsKey('document-filter-scan')) {
                        $scanQuery = (Get-SqlServerQuery document-filter-index $count).Replace('@category',"'group-2'")
                        $conditions.Plans.'document-filter-scan' = @(Get-SqlServerPlan $connection $scanQuery)
                    }
                    for ($warmup = 0; $warmup -lt 10; $warmup++) {
                        $prepared = Read-SqlServerRecord -Connection $connection -Case document-filter-index -Count $count
                        Assert-BenchmarkRecord $prepared.Records $filter
                    }
                    $elapsed = Measure-Command { $result = Read-SqlServerRecord -Connection $connection -Case document-filter-index -Count $count }
                    $serialization = Measure-Command { $json = ConvertTo-Json -InputObject $result.Records -Depth 5 -Compress }
                    Assert-BenchmarkRecord $result.Records $filter
                    @{ Shape=$label; Case=$case; Mode='reuse'; Block=$block; Warmup=($block -eq 0); ClientMs=$elapsed.TotalMilliseconds; SerializeMs=$serialization.TotalMilliseconds; JsonCharacters=$json.Length; Rows=$result.Records.Count; PairOrder=($order -join ','); PairPosition=$position; ConditionWarmups=10; Correct=$true } |
                        ConvertTo-Json -Compress | Add-Content "$output/reads.jsonl"
                    $conditions.IndexComparison += @{ Block=$block; Condition=$condition; Order=($order -join ','); WarmupOperations=10; IndexPresent=$indexPresent }
                }
            }
            if (!$indexPresent) { $null = Invoke-SqlServerSql $connection "CREATE INDEX documents_filter ON documents(Category,Enabled,Id)" }
            $batch = @($fixture | Select-Object -First 100)
            $batchJson = ConvertTo-Json -InputObject @($batch.Record) -Depth 5 -Compress
            foreach ($block in 0..$Repetitions) {
                foreach ($case in ('rows','documents','refresh-rows','refresh-documents','autocommit-rows','rows-set','refresh-rows-set','refresh-documents-set' | Get-Random -Shuffle)) {
                    $null = Invoke-SqlServerSql $connection 'TRUNCATE TABLE batch_records; TRUNCATE TABLE batch_documents'
                    if ($case -like 'refresh-rows*') { $null = Write-SqlServerBatch $connection $batch rows batch_records }
                    if ($case -like 'refresh-documents*') { $null = Write-SqlServerBatch $connection $batch documents batch_documents }
                    $table = if ($case -like '*documents*') { 'batch_documents' } else { 'batch_records' }
                    $kind = if ($case -eq 'autocommit-rows') { 'rows' } else { $case }
                    $elapsed = Measure-Command { $result = Write-SqlServerBatch $connection $batch $kind $table -Autocommit:($case -eq 'autocommit-rows') -BatchJson $batchJson }
                    $actual = @(Invoke-SqlServerSql $connection "SELECT * FROM $table ORDER BY Id")
                    if ($table -eq 'batch_documents') { $actual = @($actual | ForEach-Object { $_.Body | ConvertFrom-Json }) }
                    $expected = @($batch | ForEach-Object { $record=$_.Record | Select-Object *; if ($case -like 'refresh-*') { $record.Revision=1 }; $record })
                    Assert-BenchmarkRecord $actual $expected
                    if ($result.Affected -ne 100) { throw 'Wrong affected count' }
                    @{ Shape=$label; Case=$case; Block=$block; Warmup=($block -eq 0); ClientMs=$elapsed.TotalMilliseconds; Rows=$result.Affected; Correct=$true } |
                        ConvertTo-Json -Compress | Add-Content "$output/writes.jsonl"
                }
            }
            $conditions.Storage = @(Invoke-SqlServerSql $connection "SELECT name,type_desc,physical_name,size*8192.0 AS allocated_bytes,growth,is_percent_growth FROM sys.database_files")
            $conditions | ConvertTo-Json -Depth 30 | Set-Content "$output/$label-conditions.json"
        } finally { $connection.Dispose() }
        Write-Output "Completed $label; all results checked."
    }
} finally {
    Set-Content "$output/monitor-stop.txt" 'stop'
    $null = $monitor | Wait-Job -Timeout 5
    $monitor | Receive-Job
    $monitor | Stop-Job
    $monitor | Remove-Job
}
Write-Output "Direct SQL Server evidence: $output"


