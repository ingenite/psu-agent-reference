<#
.SYNOPSIS
Temporarily registers SQL Server benchmark endpoints/imports in dedicated dev-psu.
.PARAMETER Pass
Existing evidence pass, retaining original registrations and installed hashes.
.PARAMETER Restore
Restores original registrations only if installed files have not changed.
.NOTES
Experimental. Uses the designated vaulted dev-psu management token. SQL mode
uses the temporary file created by Initialize-SqlServerLogin; restore removes it.
Only C:/dev-psu/Repository and that file are changed. Unregistered scripts/job
history remain. Direct workloads can retain the password in their process environment.
#>
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]{1,24}$')][string] $Pass,[switch] $Restore)
$ErrorActionPreference='Stop'
$root="C:/repos/psu-agent-reference/tools/output/database/$Pass"
if (!(Test-Path "$root/metadata.json")) { throw 'Record conditions first' }
$repository='C:/dev-psu/Repository'; $backup="$root/preview-backup"; $files='endpoints.ps1','scripts.ps1'
$token=Get-Secret -Name dev-psu-codex-mgmt-api -AsPlainText
$headers=@{ Authorization="Bearer $token" }
$schema=Invoke-RestMethod http://127.0.0.1:5100/swagger/v1/swagger.json -Headers $headers -MaximumRedirection 0
if (!$schema.paths.'/api/v1/configuration/sync/{configurationFile}'.put) { throw 'Reload route unavailable' }
if ($Restore) {
    if (Test-Path "$backup/restored.txt") { throw 'Already restored' }
    $installed=Get-Content "$backup/installed.json" -Raw | ConvertFrom-Json
    foreach ($file in $files) { if ((Get-FileHash "$repository/.universal/$file").Hash -ne $installed.$file) { throw "Preview changed: $file" } }
    foreach ($file in $files) { Copy-Item "$backup/$file" "$repository/.universal/$file" -Force }
} else {
    if (Test-Path $backup) { throw 'Inspect existing preview backup' }
    New-Item $backup -ItemType Directory | Out-Null
    New-Item "$repository/scripts/benchmarks/database" -ItemType Directory -Force | Out-Null
    foreach ($file in $files) { Copy-Item "$repository/.universal/$file" "$backup/$file" }
    Copy-Item "$PSScriptRoot/SqlServer.ps1","$PSScriptRoot/Invoke-SqlServerEndpoint.ps1","$PSScriptRoot/Invoke-SqlServerImport.ps1" "$repository/scripts/benchmarks/database" -Force
    Add-Content "$repository/.universal/endpoints.ps1" @'
New-PSUEndpoint -Url '/api/par-sqlserver-benchmark' -Method POST -Environment Integrated -Authentication -Endpoint {
    & 'C:/dev-psu/Repository/scripts/benchmarks/database/Invoke-SqlServerEndpoint.ps1' -RequestJson $Body
}
'@
    Add-Content "$repository/.universal/scripts.ps1" @'
New-PSUScript -Name 'Invoke-SqlServerImport.ps1' -Path 'benchmarks/database/Invoke-SqlServerImport.ps1' -Environment 'PowerShell 7' -MaxHistory 40
'@
    $hashes=@{}; foreach ($file in $files) { $hashes[$file]=(Get-FileHash "$repository/.universal/$file").Hash }
    $hashes | ConvertTo-Json | Set-Content "$backup/installed.json"
}
foreach ($file in $files) { $null=Invoke-RestMethod "http://127.0.0.1:5100/api/v1/configuration/sync/$file" -Method Put -Headers $headers -MaximumRedirection 0 }
if ($Restore) {
    foreach ($file in $files) { if ((Get-FileHash "$backup/$file").Hash -ne (Get-FileHash "$repository/.universal/$file").Hash) { throw "Restore differs: $file" } }
    if (Test-Path C:/dev-psu/sqlserver-benchmark-password.txt) { Remove-Item -LiteralPath C:/dev-psu/sqlserver-benchmark-password.txt }
    if (Test-Path C:/dev-psu/sqlserver-benchmark-login.txt) { Remove-Item -LiteralPath C:/dev-psu/sqlserver-benchmark-login.txt }
    Set-Content "$backup/restored.txt" (Get-Date).ToUniversalTime().ToString('o')
}
Write-Output "SQL Server preview updated: $backup"
