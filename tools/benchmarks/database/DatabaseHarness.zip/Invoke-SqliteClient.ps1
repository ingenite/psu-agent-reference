# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Measures a complete SQLite endpoint request through usable deserialized objects.
.PARAMETER Request
Prepared benchmark request hashtable. Serialization of this request is outside timing.
.PARAMETER Headers
In-memory authentication headers for loopback dev-psu only; never saved.
#>
param([hashtable] $Request, [hashtable] $Headers)
$ErrorActionPreference = 'Stop'
$body = $Request | ConvertTo-Json -Compress
# Owner approved .NET Stopwatch for this SQLite experiment.
$timer = [System.Diagnostics.Stopwatch]::StartNew()
$response = Invoke-WebRequest http://127.0.0.1:5100/api/par-sqlite-benchmark -Method Post -Headers $Headers -ContentType application/json -Body $body -MaximumRedirection 0
$httpMs = $timer.Elapsed.TotalMilliseconds
$result = $response.Content | ConvertFrom-Json -Depth 15
[pscustomobject]@{ ClientMs = $timer.Elapsed.TotalMilliseconds; HttpMs = $httpMs; ParseMs = $timer.Elapsed.TotalMilliseconds - $httpMs; ResponseBytes = $response.RawContentLength; Response = @($result)[0] }
