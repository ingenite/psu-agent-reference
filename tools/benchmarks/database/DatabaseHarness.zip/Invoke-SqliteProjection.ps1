# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Measures the selected-property result: the same 500 Id/Name/Cpu objects from rows or JSON.
.PARAMETER Pass
Existing direct evidence pass with preview installed. Creates projection/ once.
.NOTES
Seven measured shuffled blocks after warm-up, 10,000 records with 256/2,048-character
payloads. Direct reuse/new connections and complete endpoint clients are retained.
#>
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]+$')][string] $Pass)
. "$PSScriptRoot/Sqlite.ps1"
$root = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
$output = "$root/projection"
if (Test-Path $output) { throw 'Projection pass exists' }
New-Item "$output/source" -ItemType Directory -Force | Out-Null
Copy-Item "$PSScriptRoot/*.ps1" "$output/source"
$token = Get-Secret -Name dev-psu-codex-mgmt-api -AsPlainText
$headers = @{ Authorization = "Bearer $token" }
$monitor = Start-Job -FilePath "$PSScriptRoot/Watch-BenchmarkHost.ps1" -ArgumentList $output
Get-Random -SetSeed 1108 | Out-Null
try {
    foreach ($size in 256,2048) {
        $shape = "n10000-p$size"
        $fixture = @(New-BenchmarkFixture 10000 $size)
        $expected = @($fixture.Record | Where-Object { $_.Category -eq 'group-2' -and $_.Enabled -eq 1 } | Select-Object Id,Name,Cpu)
        $connection = Open-BenchmarkDatabase "$root/$shape.db"
        try {
            foreach ($block in 0..7) {
                $plan = @(foreach ($case in 'row-projection','document-projection') { foreach ($location in 'reuse','new','endpoint') { @{ Case = $case; Location = $location } } }) | Get-Random -Shuffle
                foreach ($entry in $plan) {
                    if ($entry.Location -eq 'endpoint') {
                        $client = & "$PSScriptRoot/Invoke-SqliteClient.ps1" -Request @{ Pass = $Pass; Shape = $shape; Case = $entry.Case } -Headers $headers
                        $result = $client.Response.Result
                        $totalMs = $client.ClientMs
                        $bytes = $client.ResponseBytes
                    } else {
                        $parameters = @{ Path = "$root/$shape.db"; Case = $entry.Case; Count = 10000 }
                        if ($entry.Location -eq 'reuse') { $parameters.Connection = $connection }
                        $result = Read-BenchmarkRecord @parameters
                        $totalMs = $result.Metrics.TotalMs
                        $bytes = $result.Metrics.JsonCharacters
                    }
                    Assert-BenchmarkRecord @($result.Records) $expected -Fields Id,Name,Cpu
                    @{ Shape = $shape; Block = $block; Warmup = ($block -eq 0); Case = $entry.Case; Location = $entry.Location; TotalMs = $totalMs; Metrics = $result.Metrics; ResponseBytesOrAsciiCharacters = $bytes; Correct = $true } |
                        ConvertTo-Json -Depth 6 -Compress | Add-Content "$output/samples.jsonl"
                }
            }
        } finally { $connection.Dispose() }
    }
} finally {
    Set-Content "$output/monitor-stop.txt" 'stop'
    $null = $monitor | Wait-Job -Timeout 5
    $monitor | Receive-Job
    $monitor | Stop-Job
    $monitor | Remove-Job
}
Write-Output "Projection results checked: $output"
