# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Records outer client clocks as well as internal stages for direct SQLite operations.
.PARAMETER Pass
Existing fixture pass. Creates client-boundary/ once; supersedes sequential direct
read/write totals for reporting, retaining the original raw stage measurements.
.NOTES
Includes helper invocation/return and owned-connection cleanup in ClientMs. Optional
JSON serialization and all validation occur after that clock. Seven shuffled blocks
follow a warm-up. Only the dedicated batch tables are reset; main fixtures are unchanged.
#>
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]+$')][string] $Pass)
. "$PSScriptRoot/Sqlite.ps1"
$root = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
$output = "$root/client-boundary"
if (Test-Path $output) { throw 'Client-boundary pass exists' }
New-Item "$output/source" -ItemType Directory -Force | Out-Null
Copy-Item "$PSScriptRoot/*.ps1" "$output/source"
$monitor = Start-Job -FilePath "$PSScriptRoot/Watch-BenchmarkHost.ps1" -ArgumentList $output
Get-Random -SetSeed 1108 | Out-Null
try {
    while (!(Test-Path "$output/monitor-ready.txt")) {
        if ($monitor.State -eq 'Failed') { $monitor | Receive-Job; throw 'Monitor failed' }
        Start-Sleep -Milliseconds 25
    }
    foreach ($shape in @(@(1000,256),@(10000,256),@(10000,2048))) {
        $count,$size = $shape
        $label = "n$count-p$size"
        $database = "$root/$label.db"
        $fixture = @(New-BenchmarkFixture $count $size)
        $filter = @($fixture.Record | Where-Object { $_.Category -eq 'group-2' -and $_.Enabled -eq 1 })
        $connection = Open-BenchmarkDatabase $database
        try {
            foreach ($block in 0..7) {
                $plan = @(foreach ($case in 'row-key','document-key','row-filter','document-filter-scan','document-filter-index','row-offset','row-seek','row-projection','document-projection') { foreach ($mode in 'reuse','new') { @{ Case = $case; Mode = $mode } } }) | Get-Random -Shuffle
                foreach ($entry in $plan) {
                    $parameters = @{ Path = $database; Case = $entry.Case; Count = $count; SkipSerialization = $true }
                    if ($entry.Mode -eq 'reuse') { $parameters.Connection = $connection }
                    # Owner approved .NET Stopwatch and SQLite APIs for this experiment.
                    $timer = [System.Diagnostics.Stopwatch]::StartNew()
                    $result = Read-BenchmarkRecord @parameters
                    $clientMs = $timer.Elapsed.TotalMilliseconds
                    $timer.Restart()
                    $json = ConvertTo-Json -InputObject $result.Records -Depth 5 -Compress
                    $result.Metrics.SerializeMs = $timer.Elapsed.TotalMilliseconds
                    $result.Metrics.JsonCharacters = $json.Length
                    $expected = switch -Wildcard ($entry.Case) {
                        '*-key' { @($fixture[[int]($count / 2) - 1].Record) }
                        row-offset { @($filter | Select-Object -Skip ([int]($count / 40)) -First 20) }
                        row-seek { @($filter | Where-Object Id -gt ($count / 2) | Select-Object -First 20) }
                        default { $filter }
                    }
                    $fields = if ($entry.Case -like '*-projection') { 'Id','Name','Cpu' } else { 'Id','Name','Category','Enabled','Cpu','Payload','Revision' }
                    Assert-BenchmarkRecord $result.Records @($expected) -Fields $fields
                    @{ Shape = $label; Case = $entry.Case; Mode = $entry.Mode; Block = $block; Warmup = ($block -eq 0); ClientMs = $clientMs; Metrics = $result.Metrics; Correct = $true } |
                        ConvertTo-Json -Depth 6 -Compress | Add-Content "$output/reads.jsonl"
                }
            }
            $batch = @($fixture | Select-Object -First 100)
            foreach ($block in 0..7) {
                foreach ($case in ('rows','documents','refresh-rows','refresh-documents','autocommit-rows' | Get-Random -Shuffle)) {
                    $null = Invoke-BenchmarkSql $connection 'DELETE FROM batch_records; DELETE FROM batch_documents'
                    if ($case -eq 'refresh-rows') { $null = Write-BenchmarkBatch $connection $batch rows batch_records }
                    if ($case -eq 'refresh-documents') { $null = Write-BenchmarkBatch $connection $batch documents batch_documents }
                    $table = if ($case -like '*documents') { 'batch_documents' } else { 'batch_records' }
                    $kind = if ($case -eq 'autocommit-rows') { 'rows' } else { $case }
                    $timer = [System.Diagnostics.Stopwatch]::StartNew()
                    $result = Write-BenchmarkBatch $connection $batch $kind $table -Autocommit:($case -eq 'autocommit-rows')
                    $clientMs = $timer.Elapsed.TotalMilliseconds
                    $actual = @(Invoke-BenchmarkSql $connection "SELECT * FROM $table ORDER BY Id")
                    if ($table -eq 'batch_documents') { $actual = @($actual | ForEach-Object { $_.Body | ConvertFrom-Json }) }
                    $expected = @($batch | ForEach-Object { $record = $_.Record | Select-Object *; if ($case -like 'refresh-*') { $record.Revision = 1 }; $record })
                    Assert-BenchmarkRecord $actual $expected
                    if ($result.Affected -ne 100) { throw 'Wrong affected count' }
                    @{ Shape = $label; Case = $case; Block = $block; Warmup = ($block -eq 0); ClientMs = $clientMs; Metrics = $result; Correct = $true } |
                        ConvertTo-Json -Depth 5 -Compress | Add-Content "$output/writes.jsonl"
                }
            }
        } finally { $connection.Dispose() }
    }
} finally {
    Set-Content "$output/monitor-stop.txt" 'stop'
    $null = $monitor | Wait-Job -Timeout 5
    $monitor | Receive-Job
    $monitor | Stop-Job
    $monitor | Remove-Job
}
Write-Output "Outer client boundaries and results checked: $output"
