# Experimental only. Identical fixture and equality contract to the completed SQLite pass.
function New-BenchmarkFixture {
    param([int] $Count, [int] $PayloadSize, [int] $Seed = 1108)
    # Stable arithmetic fields and exact ASCII payload length; no live inventory.
    $payload = 'x' * $PayloadSize
    for ($id = 1; $id -le $Count; $id++) {
        $record = [pscustomobject][ordered]@{
            Id = $id; Name = 'process-{0:D6}' -f $id; Category = "group-$($id % 10)"
            Enabled = [int]($id % 4 -ne 0); Cpu = ($id * 37 + $Seed) % 1000
            Payload = $payload; Revision = 0
        }
        [pscustomobject]@{ Record = $record; Json = $record | ConvertTo-Json -Compress }
    }
}

function Assert-BenchmarkRecord {
    param([array] $Actual, [array] $Expected, [string[]] $Fields = @('Id','Name','Category','Enabled','Cpu','Payload','Revision'))
    if ($Actual.Count -ne $Expected.Count) { throw "Wrong record count: $($Actual.Count) / $($Expected.Count)" }
    for ($i = 0; $i -lt $Expected.Count; $i++) {
        foreach ($field in $Fields) {
            if ($Actual[$i].$field -cne $Expected[$i].$field) { throw "Wrong $field at index $i" }
        }
    }
}
