# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Imports a prepared 1,000-record JSON fixture into the dedicated benchmark batch table.
.PARAMETER Pass
Existing tools/output/database pass containing n10000-p256.db and import-fixture.json.
.NOTES
For direct or PSU automation execution. Fixture decoding is outside the database timer
and inside the complete script/client operation. Deletes only the dedicated batch table.
#>
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]+$')][string] $Pass)
# Owner approved .NET Stopwatch and SQLite APIs for this SQLite experiment.
$scriptTimer = [System.Diagnostics.Stopwatch]::StartNew()
. "$PSScriptRoot/Sqlite.ps1"
$output = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
$fixture = @(Get-Content "$output/import-fixture.json" -Raw | ConvertFrom-Json)
$connection = Open-BenchmarkDatabase "$output/n10000-p256.db"
try {
    $null = Invoke-BenchmarkSql $connection 'DELETE FROM batch_records'
    $result = Write-BenchmarkBatch $connection $fixture rows batch_records
} finally { $connection.Dispose() }
# One JSON string preserves the metrics through this instance's saved pipeline output.
[pscustomobject]@{ Metrics = $result; ScriptMs = $scriptTimer.Elapsed.TotalMilliseconds; PowerShell = "$($PSVersionTable.PSVersion)" } | ConvertTo-Json -Depth 5 -Compress
