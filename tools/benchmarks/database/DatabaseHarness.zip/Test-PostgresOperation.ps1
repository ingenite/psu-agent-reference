# Experimental only.
<#
.SYNOPSIS
Checks PostgreSQL isolation, row locks, rollback, backup, restore and relation integrity.
.PARAMETER Pass
Existing evidence pass. Creates operations/ and two dedicated databases once.
.PARAMETER AdministrativeRole
Discovered role used for database creation and pg_amcheck extension installation.
.NOTES
Requires PGPASSWORD and native PostgreSQL tools. Uses explicit TCP loopback.
These checks do not simulate crashes, power loss, recovery time or production
permissions. Logical dump/restore is distinct from physical/PITR backup.
#>
param(
    [Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]{1,24}$')][string] $Pass,
    [Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9_]+$')][string] $AdministrativeRole,
    [string] $Bin = 'C:/Program Files/PostgreSQL/18/bin'
)
. "$PSScriptRoot/Postgres.ps1"
. "$PSScriptRoot/DatabaseFixture.ps1"
$root = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
$output = "$root/operations"
if (Test-Path $output) { throw 'Operational pass exists' }
New-Item "$output/source" -ItemType Directory -Force | Out-Null
Copy-Item "$PSScriptRoot/*Postgres*.ps1","$PSScriptRoot/DatabaseFixture.ps1" "$output/source"
$database = Get-PostgresDatabaseName $Pass operations
$restore = Get-PostgresDatabaseName $Pass restore
$fixture = @(New-BenchmarkFixture 1000 256)
Initialize-PostgresDatabase $database $fixture $AdministrativeRole
$first = Open-PostgresDatabase $database
$second = Open-PostgresDatabase $database
$checks = [ordered]@{}
try {
    $null = Write-PostgresBatch $second $fixture rows batch_records
    $null = Invoke-PostgresSql $first 'BEGIN ISOLATION LEVEL REPEATABLE READ'
    $before = Invoke-PostgresSql $first 'SELECT sum(Revision) AS revisions FROM batch_records'
    $null = Invoke-PostgresIncrement $second
    $during = Invoke-PostgresSql $first 'SELECT sum(Revision) AS revisions FROM batch_records'
    $null = Invoke-PostgresSql $first 'COMMIT'
    $after = Invoke-PostgresSql $first 'SELECT sum(Revision) AS revisions FROM batch_records'
    if ($before.revisions -ne 0 -or $during.revisions -ne 0 -or $after.revisions -ne 10) { throw 'Repeatable read failed' }
    $checks.RepeatableRead = @{ Before=0; During=0; After=10; Correct=$true }
    $null = Invoke-PostgresSql $first 'BEGIN; UPDATE batch_records SET Revision=Revision+1000 WHERE Id=1'
    try {
        $null = Invoke-PostgresSql $second "SET lock_timeout='250ms'"
        $otherKey = Measure-Command { $null = Invoke-PostgresSql $second 'UPDATE batch_records SET Revision=Revision+1 WHERE Id=2' }
        $state = $null
        $sameKey = Measure-Command {
            try { $null = Invoke-PostgresSql $second 'UPDATE batch_records SET Revision=Revision+1 WHERE Id=1' }
            catch { $state=$_.Exception.InnerException.SqlState; $message=$_.Exception.Message }
        }
        if ($state -ne '55P03') { throw "Expected row-lock timeout: $message" }
        $checks.RowLocks = @{ HeldKey=1; IndependentKey=2; IndependentWriteMs=$otherKey.TotalMilliseconds; ConflictingWriteMs=$sameKey.TotalMilliseconds; LockTimeoutMs=250; SqlState=$state; Correct=$true }
    } finally { $null = Invoke-PostgresSql $first 'ROLLBACK' }
    $sum = Invoke-PostgresSql $first 'SELECT sum(Revision) AS revisions FROM batch_records'
    if ($sum.revisions -ne 11) { throw 'Rollback/independent write check failed' }
    $checks.Rollback = @{ Revisions=11; Correct=$true }
    $null = Invoke-PostgresSql $first 'BEGIN ISOLATION LEVEL READ COMMITTED'
    $before = Invoke-PostgresSql $first 'SELECT sum(Revision) AS revisions FROM batch_records'
    $null = Invoke-PostgresIncrement $second
    $during = Invoke-PostgresSql $first 'SELECT sum(Revision) AS revisions FROM batch_records'
    $null = Invoke-PostgresSql $first 'COMMIT'
    if ($before.revisions -ne 11 -or $during.revisions -ne 21) { throw 'Read committed visibility failed' }
    $checks.ReadCommitted = @{ Before=11; During=21; Correct=$true }
} finally { $first.Dispose(); $second.Dispose() }
$backup = "$output/backup.dump"
$dumpTime = Measure-Command {
    & "$Bin/pg_dump.exe" -w -h 127.0.0.1 -p 5432 -U par_benchmark -d $database -F c -f $backup 2> "$output/dump.log"
    if ($LASTEXITCODE) { throw 'pg_dump failed' }
}
$admin = Open-PostgresDatabase postgres -Role $AdministrativeRole
try { $null = Invoke-PostgresSql $admin "CREATE DATABASE $restore OWNER par_benchmark" } finally { $admin.Dispose() }
$restoreTime = Measure-Command {
    & "$Bin/pg_restore.exe" -w -h 127.0.0.1 -p 5432 -U par_benchmark -d $restore --no-owner --no-acl --exit-on-error $backup 2> "$output/restore.log"
    if ($LASTEXITCODE) { throw 'pg_restore failed' }
}
$checks.BackupRestore = @{ BackupMs=$dumpTime.TotalMilliseconds; RestoreMs=$restoreTime.TotalMilliseconds; Bytes=(Get-Item $backup).Length; Correct=$true }
foreach ($name in $database,$restore) {
    $connection = Open-PostgresDatabase $name
    try {
        Assert-BenchmarkRecord @(Invoke-PostgresSql $connection 'SELECT * FROM records ORDER BY Id') @($fixture.Record)
        $documents = @(Invoke-PostgresSql $connection 'SELECT Body::text FROM documents ORDER BY Id' | ForEach-Object { $_.body | ConvertFrom-Json })
        Assert-BenchmarkRecord $documents @($fixture.Record)
        $batch = @(Invoke-PostgresSql $connection 'SELECT * FROM batch_records ORDER BY Id')
        $expected = @($fixture | ForEach-Object { $record=$_.Record | Select-Object *; if ($record.Id -le 10) { $record.Revision=2 }; if ($record.Id -eq 2) { $record.Revision=3 }; $record })
        Assert-BenchmarkRecord $batch $expected
    } finally { $connection.Dispose() }
    & "$Bin/pg_amcheck.exe" -w -h 127.0.0.1 -p 5432 -U $AdministrativeRole --install-missing --heapallindexed --parent-check --checkunique --verbose $name *> "$output/$name-amcheck.txt"
    if ($LASTEXITCODE) { throw "pg_amcheck failed: $name" }
    $checks[$name] = @{ Records=1000; Documents=1000; BatchRecords=1000; Revisions=21; FieldEquality=$true; AmcheckExitCode=0; Correct=$true }
}
$checks | ConvertTo-Json -Depth 10 | Set-Content "$output/checks.json"
Write-Output "Operational PostgreSQL checks passed: $output/checks.json"
