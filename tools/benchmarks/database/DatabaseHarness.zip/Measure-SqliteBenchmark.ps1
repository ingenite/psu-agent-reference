# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Summarizes a completed SQLite pass into structured evidence, excluding warm-ups.
.PARAMETER Pass
Existing tools/output/database pass. Replaces summary.json only; raw files are unchanged.
.NOTES
Medians and observed ranges describe this pass. P95 uses nearest rank. Requests within
a burst are correlated; throughput counts each burst wall time once. Monitoring is
one-second host/process sampling, not attribution of subsecond operations.
#>
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]+$')][string] $Pass)
$ErrorActionPreference = 'Stop'
function Get-Distribution {
    param([double[]] $Values)
    $sorted = @($Values | Sort-Object)
    if (!$sorted.Count) { throw 'No distribution observations' }
    $middle = [int]($sorted.Count / 2)
    $median = if ($sorted.Count % 2) { $sorted[[int](($sorted.Count - 1) / 2)] } else { ($sorted[$middle - 1] + $sorted[$middle]) / 2 }
    $rank = 1
    while ($rank -lt (0.95 * $sorted.Count)) { $rank++ }
    [pscustomobject]@{ N = $sorted.Count; Min = $sorted[0]; Median = $median; P95 = $sorted[$rank - 1]; Max = $sorted[-1] }
}
$root = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
$clientReads = @(Get-Content "$root/client-boundary/reads.jsonl" | ConvertFrom-Json | Where-Object { !$_.Warmup })
$reads = @($clientReads | Where-Object Case -NotLike '*-projection')
$writes = @(Get-Content "$root/client-boundary/writes.jsonl" | ConvertFrom-Json | Where-Object { !$_.Warmup })
$endpoints = @(Get-Content "$root/followup/endpoints.jsonl" | ConvertFrom-Json | Where-Object { !$_.Warmup })
$imports = @(Get-Content "$root/followup/imports.jsonl" | ConvertFrom-Json | Where-Object { !$_.Warmup })
$bursts = @(Get-Content "$root/followup/bursts.jsonl" | ConvertFrom-Json | Where-Object { !$_.Warmup })
$projections = @(
    Get-Content "$root/projection/samples.jsonl" | ConvertFrom-Json | Where-Object { !$_.Warmup -and $_.Location -eq 'endpoint' }
    $clientReads | Where-Object { $_.Case -like '*-projection' -and $_.Shape -ne 'n1000-p256' } | ForEach-Object {
        [pscustomobject]@{ Shape = $_.Shape; Case = $_.Case; Location = $_.Mode; TotalMs = $_.ClientMs; Metrics = $_.Metrics; ResponseBytesOrAsciiCharacters = $_.Metrics.JsonCharacters }
    }
)
$control = @(Get-Content "$root/followup/control.jsonl" | ConvertFrom-Json)
$summary = [ordered]@{ Pass = $Pass; Unit = 'milliseconds except counts, bytes and operations/second'; WarmupsExcluded = $true
    Host = Get-Content "$root/host.json" -Raw | ConvertFrom-Json
    Metadata = Get-Content "$root/metadata.json" -Raw | ConvertFrom-Json
    PsuSettings = Get-Content "$root/psu-settings.json" -Raw | ConvertFrom-Json
    PsuConfigOverrides = Get-Content "$root/psu-config-overrides.json" -Raw | ConvertFrom-Json
    RuntimeConditions = Get-Content "$root/runtime-conditions.json" -Raw | ConvertFrom-Json
    Conditions = @(Get-ChildItem "$root/n*-conditions.json" | ForEach-Object { Get-Content $_ -Raw | ConvertFrom-Json })
    Reads = @($reads | Group-Object Shape,Case,Mode | ForEach-Object {
        $first = $_.Group[0]
        [pscustomobject]@{ Shape = $first.Shape; Case = $first.Case; Mode = $first.Mode
            TotalMs = Get-Distribution $_.Group.ClientMs; DatabaseObjectMs = Get-Distribution $_.Group.Metrics.TotalMs; OpenConfigureMs = Get-Distribution $_.Group.Metrics.OpenConfigureMs
            ExecuteReaderMs = Get-Distribution $_.Group.Metrics.ExecuteReaderMs; FetchObjectMs = Get-Distribution $_.Group.Metrics.FetchObjectMs
            SerializeMs = Get-Distribution $_.Group.Metrics.SerializeMs; Rows = $first.Metrics.Rows; JsonCharacters = $first.Metrics.JsonCharacters }
    })
    Writes = @($writes | Group-Object Shape,Case | ForEach-Object {
        $first = $_.Group[0]
        [pscustomobject]@{ Shape = $first.Shape; Case = $first.Case; TotalMs = Get-Distribution $_.Group.ClientMs; TransactionMs = Get-Distribution $_.Group.Metrics.TotalMs; CommitMs = Get-Distribution $_.Group.Metrics.CommitMs; Rows = $first.Metrics.Affected }
    })
    Endpoints = @($endpoints | Group-Object Shape,Case | ForEach-Object {
        $first = $_.Group[0]
        [pscustomobject]@{ Shape = $first.Shape; Case = $first.Case; ClientMs = Get-Distribution $_.Group.ClientMs
            HttpMs = Get-Distribution $_.Group.HttpMs; ParseMs = Get-Distribution $_.Group.ParseMs; HandlerMs = Get-Distribution $_.Group.HandlerMs
            DatabaseObjectMs = Get-Distribution $_.Group.Metrics.TotalMs; Rows = $first.Metrics.Rows; ResponseBytes = Get-Distribution $_.Group.Bytes; Engine = $first.Engine; PowerShell = $first.PowerShell }
    })
    Imports = @($imports | Group-Object Location | ForEach-Object {
        [pscustomobject]@{ Location = $_.Name; ClientMs = Get-Distribution $_.Group.ClientMs; CompletedMs = Get-Distribution $_.Group.CompletedMs
            DatabaseMs = Get-Distribution $_.Group.Result.Metrics.TotalMs; ScriptMs = Get-Distribution $_.Group.Result.ScriptMs; Rows = 1000 }
    })
    Bursts = @($bursts | Group-Object Location,Readers,Writers | ForEach-Object {
        $first = $_.Group[0]
        $workers = @($_.Group | ForEach-Object { Get-Content "$root/followup/$($_.WorkersFile)" -Raw | ConvertFrom-Json })
        [pscustomobject]@{ Location = $first.Location; Readers = $first.Readers; Writers = $first.Writers; IterationsPerWorker = $first.Iterations
            OperationsPerBurst = $first.Operations; Bursts = $_.Count; WallMs = Get-Distribution $_.Group.WallMs
            OperationsPerSecond = Get-Distribution @($_.Group | ForEach-Object { 1000 * $_.Operations / $_.WallMs })
            AllWorkersOverlapMs = Get-Distribution $_.Group.AllWorkersOverlapMs
            Roles = @($workers | Group-Object Role | ForEach-Object { [pscustomobject]@{ Role = $_.Name; ClientMs = Get-Distribution $_.Group.Samples.TotalMs; InternalMs = Get-Distribution $_.Group.Samples.InternalMs; Errors = @($_.Group.Samples | Where-Object Error).Count } }) }
    })
    Projection = @($projections | Group-Object Shape,Case,Location | ForEach-Object {
        $first = $_.Group[0]
        [pscustomobject]@{ Shape = $first.Shape; Case = $first.Case; Location = $first.Location; TotalMs = Get-Distribution $_.Group.TotalMs; Rows = $first.Metrics.Rows; ResponseBytesOrAsciiCharacters = Get-Distribution $_.Group.ResponseBytesOrAsciiCharacters }
    })
    OrchestrationControl = @($control | Group-Object Block | ForEach-Object {
        $quiet = $_.Group | Where-Object Condition -eq quiet
        $activity = $_.Group | Where-Object Condition -eq activity
        [pscustomobject]@{ Block = [int]$_.Name; Operations = 100; QuietWallMs = $quiet.WallMs; ActivityWallMs = $activity.WallMs; ChangePercent = 100 * ($activity.WallMs / $quiet.WallMs - 1); ActivityCycles = $(if ($activity.ActivityCycles.value) { $activity.ActivityCycles.value } else { $activity.ActivityCycles }) }
    })
    Operations = Get-Content "$root/operations/checks.json" -Raw | ConvertFrom-Json
    Files = @(Get-ChildItem "$root/*.db" | Select-Object Name,Length)
}
$summary.Monitoring = @(foreach ($phase in '.', 'followup','projection','client-boundary') {
    $samples = @(Get-Content "$root/$phase/monitoring.jsonl" | ConvertFrom-Json)
    [pscustomobject]@{ Phase = $phase; Samples = $samples.Count; FirstUtc = $samples[0].Utc; LastUtc = $samples[-1].Utc
        Counters = @($samples.Counters | Group-Object Path | ForEach-Object { [pscustomobject]@{ Path = $_.Name; Values = Get-Distribution $_.Group.CookedValue } })
        Processes = @($samples.Processes | Group-Object Id | ForEach-Object {
            [pscustomobject]@{ Id = [int]$_.Name; Name = $_.Group[0].ProcessName; CpuSecondsObserved = $_.Group[-1].CPU - $_.Group[0].CPU; PeakWorkingSetBytes = ($_.Group.WorkingSet64 | Measure-Object -Maximum).Maximum; PeakPrivateBytes = ($_.Group.PrivateMemorySize64 | Measure-Object -Maximum).Maximum }
        }) }
})
$summary | ConvertTo-Json -Depth 25 | Set-Content "$root/summary.json"
Write-Output "Structured summary: $root/summary.json"
