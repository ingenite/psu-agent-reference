# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Records native Windows PostgreSQL conditions before a benchmark pass.
.PARAMETER Pass
New evidence directory under tools/output/database. Never overwrites a pass.
.PARAMETER AdministrativeRole
Role discovered from the local installation record and verified by TCP login.
.NOTES
Set PGPASSWORD in the calling process to the owner-designated demonstration password.
Uses psql over explicit loopback. Saves no credentials. Requires Windows diagnostic
access. Records settings rather than tuning the installation for this small workload.
#>
param(
    [Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]{1,24}$')][string] $Pass,
    [Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9_]+$')][string] $AdministrativeRole,
    [string] $Bin = 'C:/Program Files/PostgreSQL/18/bin'
)
$ErrorActionPreference = 'Stop'
$output = Join-Path $PSScriptRoot "../../output/database/$Pass"
if (Test-Path $output) { throw "Pass exists: $Pass" }
New-Item "$output/source" -ItemType Directory -Force | Out-Null
Copy-Item "$PSScriptRoot/*Postgres*.ps1" "$output/source"
$sql = @'
SELECT json_build_object(
 'version',version(),'role',current_user,'address',inet_server_addr(),'port',inet_server_port(),
 'roles',(SELECT json_agg(r) FROM (SELECT rolname,rolsuper,rolcreatedb FROM pg_roles WHERE rolcanlogin) r),
 'settings',(SELECT json_agg(s) FROM (SELECT name,setting,unit,source,pending_restart FROM pg_settings
 WHERE name IN ('data_directory','config_file','hba_file','listen_addresses','port','max_connections',
 'shared_buffers','work_mem','maintenance_work_mem','effective_cache_size','max_worker_processes',
 'max_parallel_workers','max_parallel_workers_per_gather','fsync','synchronous_commit','full_page_writes',
 'wal_level','wal_sync_method','wal_compression','wal_buffers','max_wal_size','min_wal_size','checkpoint_timeout',
 'checkpoint_completion_target','autovacuum','autovacuum_max_workers','default_transaction_isolation',
 'default_toast_compression','block_size','data_checksums','ssl','server_encoding','lc_collate','lc_ctype',
 'random_page_cost','effective_io_concurrency','jit') ORDER BY name) s),
 'databases',(SELECT json_agg(d) FROM (SELECT datname,pg_encoding_to_char(encoding) AS encoding,datcollate,datctype FROM pg_database) d)
);
'@
$conditions = & "$Bin/psql.exe" -X -w -h 127.0.0.1 -p 5432 -U $AdministrativeRole -d postgres -v ON_ERROR_STOP=1 -A -t -c $sql
if ($LASTEXITCODE) { throw 'PostgreSQL discovery failed' }
$conditions | ConvertFrom-Json | ConvertTo-Json -Depth 12 | Set-Content "$output/server-before.json"
@{
    Utc = (Get-Date).ToUniversalTime().ToString('o'); AdministrativeRole = $AdministrativeRole
    Connection = 'TCP 127.0.0.1:5432; SCRAM password; SSL disabled in benchmark; no remote host'
    PowerShell = "$($PSVersionTable.PSVersion)"; BaseCommit = git rev-parse HEAD
    Runtime = (Get-Content "$PSHOME/pwsh.runtimeconfig.json" -Raw | ConvertFrom-Json).runtimeOptions
    Bin = $Bin; Seed = 1108; Repetitions = 7
    Protocol = 'review-corrected-v2'; WorkerWarmupOperations = 10; WriterLockOrder = 'Id ascending (FOR UPDATE subquery)'
    IndexComparison = 'Counterbalanced paired reuse reads; ten checked warm-ups after each condition change'
} | ConvertTo-Json -Depth 10 | Set-Content "$output/metadata.json"
@{
    Processor = Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors
    Computer = Get-CimInstance Win32_ComputerSystem | Select-Object TotalPhysicalMemory
    OS = Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber
    Disk = Get-Partition -DriveLetter C | Get-Disk | Select-Object Number,FriendlyName,BusType,Size
    Services = @(Get-CimInstance Win32_Service | Where-Object Name -match 'MSSQL|postgres' | Select-Object Name,State,PathName,StartName)
    PowerPlan = powercfg /getactivescheme
    Provider = Get-Item C:/dev-psu/Npgsql.dll | Select-Object FullName,@{ Name='Version'; Expression={$_.VersionInfo.FileVersion} }
    ProviderHash = Get-FileHash C:/dev-psu/Npgsql.dll | Select-Object Path,Hash
} | ConvertTo-Json -Depth 8 | Set-Content "$output/host.json"
Write-Output "Recorded PostgreSQL conditions: $output"
