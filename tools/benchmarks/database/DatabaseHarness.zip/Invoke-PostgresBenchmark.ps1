# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Creates dedicated PostgreSQL databases and measures checked useful PowerShell results.
.PARAMETER Pass
Existing pass created by Get-PostgresCondition. Creates direct/ once.
.PARAMETER AdministrativeRole
Discovered local administrative login, used only to create the role and databases.
.PARAMETER Repetitions
Shuffled measured blocks following one warm-up; default seven.
.NOTES
Set PGPASSWORD to the owner-designated demonstration password. Creates a
non-superuser par_benchmark login with that password and databases prefixed par_pg_.
Existing databases are never overwritten. Uses bundled Npgsql, explicit TCP
loopback, five-second command/connect timeouts and default durable settings.
Measure-Command clocks include helper call/return and owned connection disposal;
fixture preparation, JSON serialization and all field checks are outside clocks.
Index-present/absent reuse reads use counterbalanced pairs per block, with DDL,
statistics and ten checked warm-up reads per condition outside measurement.
#>
param(
    [Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]{1,24}$')][string] $Pass,
    [Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9_]+$')][string] $AdministrativeRole,
    [ValidateRange(1,15)][int] $Repetitions = 7
)
. "$PSScriptRoot/Postgres.ps1"
. "$PSScriptRoot/DatabaseFixture.ps1"
$root = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
$output = "$root/direct"
if (!(Test-Path "$root/server-before.json") -or (Test-Path $output)) { throw 'Record conditions first; direct pass must be new' }
New-Item "$output/source" -ItemType Directory -Force | Out-Null
Copy-Item "$PSScriptRoot/*Postgres*.ps1","$PSScriptRoot/DatabaseFixture.ps1" "$output/source"
$admin = Open-PostgresDatabase postgres -Role $AdministrativeRole
try {
    $exists = @(Invoke-PostgresSql $admin "SELECT rolname FROM pg_roles WHERE rolname='par_benchmark'")
    if (!$exists.Count) {
        $escapedPassword = (Get-PostgresPassword).Replace("'","''")
        $null = Invoke-PostgresSql $admin "CREATE ROLE par_benchmark LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE PASSWORD '$escapedPassword'"
    }
} finally { $admin.Dispose() }
$monitor = Start-Job -FilePath "$PSScriptRoot/Watch-PostgresHost.ps1" -ArgumentList $output
Get-Random -SetSeed 1108 | Out-Null
try {
    while (!(Test-Path "$output/monitor-ready.txt")) {
        if ($monitor.State -eq 'Failed') { $monitor | Receive-Job; throw 'Monitor failed' }
        Start-Sleep -Milliseconds 25
    }
    foreach ($shape in @(@(1000,256),@(10000,256),@(10000,2048))) {
        $count,$size = $shape; $label = "n$count-p$size"
        $fixture = @(New-BenchmarkFixture $count $size)
        $filter = @($fixture.Record | Where-Object { $_.Category -eq 'group-2' -and $_.Enabled -eq 1 })
        $database = Get-PostgresDatabaseName $Pass $label
        Initialize-PostgresDatabase $database $fixture $AdministrativeRole
        $connection = Open-PostgresDatabase $database
        try {
            $cases = 'row-key','document-key','row-filter','document-filter-index','row-offset','row-seek','row-projection','document-projection'
            $conditions = [ordered]@{
                Database = $database; Shape = $label; Rows = $count; PayloadCharacters = $size
                Provider = $connection.GetType().Assembly.FullName
                Settings = @(Invoke-PostgresSql $connection 'SELECT name,setting,unit FROM pg_settings ORDER BY name')
                Identity = Invoke-PostgresSql $connection 'SELECT current_user,inet_server_addr(),inet_server_port(),pg_backend_pid()'
                Plans = @{}
            }
            foreach ($case in $cases) {
                $query = (Get-PostgresQuery $case $count).Replace('@id',"$([int]($count/2))").Replace('@category',"'group-2'").Replace('@after',"$([int]($count/2))")
                $conditions.Plans[$case] = @(Invoke-PostgresSql $connection ("EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) $query"))
            }
            foreach ($block in 0..$Repetitions) {
                $plan = @(foreach ($case in $cases) { foreach ($mode in 'reuse','new','pooled') { @{ Case=$case; Mode=$mode } } }) | Get-Random -Shuffle
                foreach ($entry in $plan) {
                    if ($entry.Case -eq 'document-filter-index' -and $entry.Mode -eq 'reuse') { continue }
                    $parameters = @{ Database=$database; Case=$entry.Case; Count=$count; Pooling=($entry.Mode -eq 'pooled') }
                    if ($entry.Mode -eq 'reuse') { $parameters.Connection = $connection }
                    $elapsed = Measure-Command { $result = Read-PostgresRecord @parameters }
                    $serialization = Measure-Command { $json = ConvertTo-Json -InputObject $result.Records -Depth 5 -Compress }
                    $expected = switch -Wildcard ($entry.Case) {
                        '*-key' { @($fixture[[int]($count/2)-1].Record) }
                        row-offset { @($filter | Select-Object -Skip ([int]($count/40)) -First 20) }
                        row-seek { @($filter | Where-Object Id -gt ($count/2) | Select-Object -First 20) }
                        default { $filter }
                    }
                    $fields = if ($entry.Case -like '*-projection') { 'Id','Name','Cpu' } else { 'Id','Name','Category','Enabled','Cpu','Payload','Revision' }
                    Assert-BenchmarkRecord $result.Records @($expected) -Fields $fields
                    @{ Shape=$label; Case=$entry.Case; Mode=$entry.Mode; Block=$block; Warmup=($block -eq 0); ClientMs=$elapsed.TotalMilliseconds; SerializeMs=$serialization.TotalMilliseconds; JsonCharacters=$json.Length; Rows=$result.Records.Count; Correct=$true } |
                        ConvertTo-Json -Depth 5 -Compress | Add-Content "$output/reads.jsonl"
                }
            }
            # Counterbalanced pairs isolate index presence from a fixed phase order.
            $indexPresent = $true
            $conditions.IndexComparison = @()
            foreach ($block in 0..$Repetitions) {
                $order = if ($block % 2) { 'scan','indexed' } else { 'indexed','scan' }
                $position = 0
                foreach ($condition in $order) {
                    $position++
                    $wantIndex = $condition -eq 'indexed'
                    if ($wantIndex -ne $indexPresent) {
                        $sql = if ($wantIndex) { "CREATE INDEX documents_filter ON documents((Body->>'Category'), ((Body->>'Enabled')::integer), Id)" } else { 'DROP INDEX documents_filter' }
                        $null = Invoke-PostgresSql $connection $sql
                        $indexPresent = $wantIndex
                    }
                    $null = Invoke-PostgresSql $connection 'ANALYZE documents'
                    $case = if ($wantIndex) { 'document-filter-index' } else { 'document-filter-scan' }
                    if (!$wantIndex -and !$conditions.Plans.ContainsKey('document-filter-scan')) {
                        $scanQuery = (Get-PostgresQuery document-filter-index $count).Replace('@category',"'group-2'")
                        $conditions.Plans.'document-filter-scan' = @(Invoke-PostgresSql $connection "EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) $scanQuery")
                    }
                    for ($warmup = 0; $warmup -lt 10; $warmup++) {
                        $prepared = Read-PostgresRecord -Connection $connection -Case document-filter-index -Count $count
                        Assert-BenchmarkRecord $prepared.Records $filter
                    }
                    $elapsed = Measure-Command { $result = Read-PostgresRecord -Connection $connection -Case document-filter-index -Count $count }
                    $serialization = Measure-Command { $json = ConvertTo-Json -InputObject $result.Records -Depth 5 -Compress }
                    Assert-BenchmarkRecord $result.Records $filter
                    @{ Shape=$label; Case=$case; Mode='reuse'; Block=$block; Warmup=($block -eq 0); ClientMs=$elapsed.TotalMilliseconds; SerializeMs=$serialization.TotalMilliseconds; JsonCharacters=$json.Length; Rows=$result.Records.Count; PairOrder=($order -join ','); PairPosition=$position; ConditionWarmups=10; Correct=$true } |
                        ConvertTo-Json -Compress | Add-Content "$output/reads.jsonl"
                    $conditions.IndexComparison += @{ Block=$block; Condition=$condition; Order=($order -join ','); WarmupOperations=10; IndexPresent=$indexPresent }
                }
            }
            if (!$indexPresent) { $null = Invoke-PostgresSql $connection "CREATE INDEX documents_filter ON documents((Body->>'Category'), ((Body->>'Enabled')::integer), Id)" }
            $batch = @($fixture | Select-Object -First 100)
            $batchJson = ConvertTo-Json -InputObject @($batch.Record) -Depth 5 -Compress
            foreach ($block in 0..$Repetitions) {
                foreach ($case in ('rows','documents','refresh-rows','refresh-documents','autocommit-rows','rows-set','refresh-rows-set','refresh-documents-set' | Get-Random -Shuffle)) {
                    $null = Invoke-PostgresSql $connection 'TRUNCATE batch_records,batch_documents'
                    if ($case -like 'refresh-rows*') { $null = Write-PostgresBatch $connection $batch rows batch_records }
                    if ($case -like 'refresh-documents*') { $null = Write-PostgresBatch $connection $batch documents batch_documents }
                    $table = if ($case -like '*documents*') { 'batch_documents' } else { 'batch_records' }
                    $kind = if ($case -eq 'autocommit-rows') { 'rows' } else { $case }
                    $elapsed = Measure-Command { $result = Write-PostgresBatch $connection $batch $kind $table -Autocommit:($case -eq 'autocommit-rows') -BatchJson $batchJson }
                    $actual = @(Invoke-PostgresSql $connection "SELECT * FROM $table ORDER BY Id")
                    if ($table -eq 'batch_documents') { $actual = @($actual | ForEach-Object { $_.Body | ConvertFrom-Json }) }
                    $expected = @($batch | ForEach-Object { $record=$_.Record | Select-Object *; if ($case -like 'refresh-*') { $record.Revision=1 }; $record })
                    Assert-BenchmarkRecord $actual $expected
                    if ($result.Affected -ne 100) { throw 'Wrong affected count' }
                    @{ Shape=$label; Case=$case; Block=$block; Warmup=($block -eq 0); ClientMs=$elapsed.TotalMilliseconds; Rows=$result.Affected; Correct=$true } |
                        ConvertTo-Json -Compress | Add-Content "$output/writes.jsonl"
                }
            }
            $conditions.Storage = @(Invoke-PostgresSql $connection "SELECT relname,pg_relation_size(oid) AS heap_bytes,pg_total_relation_size(oid) AS total_bytes FROM pg_class WHERE relname IN ('records','documents','batch_records','batch_documents')")
            $conditions | ConvertTo-Json -Depth 30 | Set-Content "$output/$label-conditions.json"
        } finally { $connection.Dispose() }
        Write-Output "Completed $label; all results checked."
    }
} finally {
    Set-Content "$output/monitor-stop.txt" 'stop'
    $null = $monitor | Wait-Job -Timeout 5
    $monitor | Receive-Job
    $monitor | Stop-Job
    $monitor | Remove-Job
}
Write-Output "Direct PostgreSQL evidence: $output"
