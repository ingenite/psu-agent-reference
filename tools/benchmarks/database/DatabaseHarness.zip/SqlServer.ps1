# Experimental only; not reference material for creating production PSU resources.
# Owner approved SQL-client and timing .NET APIs for this bounded SQL Server phase.
$ErrorActionPreference = 'Stop'
if (!('Microsoft.Data.SqlClient.SqlConnection' -as [type])) { Add-Type -Path C:/dev-psu/Microsoft.Data.SqlClient.dll }

function Get-SqlServerDatabaseName {
    param([string] $Pass, [string] $Shape)
    if ($Pass -notmatch '^[a-zA-Z0-9-]{1,24}$' -or $Shape -notin 'n1000-p256','n10000-p256','n10000-p2048','operations','restore') { throw 'Invalid benchmark database name' }
    'par_sql_' + $Pass.Replace('-','_').ToLower() + '_' + $Shape.Replace('-','_')
}

function Open-SqlServerDatabase {
    param([string] $Database, [switch] $Pooling, [switch] $Administrative)
    if ($Database -ne 'master' -and $Database -notmatch '^par_sql_[a-z0-9_]+$') { throw 'Not a dedicated benchmark database' }
    $builder = [Microsoft.Data.SqlClient.SqlConnectionStringBuilder]::new()
    $builder['Data Source']='tcp:127.0.0.1,1433'; $builder['Initial Catalog']=$Database
    $authentication=Get-SqlServerAuthentication
    if (!$Administrative -and $authentication -eq 'Sql') {
        $password=$env:SQLSERVER_BENCHMARK_PASSWORD
        if (!$password -and (Test-Path C:/dev-psu/sqlserver-benchmark-password.txt)) { $password=(Get-Content C:/dev-psu/sqlserver-benchmark-password.txt -Raw).Trim() }
        if (!$password) { throw 'SQL authentication requires SQLSERVER_BENCHMARK_PASSWORD or the temporary demonstration file' }
        $builder['Integrated Security']=$false; $builder['User ID']=Get-SqlServerLogin; $builder['Password']=$password
    } else { $builder['Integrated Security']=$true }
    $builder['Pooling']=[bool]$Pooling
    $builder['Encrypt']='True'; $builder['Trust Server Certificate']=$true; $builder['Connect Timeout']=5
    $builder['Application Name']='PAR bounded database benchmark'
    $connection = [Microsoft.Data.SqlClient.SqlConnection]::new($builder.ConnectionString)
    $connection.Open()
    return ,$connection
}

function Get-SqlServerAuthentication {
    if ($env:PAR_SQL_AUTHENTICATION) {
        if ($env:PAR_SQL_AUTHENTICATION -notin 'Sql','Windows') { throw 'PAR_SQL_AUTHENTICATION must be Sql or Windows' }
        return $env:PAR_SQL_AUTHENTICATION
    }
    if (Test-Path C:/dev-psu/sqlserver-benchmark-password.txt) { return 'Sql' }
    return 'Windows'
}

function Get-SqlServerLogin {
    $login = $env:SQLSERVER_BENCHMARK_LOGIN
    if (!$login -and (Test-Path C:/dev-psu/sqlserver-benchmark-login.txt)) { $login = (Get-Content C:/dev-psu/sqlserver-benchmark-login.txt -Raw).Trim() }
    if (!$login) { $login = 'par_benchmark_sql' }
    if ($login -notmatch '^par_benchmark_[a-z0-9_]+$') { throw 'Invalid disposable benchmark login' }
    $login
}

function Invoke-SqlServerSql {
    param($Connection, [string] $Sql)
    $command=$Connection.CreateCommand(); $command.CommandTimeout=30; $command.CommandText=$Sql
    try {
        $reader=$command.ExecuteReader()
        try {
            do {
                while ($reader.Read()) {
                    $row=[ordered]@{}
                    for ($column=0; $column -lt $reader.FieldCount; $column++) { $row[$reader.GetName($column)]=$reader.GetValue($column) }
                    [pscustomobject]$row
                }
            } while ($reader.NextResult())
        } finally { $reader.Dispose() }
    } finally { $command.Dispose() }
}

function Initialize-SqlServerDatabase {
    param([string] $Database, [array] $Fixture)
    $admin=Open-SqlServerDatabase master -Administrative
    try { $null=Invoke-SqlServerSql $admin "CREATE DATABASE [$Database]" } finally { $admin.Dispose() }
    if ((Get-SqlServerAuthentication) -eq 'Sql') {
        $provisioner=Open-SqlServerDatabase $Database -Administrative
        $login = Get-SqlServerLogin
        try { $null=Invoke-SqlServerSql $provisioner "CREATE USER [$login] FOR LOGIN [$login]; ALTER ROLE db_owner ADD MEMBER [$login]" } finally { $provisioner.Dispose() }
    }
    $connection=Open-SqlServerDatabase $Database
    try {
        $null=Invoke-SqlServerSql $connection @'
CREATE TABLE records(Id int PRIMARY KEY, Name nvarchar(64) NOT NULL, Category nvarchar(32) NOT NULL, Enabled int NOT NULL, Cpu int NOT NULL, Payload nvarchar(max) NOT NULL, Revision int NOT NULL);
CREATE TABLE documents(Id int PRIMARY KEY, Body nvarchar(max) NOT NULL CHECK(ISJSON(Body)=1), Category AS CAST(JSON_VALUE(Body,'$.Category') AS nvarchar(32)), Enabled AS CAST(JSON_VALUE(Body,'$.Enabled') AS int));
CREATE INDEX records_filter ON records(Category,Enabled,Id);
CREATE INDEX documents_filter ON documents(Category,Enabled,Id);
CREATE TABLE batch_records(Id int PRIMARY KEY, Name nvarchar(64) NOT NULL, Category nvarchar(32) NOT NULL, Enabled int NOT NULL, Cpu int NOT NULL, Payload nvarchar(max) NOT NULL, Revision int NOT NULL);
CREATE TABLE batch_documents(Id int PRIMARY KEY, Body nvarchar(max) NOT NULL CHECK(ISJSON(Body)=1));
'@
        $null=Write-SqlServerBatch $connection $Fixture rows records
        $null=Write-SqlServerBatch $connection $Fixture documents documents
        $null=Invoke-SqlServerSql $connection 'UPDATE STATISTICS records WITH FULLSCAN; UPDATE STATISTICS documents WITH FULLSCAN;'
    } finally { $connection.Dispose() }
}

function Get-SqlServerPlan {
    param($Connection,[string] $Query)
    $null=Invoke-SqlServerSql $Connection 'SET SHOWPLAN_XML ON'
    try { Invoke-SqlServerSql $Connection $Query } finally { $null=Invoke-SqlServerSql $Connection 'SET SHOWPLAN_XML OFF' }
}

function Write-SqlServerBatch {
    param($Connection, [array] $Fixture,
        [ValidateSet('rows','documents','refresh-rows','refresh-documents','rows-set','refresh-rows-set','refresh-documents-set')][string] $Kind,
        [ValidateSet('records','documents','batch_records','batch_documents')][string] $Table,
        [switch] $Autocommit, [string] $BatchJson)
    $transaction=$null; $command=$Connection.CreateCommand(); $command.CommandTimeout=5
    try {
        if (!$Autocommit) { $transaction=$Connection.BeginTransaction(); $command.Transaction=$transaction }
        $command.CommandText=switch ($Kind) {
            rows { "INSERT INTO $Table VALUES (@id,@name,@category,@enabled,@cpu,@payload,@revision)" }
            documents { "INSERT INTO $Table(Id,Body) VALUES (@id,@body)" }
            refresh-rows { "UPDATE $Table SET Revision=Revision+1 WHERE Id=@id" }
            refresh-documents { "UPDATE $Table SET Body=JSON_MODIFY(Body,'$.Revision',CAST(JSON_VALUE(Body,'$.Revision') AS int)+1) WHERE Id=@id" }
            rows-set { "INSERT INTO $Table SELECT * FROM OPENJSON(@batch) WITH(Id int,Name nvarchar(64),Category nvarchar(32),Enabled int,Cpu int,Payload nvarchar(max),Revision int)" }
            refresh-rows-set { "UPDATE $Table SET Revision=Revision+1 WHERE Id IN (SELECT Id FROM OPENJSON(@batch) WITH(Id int))" }
            refresh-documents-set { "UPDATE $Table SET Body=JSON_MODIFY(Body,'$.Revision',CAST(JSON_VALUE(Body,'$.Revision') AS int)+1) WHERE Id IN (SELECT Id FROM OPENJSON(@batch) WITH(Id int))" }
        }
        if ($Kind -like '*-set') {
            if (!$BatchJson) { throw 'Prepare BatchJson outside database timer' }
            $null=$command.Parameters.Add('@batch',[System.Data.SqlDbType]::NVarChar,-1); $command.Parameters['@batch'].Value=$BatchJson
        } else {
            $null=$command.Parameters.Add('@id',[System.Data.SqlDbType]::Int)
            if ($Kind -eq 'rows') {
                foreach ($entry in @(@('name',64),@('category',32),@('payload',-1))) { $null=$command.Parameters.Add('@'+$entry[0],[System.Data.SqlDbType]::NVarChar,$entry[1]) }
                foreach ($name in 'enabled','cpu','revision') { $null=$command.Parameters.Add('@'+$name,[System.Data.SqlDbType]::Int) }
            } elseif ($Kind -eq 'documents') { $null=$command.Parameters.Add('@body',[System.Data.SqlDbType]::NVarChar,-1) }
        }
        $command.Prepare(); $affected=0
        if ($Kind -like '*-set') { $affected=$command.ExecuteNonQuery() }
        else {
            foreach ($item in $Fixture) {
                $command.Parameters['@id'].Value=[int]$item.Record.Id
                if ($Kind -eq 'rows') {
                    foreach ($name in 'name','category','payload') { $command.Parameters['@'+$name].Value=[string]$item.Record.$name }
                    foreach ($name in 'enabled','cpu','revision') { $command.Parameters['@'+$name].Value=[int]$item.Record.$name }
                } elseif ($Kind -eq 'documents') { $command.Parameters['@body'].Value=[string]$item.Json }
                $affected+=$command.ExecuteNonQuery()
            }
        }
        if ($transaction) { $transaction.Commit() }
        [pscustomobject]@{ Affected=$affected }
    } finally { $command.Dispose(); if ($transaction) { $transaction.Dispose() } }
}

function Get-SqlServerQuery {
    param([string] $Case, [int] $Count)
    $fields='Id,Name,Category,Enabled,Cpu,Payload,Revision'
    switch ($Case) {
        row-key { "SELECT $fields FROM records WHERE Id=@id" }
        document-key { 'SELECT Body FROM documents WHERE Id=@id' }
        row-filter { "SELECT $fields FROM records WHERE Category=@category AND Enabled=1 ORDER BY Id" }
        document-filter-index { 'SELECT Body FROM documents WHERE Category=@category AND Enabled=1 ORDER BY Id' }
        row-projection { 'SELECT Id,Name,Cpu FROM records WHERE Category=@category AND Enabled=1 ORDER BY Id' }
        document-projection { "SELECT Id,JSON_VALUE(Body,'$.Name') AS Name,CAST(JSON_VALUE(Body,'$.Cpu') AS int) AS Cpu FROM documents WHERE Category=@category AND Enabled=1 ORDER BY Id" }
        row-offset { "SELECT $fields FROM records WHERE Category=@category AND Enabled=1 ORDER BY Id OFFSET $([int]($Count/40)) ROWS FETCH NEXT 20 ROWS ONLY" }
        row-seek { "SELECT TOP(20) $fields FROM records WHERE Category=@category AND Enabled=1 AND Id>@after ORDER BY Id" }
        default { throw "Unknown case: $Case" }
    }
}

function Read-SqlServerRecord {
    param([string] $Database, [string] $Case, [int] $Count, $Connection, [switch] $Pooling)
    $ownsConnection=!$Connection
    if ($ownsConnection) { $Connection=Open-SqlServerDatabase $Database -Pooling:$Pooling }
    $command=$Connection.CreateCommand(); $command.CommandTimeout=5
    try {
        $command.CommandText=Get-SqlServerQuery $Case $Count
        $null=$command.Parameters.Add('@id',[System.Data.SqlDbType]::Int); $command.Parameters['@id'].Value=[int]($Count/2)
        $null=$command.Parameters.Add('@category',[System.Data.SqlDbType]::NVarChar,32); $command.Parameters['@category'].Value='group-2'
        $null=$command.Parameters.Add('@after',[System.Data.SqlDbType]::Int); $command.Parameters['@after'].Value=[int]($Count/2)
        $reader=$command.ExecuteReader()
        try {
            $records=@(while ($reader.Read()) {
                if ($Case -like 'document-*' -and $Case -ne 'document-projection') { $reader.GetString(0) | ConvertFrom-Json }
                elseif ($Case -like '*-projection') { [pscustomobject][ordered]@{ Id=$reader.GetInt32(0); Name=$reader.GetString(1); Cpu=$reader.GetInt32(2) } }
                else { [pscustomobject][ordered]@{ Id=$reader.GetInt32(0); Name=$reader.GetString(1); Category=$reader.GetString(2); Enabled=$reader.GetInt32(3); Cpu=$reader.GetInt32(4); Payload=$reader.GetString(5); Revision=$reader.GetInt32(6) } }
            })
        } finally { $reader.Dispose() }
        [pscustomobject]@{ Records=$records; Engine=$Connection.ServerVersion }
    } finally { $command.Dispose(); if ($ownsConnection) { $Connection.Dispose() } }
}

function Invoke-SqlServerIncrement {
    param($Connection)
    $transaction=$Connection.BeginTransaction(); $command=$Connection.CreateCommand(); $command.CommandTimeout=5
    try {
        $command.Transaction=$transaction; $command.CommandText='UPDATE batch_records SET Revision=Revision+1 WHERE Id<=10'
        $affected=$command.ExecuteNonQuery(); $transaction.Commit()
        [pscustomobject]@{ Affected=$affected; Engine=$Connection.ServerVersion }
    } finally { $command.Dispose(); $transaction.Dispose() }
}
