<#
.SYNOPSIS
Checks rollback, row-lock behavior, isolation, backup/restore and native integrity.
.PARAMETER Pass
Existing pass. Creates dedicated operations/restore databases; never overwrites.
.NOTES
Experimental, explicit TCP with selected workload authentication. Requires Windows SQL sysadmin for
database creation, backup and restore. Grants the SQL service modify access only
to this pass's operations directory so backup evidence survives uninstall.
Read committed is tested without RCSI; repeatable read retains shared locks.
No crash, power-loss, PITR or remote permissions claim follows these checks.
#>
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]{1,24}$')][string] $Pass)
. "$PSScriptRoot/SqlServer.ps1"
. "$PSScriptRoot/DatabaseFixture.ps1"
$root="C:/repos/psu-agent-reference/tools/output/database/$Pass"; $output="$root/operations"
if (Test-Path $output) { throw 'Operations pass exists' }
New-Item "$output/source" -ItemType Directory -Force | Out-Null
Copy-Item "$PSScriptRoot/*SqlServer*.ps1","$PSScriptRoot/DatabaseFixture.ps1" "$output/source"
& icacls.exe $output /grant 'NT SERVICE\MSSQLSERVER:(OI)(CI)M' | Set-Content "$output/backup-acl.txt"
if ($LASTEXITCODE) { throw 'Backup directory permission failed' }
$database=Get-SqlServerDatabaseName $Pass operations; $restore=Get-SqlServerDatabaseName $Pass restore
$fixture=@(New-BenchmarkFixture 100 256)
Initialize-SqlServerDatabase $database $fixture
$a=Open-SqlServerDatabase $database; $b=Open-SqlServerDatabase $database
$checks=[ordered]@{}
try {
    $null=Invoke-SqlServerSql $a 'BEGIN TRANSACTION; UPDATE records SET Revision=77 WHERE Id=1; ROLLBACK'
    $actual=@(Invoke-SqlServerSql $a 'SELECT * FROM records ORDER BY Id'); Assert-BenchmarkRecord $actual @($fixture.Record)
    $checks.Rollback=@{Correct=$true;Rows=100}
    $null=Invoke-SqlServerSql $a 'BEGIN TRANSACTION; UPDATE records SET Revision=Revision+1 WHERE Id=1'
    try {
        $null=Invoke-SqlServerSql $b 'SET LOCK_TIMEOUT 250; UPDATE records SET Revision=Revision+1 WHERE Id=2'
        $blocked=$false
        try { $null=Invoke-SqlServerSql $b 'UPDATE records SET Revision=Revision+1 WHERE Id=1' }
        catch { if ($_.Exception.InnerException.Number -ne 1222) { throw }; $blocked=$true }
        if (!$blocked) { throw 'Conflicting row did not block' }
        $checks.RowLocks=@{Correct=$true;IndependentRowCommitted=$true;ConflictingRowError=1222;LockTimeoutMs=250}
    } finally { $null=Invoke-SqlServerSql $a 'ROLLBACK'; $null=Invoke-SqlServerSql $b 'UPDATE records SET Revision=0 WHERE Id=2' }
    $null=Invoke-SqlServerSql $a 'SET TRANSACTION ISOLATION LEVEL READ COMMITTED; BEGIN TRANSACTION'
    try {
        $before=@(Invoke-SqlServerSql $a 'SELECT Revision FROM records WHERE Id=1')[0].Revision
        $null=Invoke-SqlServerSql $b 'UPDATE records SET Revision=1 WHERE Id=1'
        $after=@(Invoke-SqlServerSql $a 'SELECT Revision FROM records WHERE Id=1')[0].Revision
        if ($before -ne 0 -or $after -ne 1) { throw 'Read committed expectation failed' }
        $checks.ReadCommitted=@{Correct=$true;Before=$before;After=$after}
    } finally { $null=Invoke-SqlServerSql $a 'ROLLBACK'; $null=Invoke-SqlServerSql $b 'UPDATE records SET Revision=0 WHERE Id=1' }
    $null=Invoke-SqlServerSql $a 'SET TRANSACTION ISOLATION LEVEL REPEATABLE READ; BEGIN TRANSACTION; SELECT Revision FROM records WHERE Id=1'
    try {
        $blocked=$false
        try { $null=Invoke-SqlServerSql $b 'UPDATE records SET Revision=1 WHERE Id=1' }
        catch { if ($_.Exception.InnerException.Number -ne 1222) { throw }; $blocked=$true }
        if (!$blocked) { throw 'Repeatable read did not retain shared lock' }
        $checks.RepeatableRead=@{Correct=$true;ConflictingWriterBlocked=$true;LockTimeoutMs=250}
    } finally { $null=Invoke-SqlServerSql $a 'ROLLBACK; SET TRANSACTION ISOLATION LEVEL READ COMMITTED' }
    $integrity=@(Invoke-SqlServerSql $a 'DBCC CHECKDB WITH NO_INFOMSGS, ALL_ERRORMSGS, TABLERESULTS')
    $integrity | ConvertTo-Json -Depth 10 | Set-Content "$output/original-checkdb.json"
    if ($integrity.Count) { throw 'CHECKDB returned diagnostics' }
    $checks.Integrity=@{Correct=$true;Command='DBCC CHECKDB WITH NO_INFOMSGS, ALL_ERRORMSGS, TABLERESULTS';DiagnosticRows=$integrity.Count}
    $backup="$output/backup.bak"
    $backupAdmin=Open-SqlServerDatabase $database -Administrative
    try {
        $null=Invoke-SqlServerSql $backupAdmin "BACKUP DATABASE [$database] TO DISK=N'$backup' WITH COPY_ONLY,CHECKSUM"
        $null=Invoke-SqlServerSql $backupAdmin "RESTORE VERIFYONLY FROM DISK=N'$backup' WITH CHECKSUM"
        $fileList=@(Invoke-SqlServerSql $backupAdmin "RESTORE FILELISTONLY FROM DISK=N'$backup'")
    } finally { $backupAdmin.Dispose() }
    $fileList | ConvertTo-Json -Depth 10 | Set-Content "$output/backup-filelist.json"
    $moves=@($fileList | ForEach-Object { "MOVE N'$($_.LogicalName)' TO N'$($_.PhysicalName.Replace($database,$restore))'" })
    # SQL-client scope includes restore paths; no existing database is replaced.
    $admin=Open-SqlServerDatabase master -Administrative
    try { $null=Invoke-SqlServerSql $admin "RESTORE DATABASE [$restore] FROM DISK=N'$backup' WITH CHECKSUM,$($moves -join ',')" } finally { $admin.Dispose() }
    $restored=Open-SqlServerDatabase $restore
    try {
        Assert-BenchmarkRecord @(Invoke-SqlServerSql $restored 'SELECT * FROM records ORDER BY Id') @($fixture.Record)
        $documents=@(Invoke-SqlServerSql $restored 'SELECT Body FROM documents ORDER BY Id' | ForEach-Object { $_.Body | ConvertFrom-Json })
        Assert-BenchmarkRecord $documents @($fixture.Record)
        $integrity=@(Invoke-SqlServerSql $restored 'DBCC CHECKDB WITH NO_INFOMSGS, ALL_ERRORMSGS, TABLERESULTS')
        $integrity | ConvertTo-Json -Depth 10 | Set-Content "$output/restore-checkdb.json"
        if ($integrity.Count) { throw 'Restored CHECKDB returned diagnostics' }
    } finally { $restored.Dispose() }
    $checks.BackupRestore=@{Correct=$true;Checksum=$true;VerifyOnly=$true;ActualRestore=$true;Rows=100;Documents=100;RestoredCheckdb=$true}
} finally { $a.Dispose(); $b.Dispose() }
$reopen=Open-SqlServerDatabase $database
try { Assert-BenchmarkRecord @(Invoke-SqlServerSql $reopen 'SELECT * FROM records ORDER BY Id') @($fixture.Record) } finally { $reopen.Dispose() }
$checks.Reopen=@{Correct=$true;Rows=100}
$checks | ConvertTo-Json -Depth 12 | Set-Content "$output/checks.json"
Write-Output "SQL Server operational checks passed: $output"
