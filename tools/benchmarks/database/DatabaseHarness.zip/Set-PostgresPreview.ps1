# Experimental only.
<#
.SYNOPSIS
Installs or restores two PostgreSQL registrations in the dedicated dev-psu preview.
.PARAMETER Pass
Existing evidence pass to hold original registrations and installed hashes.
.PARAMETER Restore
Restores only unchanged benchmark registrations and removes the temporary password.
.NOTES
Requires the designated vaulted dev-psu API token. Set PGPASSWORD for setup.
Only C:/dev-psu/Repository and C:/dev-psu/postgres-benchmark-password.txt are changed.
The password file is temporary local demonstration configuration, never evidence.
Unregistered benchmark scripts and job history remain after restore.
#>
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]{1,24}$')][string] $Pass, [switch] $Restore)
$ErrorActionPreference = 'Stop'
$root = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
if (!(Test-Path "$root/metadata.json")) { throw 'Record conditions first' }
$repository = 'C:/dev-psu/Repository'; $backup = "$root/preview-backup"
$files = 'endpoints.ps1','scripts.ps1'
$token = Get-Secret -Name dev-psu-codex-mgmt-api -AsPlainText
$headers = @{ Authorization="Bearer $token" }
$schema = Invoke-RestMethod http://127.0.0.1:5100/swagger/v1/swagger.json -Headers $headers -MaximumRedirection 0
if (!$schema.paths.'/api/v1/configuration/sync/{configurationFile}'.put) { throw 'Reload route unavailable' }
if ($Restore) {
    if (Test-Path "$backup/restored.txt") { throw 'Already restored' }
    $installed = Get-Content "$backup/installed.json" -Raw | ConvertFrom-Json
    foreach ($file in $files) {
        if ((Get-FileHash "$repository/.universal/$file").Hash -ne $installed.$file) { throw "Preview changed: $file" }
    }
    foreach ($file in $files) { Copy-Item "$backup/$file" "$repository/.universal/$file" -Force }
} else {
    if ((Test-Path $backup) -or (Test-Path C:/dev-psu/postgres-benchmark-password.txt)) { throw 'Inspect existing preview/password first' }
    if (!$env:PGPASSWORD) { throw 'Set PGPASSWORD for demonstration preview' }
    New-Item $backup -ItemType Directory | Out-Null
    New-Item "$repository/scripts/benchmarks/database" -ItemType Directory -Force | Out-Null
    foreach ($file in $files) { Copy-Item "$repository/.universal/$file" "$backup/$file" }
    Set-Content C:/dev-psu/postgres-benchmark-password.txt $env:PGPASSWORD -NoNewline
    Copy-Item "$PSScriptRoot/Postgres.ps1","$PSScriptRoot/Invoke-PostgresEndpoint.ps1","$PSScriptRoot/Invoke-PostgresImport.ps1" "$repository/scripts/benchmarks/database" -Force
    Add-Content "$repository/.universal/endpoints.ps1" @'
New-PSUEndpoint -Url '/api/par-postgres-benchmark' -Method POST -Environment Integrated -Authentication -Endpoint {
    & 'C:/dev-psu/Repository/scripts/benchmarks/database/Invoke-PostgresEndpoint.ps1' -RequestJson $Body
}
'@
    Add-Content "$repository/.universal/scripts.ps1" @'
New-PSUScript -Name 'Invoke-PostgresImport.ps1' -Path 'benchmarks/database/Invoke-PostgresImport.ps1' -Environment 'PowerShell 7' -MaxHistory 40
'@
    $hashes = @{}
    foreach ($file in $files) { $hashes[$file] = (Get-FileHash "$repository/.universal/$file").Hash }
    $hashes | ConvertTo-Json | Set-Content "$backup/installed.json"
}
foreach ($file in $files) {
    $null = Invoke-RestMethod "http://127.0.0.1:5100/api/v1/configuration/sync/$file" -Method Put -Headers $headers -MaximumRedirection 0
}
if ($Restore) {
    foreach ($file in $files) {
        if ((Get-FileHash "$backup/$file").Hash -ne (Get-FileHash "$repository/.universal/$file").Hash) { throw "Restore differs: $file" }
    }
    Remove-Item -LiteralPath C:/dev-psu/postgres-benchmark-password.txt
    Set-Content "$backup/restored.txt" (Get-Date).ToUniversalTime().ToString('o')
}
Write-Output "PostgreSQL preview updated: $backup"
