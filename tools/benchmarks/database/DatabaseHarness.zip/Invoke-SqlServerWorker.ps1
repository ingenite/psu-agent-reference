# Experimental only.
<#
.SYNOPSIS
Runs one warmed SQL Server client after a shared future-time gate.
.PARAMETER Settings
Parent-supplied database, role, directory, worker Id and iteration count.
.NOTES
Checks ten operations of the assigned role before readiness. The parent verifies
all warm-up increments and resets them before opening the gate. Keeps samples
in memory until the loop ends. Startup is outside burst timing.
Native Measure-Command clocks include helper call/return through usable objects.
#>
param([hashtable] $Settings)
. "$PSScriptRoot/SqlServer.ps1"
$connection = Open-SqlServerDatabase $Settings.Database
try {
    $warmupOperations = 10
    for ($warmup = 0; $warmup -lt $warmupOperations; $warmup++) {
        if ($Settings.Role -eq 'writer') {
            $prepared = Invoke-SqlServerIncrement $connection
            if ($prepared.Affected -ne 10) { throw 'Writer warm-up result mismatch' }
        } else {
            $prepared = Read-SqlServerRecord -Connection $connection -Case row-seek -Count 10000
            if ($prepared.Records.Count -ne 20) { throw 'Reader warm-up result mismatch' }
        }
    }
    Set-Content "$($Settings.Directory)/ready-$($Settings.Id).txt" $PID
    $waitStart = Get-Date
    while (!(Test-Path "$($Settings.Directory)/gate.txt")) {
        if (((Get-Date)-$waitStart).TotalSeconds -gt 30) { throw 'Gate timeout' }
        Start-Sleep -Milliseconds 10
    }
    $gateText = Get-Content "$($Settings.Directory)/gate.txt" -Raw
    if (!$gateText) { throw 'Gate time unreadable' }
    $gate = Get-Date $gateText
    while ((Get-Date) -lt $gate) { Start-Sleep -Milliseconds 5 }
    $started = (Get-Date).ToUniversalTime()
    $wall = Measure-Command {
        $samples = @(for ($iteration=0; $iteration -lt $Settings.Iterations; $iteration++) {
            $errorMessage = $null; $rows = 0
            $operation = Measure-Command {
                try {
                    if ($Settings.Role -eq 'writer') { $result = Invoke-SqlServerIncrement $connection; $rows=$result.Affected }
                    else { $result = Read-SqlServerRecord -Connection $connection -Case row-seek -Count 10000; $rows=$result.Records.Count }
                } catch { $errorMessage=$_.Exception.Message }
            }
            [pscustomobject]@{ Iteration=$iteration; TotalMs=$operation.TotalMilliseconds; Rows=$rows; Error=$errorMessage }
        })
    }
    $ended = (Get-Date).ToUniversalTime()
    [pscustomobject]@{ Id=$Settings.Id; Role=$Settings.Role; Location='direct'; Started=$started.ToString('o'); Ended=$ended.ToString('o'); WallMs=$wall.TotalMilliseconds; Samples=$samples; ProcessId=$PID; WarmupOperations=$warmupOperations; WarmupRole=$Settings.Role }
} finally { $connection.Dispose() }

