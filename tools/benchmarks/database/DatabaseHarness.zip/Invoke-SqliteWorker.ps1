# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Runs a prepared closed-loop reader or writer after a shared file gate.
.PARAMETER Settings
Worker settings supplied by Invoke-SqliteFollowup; includes no saved credentials.
.NOTES
Ten checked operations of the assigned role precede readiness; the parent checks
and resets warm-up increments before the gate. Samples stay in memory until the loop
finishes. Provider lock waits are included; there is no application-level retry.
#>
param([hashtable] $Settings)
. "$PSScriptRoot/Sqlite.ps1"
$connection = $null
try {
    if ($Settings.Location -eq 'direct') { $connection = Open-BenchmarkDatabase $Settings.Database }
    $warmupOperations = 10
    for ($warmup = 0; $warmup -lt $warmupOperations; $warmup++) {
        if ($Settings.Location -eq 'direct') {
            if ($Settings.Role -eq 'writer') { $prepared = Invoke-BenchmarkIncrement $connection; $rows = $prepared.Affected }
            else { $prepared = Read-BenchmarkRecord -Connection $connection -Case row-seek -Count 10000 -SkipSerialization; $rows = $prepared.Records.Count }
        } else {
            $case = if ($Settings.Role -eq 'writer') { 'increment' } else { 'row-seek' }
            $prepared = & "$PSScriptRoot/Invoke-SqliteClient.ps1" -Request @{ Pass = $Settings.Pass; Shape = 'n10000-p256'; Case = $case } -Headers $Settings.Headers
            $rows = if ($Settings.Role -eq 'writer') { $prepared.Response.Result.Affected } else { @($prepared.Response.Result.Records).Count }
        }
        $expectedRows = if ($Settings.Role -eq 'writer') { 10 } else { 20 }
        if ($rows -ne $expectedRows) { throw 'Worker warm-up result mismatch' }
    }
    Set-Content "$($Settings.Directory)/ready-$($Settings.Id).txt" $PID
    $waitStart = Get-Date
    while (!(Test-Path "$($Settings.Directory)/gate.txt")) {
        if (((Get-Date) - $waitStart).TotalSeconds -gt 30) { throw 'Gate timeout' }
        Start-Sleep -Milliseconds 10
    }
    $gateText = Get-Content "$($Settings.Directory)/gate.txt" -Raw
    if (!$gateText) { throw 'Gate time unreadable' }
    $gate = Get-Date $gateText
    while ((Get-Date) -lt $gate) { Start-Sleep -Milliseconds 5 }
    $started = (Get-Date).ToUniversalTime()
    $timer = [System.Diagnostics.Stopwatch]::StartNew()
    $samples = @(for ($iteration = 0; $iteration -lt $Settings.Iterations; $iteration++) {
        $operationTimer = [System.Diagnostics.Stopwatch]::StartNew()
        try {
            if ($Settings.Location -eq 'direct') {
                if ($Settings.Role -eq 'writer') { $result = Invoke-BenchmarkIncrement $connection; $rows = $result.Affected }
                else { $result = Read-BenchmarkRecord -Connection $connection -Case row-seek -Count 10000 -SkipSerialization; $rows = $result.Records.Count }
                $operationMs = $operationTimer.Elapsed.TotalMilliseconds
                $internalMs = if ($Settings.Role -eq 'writer') { $result.TotalMs } else { $result.Metrics.TotalMs }
            } else {
                $case = if ($Settings.Role -eq 'writer') { 'increment' } else { 'row-seek' }
                $result = & "$PSScriptRoot/Invoke-SqliteClient.ps1" -Request @{ Pass = $Settings.Pass; Shape = 'n10000-p256'; Case = $case } -Headers $Settings.Headers
                $operationMs = $result.ClientMs
                $rows = if ($Settings.Role -eq 'writer') { $result.Response.Result.Affected } else { @($result.Response.Result.Records).Count }
                $internalMs = if ($Settings.Role -eq 'writer') { $result.Response.Result.TotalMs } else { $result.Response.Result.Metrics.TotalMs }
            }
            [pscustomobject]@{ Iteration = $iteration; TotalMs = $operationMs; InternalMs = $internalMs; Rows = $rows; Error = $null }
        } catch {
            [pscustomobject]@{ Iteration = $iteration; TotalMs = $operationTimer.Elapsed.TotalMilliseconds; InternalMs = $null; Rows = 0; Error = $_.Exception.Message }
        }
    })
    $wallMs = $timer.Elapsed.TotalMilliseconds
    $ended = (Get-Date).ToUniversalTime()
    [pscustomobject]@{ Id = $Settings.Id; Role = $Settings.Role; Location = $Settings.Location; Started = $started.ToString('o'); Ended = $ended.ToString('o'); WallMs = $wallMs; Samples = $samples; ProcessId = $PID; WarmupOperations = $warmupOperations; WarmupRole = $Settings.Role }
} finally { if ($connection) { $connection.Dispose() } }
