# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Checks completeness, burst counting, stored fixture equality and restoration of a full SQLite pass.
.PARAMETER Pass
Existing evidence pass. Writes evidence-checks.json; throws on missing/invalid evidence.
.NOTES
Expected plan is the default seven repetitions/200 iterations. No performance threshold.
These are live synthetic SQLite evidence checks, not production or crash-durability tests.
Follow-ups whose metadata records the review-corrected-v2 protocol also need
role-specific warm-up/reset evidence; historical passes have no protocol marker.
#>
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]+$')][string] $Pass)
. "$PSScriptRoot/Sqlite.ps1"
$root = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
$checks = [ordered]@{}
foreach ($plan in @(
    @{ File = 'reads.jsonl'; Rows = 336; Groups = @('Shape','Case','Mode'); GroupSize = 8 },
    @{ File = 'writes.jsonl'; Rows = 120; Groups = @('Shape','Case'); GroupSize = 8 },
    @{ File = 'followup/endpoints.jsonl'; Rows = 120; Groups = @('Shape','Case'); GroupSize = 8 },
    @{ File = 'followup/imports.jsonl'; Rows = 16; Groups = @('Location'); GroupSize = 8 },
    @{ File = 'followup/bursts.jsonl'; Rows = 40; Groups = @('Location','Readers','Writers'); GroupSize = 4 },
    @{ File = 'projection/samples.jsonl'; Rows = 96; Groups = @('Shape','Case','Location'); GroupSize = 8 }
    @{ File = 'client-boundary/reads.jsonl'; Rows = 432; Groups = @('Shape','Case','Mode'); GroupSize = 8 }
    @{ File = 'client-boundary/writes.jsonl'; Rows = 120; Groups = @('Shape','Case'); GroupSize = 8 }
)) {
    $rows = @(Get-Content "$root/$($plan.File)" | ConvertFrom-Json)
    if ($rows.Count -ne $plan.Rows -or @($rows | Where-Object { !$_.Correct }).Count) { throw "Missing/invalid results: $($plan.File)" }
    foreach ($group in ($rows | Group-Object -Property $plan.Groups)) {
        if ($group.Count -ne $plan.GroupSize -or @($group.Group | Where-Object Warmup).Count -ne 1 -or @($group.Group.Block | Sort-Object -Unique).Count -ne $plan.GroupSize) { throw "Unbalanced blocks: $($plan.File)" }
    }
    $checks[$plan.File] = @{ Rows = $rows.Count; Correct = $true }
}
$operations = 0
$correctedProtocol = (Get-Content "$root/followup/metadata.json" -Raw | ConvertFrom-Json).Protocol -eq 'review-corrected-v2'
foreach ($burst in (Get-Content "$root/followup/bursts.jsonl" | ConvertFrom-Json)) {
    $workers = @(Get-Content "$root/followup/$($burst.WorkersFile)" -Raw | ConvertFrom-Json)
    if ($workers.Count -ne ($burst.Readers + $burst.Writers) -or $burst.AllWorkersOverlapMs -le 0) { throw 'Burst overlap/count mismatch' }
    if ($correctedProtocol) {
        $reset = Get-Content (Join-Path (Split-Path "$root/followup/$($burst.WorkersFile)") 'warmup-reset.json') -Raw | ConvertFrom-Json
        if (!$reset.Correct -or !$reset.AllWorkersReady -or !$reset.RoleSpecific -or $reset.OperationsPerWorker -ne 10 -or $reset.BeforeReset -ne (100 * $burst.Writers) -or $reset.AfterReset -ne 0) { throw 'Invalid role-specific warm-up/reset evidence' }
        if (@($workers | Where-Object { $_.WarmupOperations -ne 10 -or $_.WarmupRole -ne $_.Role }).Count) { throw 'Missing worker warm-up evidence' }
    }
    foreach ($worker in $workers) {
        if ($worker.Samples.Count -ne 200 -or @($worker.Samples | Where-Object Error).Count) { throw 'Incomplete/failed worker' }
        $expected = if ($worker.Role -eq 'writer') { 10 } else { 20 }
        if (@($worker.Samples | Where-Object Rows -ne $expected).Count) { throw 'Wrong worker row count' }
        $operations += $worker.Samples.Count
    }
}
if ($operations -ne 22400) { throw "Wrong concurrent operation total: $operations" }
$checks.ConcurrentOperations = $operations
foreach ($shape in @(@(1000,256),@(10000,256),@(10000,2048))) {
    $count,$size = $shape
    $connection = Open-BenchmarkDatabase "$root/n$count-p$size.db"
    try {
        $integrity = Invoke-BenchmarkSql $connection 'PRAGMA integrity_check'
        $counts = Invoke-BenchmarkSql $connection 'SELECT (SELECT count(*) FROM records) AS Rows, (SELECT count(*) FROM documents) AS Documents'
        $mismatch = Invoke-BenchmarkSql $connection @'
SELECT count(*) AS Mismatches FROM records r LEFT JOIN documents d ON r.Id=d.Id
WHERE d.Id IS NULL OR r.Id<>json_extract(d.Body,'$.Id') OR r.Name<>json_extract(d.Body,'$.Name')
OR r.Category<>json_extract(d.Body,'$.Category') OR r.Enabled<>json_extract(d.Body,'$.Enabled')
OR r.Cpu<>json_extract(d.Body,'$.Cpu') OR r.Payload<>json_extract(d.Body,'$.Payload') OR r.Revision<>json_extract(d.Body,'$.Revision');
'@
        if ($integrity.integrity_check -ne 'ok' -or $counts.Rows -ne $count -or $counts.Documents -ne $count -or $mismatch.Mismatches -ne 0) { throw 'Stored dataset failed verification' }
        $fixture = @(New-BenchmarkFixture $count $size)
        Assert-BenchmarkRecord @(Invoke-BenchmarkSql $connection 'SELECT * FROM records ORDER BY Id') @($fixture.Record)
        $checks["n$count-p$size"] = @{ Rows = $count; Documents = $count; Mismatches = 0; Integrity = 'ok'; Correct = $true }
    } finally { $connection.Dispose() }
}
$control = @(Get-Content "$root/followup/control.jsonl" | ConvertFrom-Json)
if ($control.Count -ne 6 -or @($control | Where-Object { !$_.Correct -or $_.TotalMs.Count -ne 100 }).Count) { throw 'Incomplete orchestration control' }
foreach ($phase in '.', 'followup','projection','client-boundary') {
    if (@(Get-Content "$root/$phase/monitoring.jsonl").Count -lt 1) { throw "Missing monitoring: $phase" }
}
$operational = Get-Content "$root/operations/checks.json" -Raw | ConvertFrom-Json
foreach ($name in 'Snapshot','WriteLock','Rollback','Reopen','BackupVerification') { if (!$operational.$name.Correct) { throw "Operational check failed: $name" } }
if (!(Test-Path "$root/preview-backup/restored.txt")) { throw 'Preview not restored' }
foreach ($file in 'endpoints.ps1','scripts.ps1') {
    if ((Get-FileHash "$root/preview-backup/$file").Hash -ne (Get-FileHash "C:/dev-psu/Repository/.universal/$file").Hash) { throw "Preview restore mismatch: $file" }
}
$checks.ControlOperations = 600
$checks.PreviewRestored = $true
$checks.Correct = $true
$checks | ConvertTo-Json -Depth 6 | Set-Content "$root/evidence-checks.json"
Write-Output "SQLite evidence complete and checked: $root/evidence-checks.json"
