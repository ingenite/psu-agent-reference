# Experimental only; use on the dedicated dev-psu instance.
<#
.SYNOPSIS
Returns a constrained synthetic PostgreSQL read from an authenticated endpoint.
.PARAMETER RequestJson
Object containing Pass, Shape and Case. No connection string or SQL is accepted.
.NOTES
Uses loopback, the disposable par_benchmark role, pooled connections and the
temporary demonstration password file prepared by Set-PostgresPreview.
#>
param([Parameter(Mandatory)][string] $RequestJson)
$duration = Measure-Command {
    . "$PSScriptRoot/Postgres.ps1"
    $request = $RequestJson | ConvertFrom-Json
    $database = Get-PostgresDatabaseName $request.Pass $request.Shape
    if ($request.Case -notin 'row-key','document-key','row-filter','document-filter-index','row-seek','row-projection','document-projection') { throw 'Invalid benchmark case' }
    $count = if ($request.Shape -eq 'n1000-p256') { 1000 } else { 10000 }
    $result = Read-PostgresRecord -Database $database -Case $request.Case -Count $count -Pooling
}
[pscustomobject]@{ Result=$result; HandlerMs=$duration.TotalMilliseconds; PowerShell="$($PSVersionTable.PSVersion)"; Engine=$result.Engine }
