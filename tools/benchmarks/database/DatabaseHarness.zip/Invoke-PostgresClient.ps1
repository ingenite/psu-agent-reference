# Experimental only.
<#
.SYNOPSIS
Measures HTTP transfer and JSON parsing through usable PostgreSQL endpoint objects.
.PARAMETER Request
Prepared Pass/Shape/Case hashtable; its serialization is outside the timer.
.PARAMETER Headers
In-memory loopback authentication headers; never saved.
#>
param([hashtable] $Request, [hashtable] $Headers)
$ErrorActionPreference = 'Stop'
$body = $Request | ConvertTo-Json -Compress
$elapsed = Measure-Command {
    $http = Measure-Command {
        $response = Invoke-WebRequest http://127.0.0.1:5100/api/par-postgres-benchmark -Method Post -Headers $Headers -ContentType application/json -Body $body -MaximumRedirection 0
    }
    $parse = Measure-Command { $result = $response.Content | ConvertFrom-Json -Depth 15 }
}
[pscustomobject]@{ ClientMs=$elapsed.TotalMilliseconds; HttpMs=$http.TotalMilliseconds; ParseMs=$parse.TotalMilliseconds; ResponseBytes=$response.RawContentLength; Response=@($result)[0] }
