<#
.SYNOPSIS
Records the temporary SQL Server instance and host before measurement.
.PARAMETER Pass
New evidence directory under tools/output/database; never overwrites a pass.
.PARAMETER ConfigureTcp
Enables TCP on IPv4 loopback only, port 1433, and restarts MSSQLSERVER if needed.
.NOTES
Experimental. Requires Windows diagnostic access and local SQL administrative
Windows authentication. Configuration is owner-authorized for this temporary
installation. Saves original TCP registry values before changes. SQL workloads
can use the login prepared by Initialize-SqlServerLogin; discovery still uses
Windows administration. No software, firewall or durability changes here.
#>
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]{1,24}$')][string] $Pass, [switch] $ConfigureTcp)
. "$PSScriptRoot/SqlServer.ps1"
$output="C:/repos/psu-agent-reference/tools/output/database/$Pass"
if (Test-Path $output) { throw 'Pass exists' }
New-Item "$output/source" -ItemType Directory -Force | Out-Null
Copy-Item "$PSScriptRoot/*SqlServer*.ps1","$PSScriptRoot/DatabaseFixture.ps1" "$output/source"
$instance=(Get-ItemProperty 'HKLM:/SOFTWARE/Microsoft/Microsoft SQL Server/Instance Names/SQL').MSSQLSERVER
if ($instance -ne 'MSSQL17.MSSQLSERVER') { throw 'Inspect instance before configuring a different installation' }
$tcp="HKLM:/SOFTWARE/Microsoft/Microsoft SQL Server/$instance/MSSQLServer/SuperSocketNetLib/Tcp"
@{ Protocol=Get-ItemProperty $tcp | Select-Object Enabled,ListenOnAllIPs
    Addresses=@(Get-ChildItem $tcp | ForEach-Object { Get-ItemProperty $_.PSPath | Select-Object PSChildName,Active,Enabled,IpAddress,TcpPort,TcpDynamicPorts })
} | ConvertTo-Json -Depth 6 | Set-Content "$output/tcp-before.json"
if ($ConfigureTcp) {
    Set-ItemProperty $tcp -Name Enabled -Value 1
    Set-ItemProperty $tcp -Name ListenOnAllIPs -Value 0
    foreach ($address in Get-ChildItem $tcp) {
        if ($address.PSChildName -eq 'IPAll') { continue }
        $settings=Get-ItemProperty $address.PSPath
        Set-ItemProperty $address.PSPath -Name Enabled -Value ([int]($settings.IpAddress -eq '127.0.0.1'))
        if ($settings.IpAddress -eq '127.0.0.1') {
            Set-ItemProperty $address.PSPath -Name TcpPort -Value '1433'
            Set-ItemProperty $address.PSPath -Name TcpDynamicPorts -Value ''
        }
    }
    Restart-Service MSSQLSERVER -ErrorAction Stop
}
$connection=Open-SqlServerDatabase master -Administrative
try {
    @{
        Version=@(Invoke-SqlServerSql $connection "SELECT @@VERSION AS version,SERVERPROPERTY('Edition') AS edition,SERVERPROPERTY('ProductVersion') AS product_version,SERVERPROPERTY('InstanceName') AS instance,SERVERPROPERTY('ServerName') AS server_name,SERVERPROPERTY('IsIntegratedSecurityOnly') AS windows_only")
        Connection=@(Invoke-SqlServerSql $connection "SELECT ORIGINAL_LOGIN() AS login_name,IS_SRVROLEMEMBER('sysadmin') AS sysadmin,net_transport,auth_scheme,encrypt_option,local_net_address,local_tcp_port,client_net_address FROM sys.dm_exec_connections WHERE session_id=@@SPID")
        Configuration=@(Invoke-SqlServerSql $connection 'SELECT name,value,value_in_use,description FROM sys.configurations ORDER BY name')
        System=@(Invoke-SqlServerSql $connection 'SELECT cpu_count,scheduler_count,physical_memory_kb,committed_kb,committed_target_kb,sqlserver_start_time FROM sys.dm_os_sys_info')
        Databases=@(Invoke-SqlServerSql $connection 'SELECT name,compatibility_level,recovery_model_desc,page_verify_option_desc,delayed_durability_desc,is_read_committed_snapshot_on,snapshot_isolation_state_desc,is_auto_close_on,is_auto_shrink_on,is_accelerated_database_recovery_on FROM sys.databases')
        Files=@(Invoke-SqlServerSql $connection 'SELECT DB_NAME(database_id) AS database_name,name,type_desc,physical_name,size,growth,is_percent_growth FROM sys.master_files')
    } | ConvertTo-Json -Depth 15 | Set-Content "$output/server-before.json"
} finally { $connection.Dispose() }
@{ Utc=(Get-Date).ToUniversalTime().ToString('o'); PowerShell="$($PSVersionTable.PSVersion)"; Seed=1108; Repetitions=7
    BaseCommit=git rev-parse HEAD; Authentication=Get-SqlServerAuthentication; BenchmarkLogin=Get-SqlServerLogin
    Protocol='review-corrected-v2'; WorkerWarmupOperations=10; IndexComparison='Counterbalanced paired reuse reads; ten checked warm-ups after each condition change'
    Connection='tcp:127.0.0.1,1433; TLS encrypted, server certificate trusted without validation; explicit pooling modes; authentication recorded separately'
    Runtime=(Get-Content "$PSHOME/pwsh.runtimeconfig.json" -Raw | ConvertFrom-Json).runtimeOptions
} | ConvertTo-Json -Depth 10 | Set-Content "$output/metadata.json"
@{
    Processor=Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors
    Computer=Get-CimInstance Win32_ComputerSystem | Select-Object TotalPhysicalMemory
    OS=Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber
    Disk=Get-Partition -DriveLetter C | Get-Disk | Select-Object Number,FriendlyName,BusType,Size
    Services=@(Get-CimInstance Win32_Service | Where-Object Name -match 'MSSQL|postgres' | Select-Object Name,State,PathName,StartName)
    PowerPlan=powercfg /getactivescheme
    Provider=Get-Item C:/dev-psu/Microsoft.Data.SqlClient.dll | Select-Object FullName,@{Name='Version';Expression={$_.VersionInfo.FileVersion}}
    ProviderHash=Get-FileHash C:/dev-psu/Microsoft.Data.SqlClient.dll | Select-Object Path,Hash
} | ConvertTo-Json -Depth 8 | Set-Content "$output/host.json"
$benchmark=Open-SqlServerDatabase master
try {
    @(Invoke-SqlServerSql $benchmark "SELECT ORIGINAL_LOGIN() AS login_name,IS_SRVROLEMEMBER('sysadmin') AS sysadmin,CONNECTIONPROPERTY('net_transport') AS transport,CONNECTIONPROPERTY('auth_scheme') AS authentication,CONNECTIONPROPERTY('local_net_address') AS address,CONNECTIONPROPERTY('local_tcp_port') AS port") | ConvertTo-Json -Depth 5 | Set-Content "$output/benchmark-identity.json"
} finally { $benchmark.Dispose() }
if ((Get-SqlServerAuthentication) -eq 'Sql') { Copy-Item C:/repos/psu-agent-reference/tools/output/database/sqlserver-login-setup.json $output }
Write-Output "SQL Server conditions: $output"
