<#
.SYNOPSIS
Validates and preserves SQL Server databases and evidence independently of installation.
.PARAMETER Pass
Completed pass. Creates retained/ and a sibling evidence ZIP once.
.PARAMETER SkipPortable
Keeps the pass summary but leaves the committed portable evidence files unchanged.
.NOTES
Experimental. Uses explicit TCP Windows authentication, SQL administrative access,
Windows diagnostics and designated dev-psu token. Native COPY_ONLY/CHECKSUM backups
are verified; operations/backup.bak was actually restored. Each measured database
also receives full field equality checks and DBCC CHECKDB. No software is removed.
Grants SQL service modify access only to retained/. Saves no passwords or tokens.
Manifest excludes itself; ZIP has a separate SHA256. Does not replace a package.
#>
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]{1,24}$')][string] $Pass, [switch] $SkipPortable)
. "$PSScriptRoot/SqlServer.ps1"
. "$PSScriptRoot/DatabaseFixture.ps1"
$root="C:/repos/psu-agent-reference/tools/output/database/$Pass"; $output="$root/retained"; $archive="$root-evidence.zip"
if ((Test-Path $output) -or (Test-Path $archive)) { throw 'Retained package exists' }
New-Item "$output/source" -ItemType Directory -Force | Out-Null
Copy-Item "$PSScriptRoot/*SqlServer*.ps1","$PSScriptRoot/DatabaseFixture.ps1" "$output/source"
Copy-Item "$PSScriptRoot/../DatabaseProviders.md" $output
& icacls.exe $output /grant 'NT SERVICE\MSSQLSERVER:(OI)(CI)M' | Set-Content "$output/backup-acl.txt"
if ($LASTEXITCODE) { throw 'Backup directory permission failed' }
foreach ($shape in @(@(1000,256),@(10000,256),@(10000,2048))) {
    $count,$size=$shape; $label="n$count-p$size"; $database=Get-SqlServerDatabaseName $Pass $label
    $connection=Open-SqlServerDatabase $database -Administrative
    try {
        $fixture=@(New-BenchmarkFixture $count $size)
        Assert-BenchmarkRecord @(Invoke-SqlServerSql $connection 'SELECT * FROM records ORDER BY Id') @($fixture.Record)
        $documents=@(Invoke-SqlServerSql $connection 'SELECT Body FROM documents ORDER BY Id' | ForEach-Object { $_.Body | ConvertFrom-Json })
        Assert-BenchmarkRecord $documents @($fixture.Record)
        $integrity=@(Invoke-SqlServerSql $connection 'DBCC CHECKDB WITH NO_INFOMSGS, ALL_ERRORMSGS, TABLERESULTS')
        if ($integrity.Count) { throw 'Measured database CHECKDB diagnostics' }
        $backup="$output/$label.bak"
        $null=Invoke-SqlServerSql $connection "BACKUP DATABASE [$database] TO DISK=N'$backup' WITH COPY_ONLY,CHECKSUM"
        $null=Invoke-SqlServerSql $connection "RESTORE VERIFYONLY FROM DISK=N'$backup' WITH CHECKSUM"
        @{
            Correct=$true; RowsChecked=$count; DocumentsChecked=$count; CheckdbDiagnosticRows=$integrity.Count; BackupVerified=$true
            Tables=@(Invoke-SqlServerSql $connection 'SELECT t.name AS table_name,c.name AS column_name,TYPE_NAME(c.user_type_id) AS type_name,c.max_length,c.is_nullable,c.is_computed,cc.definition FROM sys.tables t JOIN sys.columns c ON t.object_id=c.object_id LEFT JOIN sys.computed_columns cc ON cc.object_id=c.object_id AND cc.column_id=c.column_id ORDER BY t.name,c.column_id')
            Indexes=@(Invoke-SqlServerSql $connection 'SELECT t.name AS table_name,i.name,i.type_desc,i.is_primary_key,c.name AS column_name,ic.key_ordinal,ic.is_included_column FROM sys.tables t JOIN sys.indexes i ON t.object_id=i.object_id JOIN sys.index_columns ic ON i.object_id=ic.object_id AND i.index_id=ic.index_id JOIN sys.columns c ON ic.object_id=c.object_id AND ic.column_id=c.column_id ORDER BY t.name,i.name,ic.key_ordinal')
            Compression=@(Invoke-SqlServerSql $connection 'SELECT OBJECT_NAME(object_id) AS table_name,index_id,rows,data_compression_desc FROM sys.partitions WHERE object_id IN(OBJECT_ID(''records''),OBJECT_ID(''documents''),OBJECT_ID(''batch_records''),OBJECT_ID(''batch_documents''))')
            BackupHeader=@(Invoke-SqlServerSql $connection "RESTORE HEADERONLY FROM DISK=N'$backup'")
        } | ConvertTo-Json -Depth 15 | Set-Content "$output/$label-checks-schema.json"
    } finally { $connection.Dispose() }
}
$configuration=Get-Content C:/dev-psu/appsettings.json -Raw | ConvertFrom-Json
$token=Get-Secret -Name dev-psu-codex-mgmt-api -AsPlainText
$headers=@{Authorization="Bearer $token"}
$settings=@(Invoke-RestMethod http://127.0.0.1:5100/api/v1/settings -Headers $headers -MaximumRedirection 0)[0]
$environments=Invoke-RestMethod http://127.0.0.1:5100/api/v1/environment -Headers $headers -MaximumRedirection 0
@{
    SystemLogLevel=$configuration.SystemLogLevel; ApiSecurity=$configuration.Api.SecurityModel; HangfireWorkerCount=$configuration.HangfireWorkerCount
    Settings=$settings | Select-Object concurrentJobLimit,maxJobMemory,scriptBaseFolder,gitSyncEnabled
    Environments=@($environments | Select-Object name,version,maxRunspaces,persistentRunspace)
    Runtime=@{
        Harness=(Get-Content "$PSHOME/pwsh.runtimeconfig.json" -Raw | ConvertFrom-Json).runtimeOptions
        PsuServer=(Get-Content C:/dev-psu/Universal.Server.runtimeconfig.json -Raw | ConvertFrom-Json).runtimeOptions
        PsuJob=(Get-Content C:/dev-psu/pwsh.runtimeconfig.json -Raw | ConvertFrom-Json).runtimeOptions
    }
} | ConvertTo-Json -Depth 12 | Set-Content "$root/psu-condition.json"
& "$PSScriptRoot/Test-SqlServerEvidence.ps1" -Pass $Pass
& "$PSScriptRoot/Export-SqlServerEvidence.ps1" -Pass $Pass -SkipPortable:$SkipPortable
Copy-Item "$root/summary.json" "$output/summary.json"
$resolved=(Resolve-Path $root).Path
Get-ChildItem $root -File -Recurse | Sort-Object FullName | ForEach-Object {
    [pscustomobject]@{File=$_.FullName.Substring($resolved.Length+1).Replace('\','/');Bytes=$_.Length;Sha256=(Get-FileHash $_.FullName).Hash}
} | ConvertTo-Json -Depth 5 | Set-Content "$root/manifest.json"
Compress-Archive -LiteralPath $root -DestinationPath $archive -CompressionLevel Optimal
Get-FileHash $archive | Select-Object Path,Hash | ConvertTo-Json | Set-Content "$archive.sha256.json"
Write-Output "SQL Server evidence retained: $archive"
