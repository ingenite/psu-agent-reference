# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Compares the retained SQL-login baseline with the corrected SQL Server rerun.
.PARAMETER OutputDirectory
Generated JSON and CSV location; defaults to tools/output/database/sqlserver-review-comparison.
.NOTES
Reads portable evidence and retained corrected raw index pairs. Does not connect
to SQL Server or alter either pass. Percent changes are descriptive, not isolated
effects of the protocol fixes; the passes used different disposable SQL logins.
#>
param([string] $OutputDirectory = "$PSScriptRoot/../../output/database/sqlserver-review-comparison")
$ErrorActionPreference = 'Stop'
$before = Get-Content "$PSScriptRoot/SqlServerEvidence.json" -Raw | ConvertFrom-Json
$after = Get-Content "$PSScriptRoot/SqlServerReviewedEvidence.json" -Raw | ConvertFrom-Json
New-Item $OutputDirectory -ItemType Directory -Force | Out-Null
$comparisons = @(foreach ($section in 'Reads','Writes','Endpoints','Imports','Bursts') {
    $keys = switch ($section) {
        Reads { 'Shape','Case','Mode' }
        Writes { 'Shape','Case' }
        Endpoints { 'Shape','Case' }
        Imports { 'Location','Method' }
        Bursts { 'Readers','Writers' }
    }
    $metric = if ($section -eq 'Bursts') { 'OperationsPerSecond' } else { 'ClientMs' }
    foreach ($previous in $before.$section) {
        $current = @($after.$section)
        foreach ($key in $keys) { $value = $previous.$key; $current = @($current | Where-Object { $_.$key -eq $value }) }
        if ($current.Count -ne 1) { throw "Missing or ambiguous $section comparison" }
        $oldMedian = $previous.$metric.Median
        $newMedian = $current[0].$metric.Median
        [pscustomobject]@{
            Section=$section; Shape=$previous.Shape; Case=$previous.Case; Mode=$previous.Mode
            Location=$previous.Location; Method=$previous.Method; Readers=$previous.Readers; Writers=$previous.Writers
            Metric=$metric; BeforeMedian=$oldMedian; AfterMedian=$newMedian
            ChangePercent=100*($newMedian/$oldMedian-1)
        }
    }
})
$pairedReads = @(Get-Content "C:/repos/psu-agent-reference/tools/output/database/$($after.Pass)/direct/reads.jsonl" | ConvertFrom-Json |
    Where-Object { !$_.Warmup -and $_.Mode -eq 'reuse' -and $_.Case -in 'document-filter-index','document-filter-scan' })
$pairs = @(foreach ($group in $pairedReads | Group-Object Shape,Block) {
    $scan = @($group.Group | Where-Object Case -eq 'document-filter-scan')
    $indexed = @($group.Group | Where-Object Case -eq 'document-filter-index')
    if ($scan.Count -ne 1 -or $indexed.Count -ne 1) { throw 'Incomplete paired index sample' }
    [pscustomobject]@{
        Shape=$scan[0].Shape; Block=$scan[0].Block; Order=$scan[0].PairOrder
        ScanMs=$scan[0].ClientMs; IndexedMs=$indexed[0].ClientMs
        SavedMs=$scan[0].ClientMs-$indexed[0].ClientMs
        ReductionPercent=100*(1-$indexed[0].ClientMs/$scan[0].ClientMs)
    }
})
@{ BeforePass=$before.Pass; AfterPass=$after.Pass; Comparisons=$comparisons; IndexPairs=$pairs;
    Interpretation='Unpaired before/after provider passes. Index pairs inside the corrected pass are counterbalanced by block. Old baseline concurrency lacked role-specific writer warm-up.' } |
    ConvertTo-Json -Depth 10 | Set-Content "$OutputDirectory/comparison.json"
$comparisons | Export-Csv "$OutputDirectory/comparison.csv" -NoTypeInformation
$pairs | Export-Csv "$OutputDirectory/index-pairs.csv" -NoTypeInformation
Write-Output "SQL Server comparison: $OutputDirectory/comparison.json and CSV files"
