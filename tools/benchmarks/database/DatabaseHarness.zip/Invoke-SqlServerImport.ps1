# Experimental only.
<#
.SYNOPSIS
Imports 1,000 prepared synthetic records directly or through PSU automation.
.PARAMETER Pass
Evidence pass containing import-fixture.json.
.PARAMETER Method
Prepared per-row commands or a single OPENJSON recordset statement. Both commit once.
The identity method returns the actual login/role/transport for an untimed probe.
.NOTES
Fixture decoding and batch JSON preparation precede DatabaseMs, and are included
in ScriptMs and the external client clock. Resets only the dedicated batch table.
#>
param(
    [Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]{1,24}$')][string] $Pass,
    [ValidateSet('rows','rows-set','identity')][string] $Method = 'rows-set'
)
if ($Method -eq 'identity') {
    . "$PSScriptRoot/SqlServer.ps1"
    $connection=Open-SqlServerDatabase (Get-SqlServerDatabaseName $Pass n10000-p256) -Pooling
    try { Invoke-SqlServerSql $connection "SELECT ORIGINAL_LOGIN() AS login_name,IS_SRVROLEMEMBER('sysadmin') AS sysadmin,IS_MEMBER('db_owner') AS db_owner,CONNECTIONPROPERTY('auth_scheme') AS authentication,CONNECTIONPROPERTY('net_transport') AS transport" | ConvertTo-Json -Compress } finally { $connection.Dispose() }
    return
}
$scriptDuration = Measure-Command {
    . "$PSScriptRoot/SqlServer.ps1"
    $output = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
    $fixture = @(Get-Content "$output/import-fixture.json" -Raw | ConvertFrom-Json)
    $json = ConvertTo-Json -InputObject @($fixture.Record) -Depth 5 -Compress
    $connection = Open-SqlServerDatabase (Get-SqlServerDatabaseName $Pass n10000-p256) -Pooling
    try {
        $null = Invoke-SqlServerSql $connection 'TRUNCATE TABLE batch_records'
        $databaseDuration = Measure-Command { $result = Write-SqlServerBatch $connection $fixture $Method batch_records -BatchJson $json }
    } finally { $connection.Dispose() }
}
[pscustomobject]@{ Affected=$result.Affected; DatabaseMs=$databaseDuration.TotalMilliseconds; ScriptMs=$scriptDuration.TotalMilliseconds; Method=$Method; PowerShell="$($PSVersionTable.PSVersion)" } | ConvertTo-Json -Compress


