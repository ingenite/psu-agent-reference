# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Measures selected PSU reads and 1,000-record automation imports.
.PARAMETER EvidencePass
Existing direct evidence pass with the SQL Server preview installed. Adds followup/ once.
.PARAMETER Repetitions
Measured shuffled blocks after one warm-up for endpoints and both import methods.
.NOTES
Requires designated local API token. No tools or console output during blocks.
Resets only dedicated batch tables. Result checks run after clocks stop.
#>
[CmdletBinding()]
param([Alias('Pass')][Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]+$')][string] $EvidencePass,
    [ValidateRange(1,15)][int] $Repetitions = 7)
. "$PSScriptRoot/SqlServer.ps1"
. "$PSScriptRoot/DatabaseFixture.ps1"
$root = "C:/repos/psu-agent-reference/tools/output/database/$EvidencePass"
$output = "$root/followup"
if (Test-Path $output) { throw 'Follow-up exists' }
New-Item "$output/source" -ItemType Directory -Force | Out-Null
Copy-Item "$PSScriptRoot/*.ps1" "$output/source"
$monitor = Start-Job -FilePath "$PSScriptRoot/Watch-SqlServerHost.ps1" -ArgumentList $output
try {
while (!(Test-Path "$output/monitor-ready.txt")) {
    if ($monitor.State -eq 'Failed') { $monitor | Receive-Job; throw 'Monitor failed' }
    Start-Sleep -Milliseconds 25
}
$token = Get-Secret -Name dev-psu-codex-mgmt-api -AsPlainText
$headers = @{ Authorization = "Bearer $token" }
$schema = Invoke-RestMethod http://127.0.0.1:5100/swagger/v1/swagger.json -Headers $headers -MaximumRedirection 0
if (!$schema.paths.'/api/v1/script/{id}'.post) { throw 'Job submission route unavailable' }
$schema.components.schemas.'PowerShellUniversal.JobContext' | ConvertTo-Json -Depth 15 | Set-Content "$output/job-context-schema.json"
$settingsResponse = Invoke-RestMethod http://127.0.0.1:5100/api/v1/settings -Headers $headers -MaximumRedirection 0
$settings = @($settingsResponse)[0]
@{ Utc = (Get-Date).ToUniversalTime().ToString('o'); Repetitions = $Repetitions; Seed = 1108
    Version = Invoke-RestMethod http://127.0.0.1:5100/api/v1/version -Headers $headers -MaximumRedirection 0
    Environments = Invoke-RestMethod http://127.0.0.1:5100/api/v1/environment -Headers $headers -MaximumRedirection 0
    Settings = $settings | Select-Object apiSecurityModel,concurrentJobLimit,maxJobMemory,logLevel,scriptBaseFolder,gitSyncEnabled
    PreviewHashes = @(Get-ChildItem C:/dev-psu/Repository/scripts/benchmarks/database -File | Get-FileHash | Select-Object Path,Hash)
} | ConvertTo-Json -Depth 15 | Set-Content "$output/metadata.json"
Get-Random -SetSeed 1108 | Out-Null
$identity=& "$PSScriptRoot/Invoke-SqlServerClient.ps1" -Request @{Pass=$EvidencePass;Shape='n1000-p256';Case='identity'} -Headers $headers
$identity.Response.Result.Records | ConvertTo-Json -Depth 5 | Set-Content "$output/endpoint-identity.json"
if ((Get-SqlServerAuthentication) -eq 'Sql' -and ($identity.Response.Result.Records[0].authentication -ne 'SQL' -or $identity.Response.Result.Records[0].sysadmin -ne 0)) { throw 'Endpoint SQL identity did not match' }
foreach ($shape in 'n1000-p256','n10000-p256','n10000-p2048') {
    $count = if ($shape -eq 'n1000-p256') { 1000 } else { 10000 }
    $size = if ($shape -eq 'n10000-p2048') { 2048 } else { 256 }
    $fixture = @(New-BenchmarkFixture $count $size)
    foreach ($block in 0..$Repetitions) {
        foreach ($case in ('row-key','document-key','row-seek','row-filter','document-filter-index','row-projection','document-projection' | Get-Random -Shuffle)) {
            $result = & "$PSScriptRoot/Invoke-SqlServerClient.ps1" -Request @{ Pass = $EvidencePass; Shape = $shape; Case = $case } -Headers $headers
            $expected = switch -Wildcard ($case) {
                '*-key' { @($fixture[[int]($count / 2) - 1].Record) }
                'row-seek' { @($fixture.Record | Where-Object { $_.Category -eq 'group-2' -and $_.Enabled -eq 1 -and $_.Id -gt ($count / 2) } | Select-Object -First 20) }
                default { @($fixture.Record | Where-Object { $_.Category -eq 'group-2' -and $_.Enabled -eq 1 }) }
            }
            $fields = if ($case -like '*-projection') { 'Id','Name','Cpu' } else { 'Id','Name','Category','Enabled','Cpu','Payload','Revision' }
            Assert-BenchmarkRecord @($result.Response.Result.Records) @($expected) -Fields $fields
            @{ Block = $block; Warmup = ($block -eq 0); Shape = $shape; Case = $case; ClientMs = $result.ClientMs; HttpMs = $result.HttpMs; ParseMs = $result.ParseMs; Bytes = $result.ResponseBytes; HandlerMs = $result.Response.HandlerMs; Engine = $result.Response.Engine; PowerShell = $result.Response.PowerShell; Correct = $true } |
                ConvertTo-Json -Depth 7 -Compress | Add-Content "$output/endpoints.jsonl"
        }
    }
}
Write-Output 'Endpoint blocks checked.'
$fixture = @(New-BenchmarkFixture 1000 256)
$fixture | ConvertTo-Json -Depth 6 -Compress | Set-Content "$root/import-fixture.json"
$scripts = Invoke-RestMethod http://127.0.0.1:5100/api/v1/script -Headers $headers -MaximumRedirection 0
$scriptId = ($scripts | Where-Object name -eq 'Invoke-SqlServerImport.ps1').id
if (!$scriptId) { throw 'Import script unavailable' }
$EvidencePass | Export-Clixml "$output/identity-pass.clixml"
'identity' | Export-Clixml "$output/identity-method.clixml"
$identityBody=@{jobParameters=@(
    @{name='Pass';type='System.String';value=Get-Content "$output/identity-pass.clixml" -Raw;stringValue=$EvidencePass},
    @{name='Method';type='System.String';value=Get-Content "$output/identity-method.clixml" -Raw;stringValue='identity'}
)} | ConvertTo-Json -Depth 6 -Compress
$identityJob=Invoke-RestMethod "http://127.0.0.1:5100/api/v1/script/$scriptId" -Method Post -Headers $headers -ContentType application/json -Body $identityBody -MaximumRedirection 0
$identityStart=Get-Date
do {
    if (((Get-Date)-$identityStart).TotalSeconds -gt 30) { throw 'Identity job timed out' }
    Start-Sleep -Milliseconds 50
    $identityStatus=Invoke-RestMethod "http://127.0.0.1:5100/api/v1/job/$identityJob" -Headers $headers -MaximumRedirection 0
} while ($identityStatus.status -in 0,1)
if ($identityStatus.status -ne 2) { throw 'Identity job failed' }
$identityPipeline=Invoke-RestMethod "http://127.0.0.1:5100/api/v1/job/$identityJob/pipelineOutput" -Headers $headers -MaximumRedirection 0
if (@($identityPipeline).Count -ne 1) { throw 'Wrong identity job output count' }
@($identityPipeline)[0].data | Set-Content "$output/identity-job.clixml"
$jobIdentity=Import-Clixml "$output/identity-job.clixml" | ConvertFrom-Json
$jobIdentity | ConvertTo-Json -Depth 5 | Set-Content "$output/job-identity.json"
if ((Get-SqlServerAuthentication) -eq 'Sql' -and ($jobIdentity.authentication -ne 'SQL' -or $jobIdentity.sysadmin -ne 0)) { throw 'Job SQL identity did not match' }
$database = Get-SqlServerDatabaseName $EvidencePass n10000-p256
foreach ($block in 0..$Repetitions) {
    foreach ($entry in (@(@{Location='direct';Method='rows'},@{Location='direct';Method='rows-set'},@{Location='job';Method='rows'},@{Location='job';Method='rows-set'}) | Get-Random -Shuffle)) {
        $location=$entry.Location; $method=$entry.Method
        $EvidencePass | Export-Clixml "$output/job-parameter.clixml"
        $method | Export-Clixml "$output/method-parameter.clixml"
        $body = @{ jobParameters = @(@{ name = 'Pass'; type = 'System.String'; value = Get-Content "$output/job-parameter.clixml" -Raw; stringValue = $EvidencePass },@{ name = 'Method'; type = 'System.String'; value = Get-Content "$output/method-parameter.clixml" -Raw; stringValue = $method }) } | ConvertTo-Json -Depth 6 -Compress
        $timer = Get-Date
        if ($location -eq 'direct') {
            $result = & "$PSScriptRoot/Invoke-SqlServerImport.ps1" -Pass $EvidencePass -Method $method | ConvertFrom-Json
            $completedMs = ((Get-Date) - $timer).TotalMilliseconds
        } else {
            $acceptedId = Invoke-RestMethod "http://127.0.0.1:5100/api/v1/script/$scriptId" -Method Post -Headers $headers -ContentType application/json -Body $body -MaximumRedirection 0
            $job = @{ id = $acceptedId }
            do {
                if (((Get-Date) - $timer).TotalSeconds -gt 30) { throw 'Import job timeout' }
                Start-Sleep -Milliseconds 50
                $status = Invoke-RestMethod "http://127.0.0.1:5100/api/v1/job/$($job.id)" -Headers $headers -MaximumRedirection 0
            } while ($status.status -in 0,1)
            $completedMs = ((Get-Date) - $timer).TotalMilliseconds
            if ($status.status -ne 2) { throw "Import job status: $($status.status)" }
            $pipeline = Invoke-RestMethod "http://127.0.0.1:5100/api/v1/job/$($job.id)/pipelineOutput" -Headers $headers -MaximumRedirection 0
            if (@($pipeline).Count -ne 1) { throw 'Unexpected import pipeline count' }
            @($pipeline)[0].data | Set-Content "$output/job-result.clixml"
            $result = Import-Clixml "$output/job-result.clixml" | ConvertFrom-Json
        }
        $clientMs = ((Get-Date) - $timer).TotalMilliseconds
        if ($result.Affected -ne 1000) { throw 'Wrong reported import count' }
        $connection = Open-SqlServerDatabase $database
        try { $actual = @(Invoke-SqlServerSql $connection 'SELECT * FROM batch_records ORDER BY Id') } finally { $connection.Dispose() }
        Assert-BenchmarkRecord $actual @($fixture.Record)
        @{ Block = $block; Warmup = ($block -eq 0); Location = $location; Method = $method; CompletedMs = $completedMs; ClientMs = $clientMs; Result = $result; JobId = $(if ($location -eq 'job') { $job.id }); Correct = $true } |
            ConvertTo-Json -Depth 15 -Compress | Add-Content "$output/imports.jsonl"
    }
}
Write-Output 'Import blocks checked.'
} finally {
    Set-Content "$output/monitor-stop.txt" 'stop'
    $null = $monitor | Wait-Job -Timeout 5
    $monitor | Receive-Job
    $monitor | Stop-Job
    $monitor | Remove-Job
}
Write-Output "PSU endpoint/import evidence checked: $output"



