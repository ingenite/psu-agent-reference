# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Installs or restores two SQLite-only registrations in the dedicated dev-psu preview.
.PARAMETER Pass
Existing evidence directory to hold original files and installation hashes.
.PARAMETER Restore
Restores originals only if the active files still match the installed hashes.
.NOTES
Requires designated dev-psu vaulted API token. Copies benchmark scripts into its
preview repository; leaves unregistered script copies and job history after restore.
Never targets the synchronized PSU instance or PSU internal database.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]+$')][string] $Pass, [switch] $Restore)
$ErrorActionPreference = 'Stop'
$output = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
if (!(Test-Path "$output/metadata.json")) { throw 'Run the direct benchmark first' }
$repository = 'C:/dev-psu/Repository'
$backup = "$output/preview-backup"
$files = 'endpoints.ps1','scripts.ps1'
$token = Get-Secret -Name dev-psu-codex-mgmt-api -AsPlainText
$headers = @{ Authorization = "Bearer $token" }
$schema = Invoke-RestMethod http://127.0.0.1:5100/swagger/v1/swagger.json -Headers $headers -MaximumRedirection 0
if (!$schema.paths.'/api/v1/configuration/sync/{configurationFile}'.put) { throw 'Reload route unavailable' }
if ($Restore) {
    if (Test-Path "$backup/restored.txt") { throw 'Already restored' }
    $installed = Get-Content "$backup/installed.json" -Raw | ConvertFrom-Json
    foreach ($file in $files) {
        if ((Get-FileHash "$repository/.universal/$file").Hash -ne $installed.$file) { throw "Preview changed since installation: $file" }
    }
    foreach ($file in $files) { Copy-Item "$backup/$file" "$repository/.universal/$file" -Force }
} else {
    if (Test-Path $backup) { throw 'Backup exists; inspect or restore it first' }
    New-Item $backup -ItemType Directory | Out-Null
    New-Item "$repository/scripts/benchmarks/database" -ItemType Directory -Force | Out-Null
    foreach ($file in $files) { Copy-Item "$repository/.universal/$file" "$backup/$file" }
    Copy-Item "$PSScriptRoot/Sqlite.ps1","$PSScriptRoot/Invoke-SqliteEndpoint.ps1","$PSScriptRoot/Invoke-SqliteImport.ps1" "$repository/scripts/benchmarks/database" -Force
    Add-Content "$repository/.universal/endpoints.ps1" @'
New-PSUEndpoint -Url '/api/par-sqlite-benchmark' -Method POST -Environment Integrated -Authentication -Endpoint {
    & 'C:/dev-psu/Repository/scripts/benchmarks/database/Invoke-SqliteEndpoint.ps1' -RequestJson $Body
}
'@
    Add-Content "$repository/.universal/scripts.ps1" @'
New-PSUScript -Name 'Invoke-SqliteImport.ps1' -Path 'benchmarks/database/Invoke-SqliteImport.ps1' -Environment 'PowerShell 7' -MaxHistory 30
'@
    $hashes = @{}
    foreach ($file in $files) { $hashes[$file] = (Get-FileHash "$repository/.universal/$file").Hash }
    $hashes | ConvertTo-Json | Set-Content "$backup/installed.json"
}
foreach ($file in $files) {
    $null = Invoke-RestMethod "http://127.0.0.1:5100/api/v1/configuration/sync/$file" -Method Put -Headers $headers -MaximumRedirection 0
}
if ($Restore) {
    foreach ($file in $files) {
        if ((Get-FileHash "$backup/$file").Hash -ne (Get-FileHash "$repository/.universal/$file").Hash) { throw "Restore differs: $file" }
    }
    Set-Content "$backup/restored.txt" (Get-Date).ToUniversalTime().ToString('o')
}
Write-Output "SQLite preview updated; backup: $backup"
