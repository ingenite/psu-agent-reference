<#
.SYNOPSIS
Enables mixed authentication and creates the disposable local SQL benchmark login.
.PARAMETER Login
Disposable login name; choose another par_benchmark_ name when an older login
exists without its demonstration password. Existing logins are never changed.
.NOTES
Owner-authorized temporary SQL Server benchmark only. Uses the existing Windows
SQL administrator over TCP loopback. Creates the selected login with no server
role and a new generated demonstration password. Writes that password only to
C:/dev-psu/sqlserver-benchmark-password.txt, restricting access to the current
Windows identity and SYSTEM before the password is written. A failed setup removes
both files and the new login; a mixed-mode change is not reverted. A nonsecret companion login file makes the selected
identity available to PSU. Never copies the password into evidence. Fails if the login
or file exists. Each new benchmark database grants this login db_owner, analogous
to the PostgreSQL database owner; this is not a production least-privilege design.
If RestartRequired is true, restart MSSQLSERVER in an elevated Windows shell
before Get-SqlServerCondition. Leaves sa disabled and TCP settings unchanged.
Remove both temporary files after all SQL-authenticated measurements finish.
#>
param([ValidatePattern('^par_benchmark_[a-z0-9_]+$')][string] $Login = 'par_benchmark_sql')
. "$PSScriptRoot/SqlServer.ps1"
$path='C:/dev-psu/sqlserver-benchmark-password.txt'
if (Test-Path $path) { throw 'Inspect existing demonstration credential file' }
if (Test-Path C:/dev-psu/sqlserver-benchmark-login.txt) { throw 'Inspect existing demonstration login file' }
$admin=Open-SqlServerDatabase master -Administrative
$loginCreated=$false
$completed=$false
try {
    if (@(Invoke-SqlServerSql $admin "SELECT name FROM sys.server_principals WHERE name='$Login'").Count) { throw 'Benchmark login already exists' }
    $before=@(Invoke-SqlServerSql $admin "SELECT SERVERPROPERTY('IsIntegratedSecurityOnly') AS windows_only")[0].windows_only
    # Restrict the empty file before it ever holds the password.
    $null=New-Item $path -ItemType File
    $identity=(whoami).Trim()
    & icacls.exe $path /inheritance:r /grant:r "$($identity):(F)" 'SYSTEM:(F)' | Out-Null
    if ($LASTEXITCODE) { throw 'Demonstration file ACL failed' }
    if ($before -eq 1) {
        $null=Invoke-SqlServerSql $admin "EXEC master.dbo.xp_instance_regwrite N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\MSSQLServer',N'LoginMode',REG_DWORD,2"
    }
    $password='Par!'+(New-Guid).Guid+'A7'
    $escaped=$password.Replace("'","''")
    $null=Invoke-SqlServerSql $admin "CREATE LOGIN [$Login] WITH PASSWORD=N'$escaped',CHECK_POLICY=ON,CHECK_EXPIRATION=OFF,DEFAULT_DATABASE=master"
    $loginCreated=$true
    Set-Content $path $password -NoNewline
    Set-Content C:/dev-psu/sqlserver-benchmark-login.txt $Login -NoNewline
    @{
        Utc=(Get-Date).ToUniversalTime().ToString('o'); Login=$Login; OriginalWindowsOnly=$before; RestartRequired=($before -eq 1)
        LoginProperties=@(Invoke-SqlServerSql $admin "SELECT name,type_desc,is_disabled,is_policy_checked,is_expiration_checked FROM sys.sql_logins WHERE name IN ('$Login','sa')")
        ServerRoles=@(Invoke-SqlServerSql $admin "SELECT r.name AS role_name FROM sys.server_role_members m JOIN sys.server_principals r ON r.principal_id=m.role_principal_id JOIN sys.server_principals p ON p.principal_id=m.member_principal_id WHERE p.name='$Login'")
    } | ConvertTo-Json -Depth 8 | Set-Content C:/repos/psu-agent-reference/tools/output/database/sqlserver-login-setup.json
    $completed=$true
} finally {
    # Both files were absent at start, so a failed setup removes only what it created.
    if (!$completed) {
        Remove-Item $path,C:/dev-psu/sqlserver-benchmark-login.txt -ErrorAction SilentlyContinue
        if ($loginCreated) { $null=Invoke-SqlServerSql $admin "DROP LOGIN [$Login]" }
    }
    $admin.Dispose(); $password=$null; $escaped=$null
}
Write-Output 'Created disposable SQL login. See tools/output/database/sqlserver-login-setup.json for restart requirement; no credential is in evidence.'
