# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Creates dedicated synthetic SQLite databases and measures useful direct PowerShell operations.
.PARAMETER Pass
New evidence directory below tools/output/database. Never overwrites a pass or database.
.PARAMETER Repetitions
Measured shuffled blocks after one warm-up, for each of three fixture shapes.
.NOTES
Requires existing dev-psu bundled Microsoft.Data.Sqlite assemblies. No installation.
Deletes/reloads only dedicated batch tables in newly created benchmark files.
Timing/object assertions and source snapshots are retained; generated fixtures are outside timers.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]+$')][string] $Pass,
    [ValidateRange(1,15)][int] $Repetitions = 7, [int] $Seed = 1108)
. "$PSScriptRoot/Sqlite.ps1"
$output = Join-Path $PSScriptRoot "../../output/database/$Pass"
if (Test-Path $output) { throw "Pass exists: $Pass" }
New-Item "$output/source" -ItemType Directory -Force | Out-Null
Copy-Item "$PSScriptRoot/*.ps1" "$output/source"
@{ Utc = (Get-Date).ToUniversalTime().ToString('o'); Seed = $Seed; Repetitions = $Repetitions
    PowerShell = "$($PSVersionTable.PSVersion)"; OS = $PSVersionTable.OS; RuntimeConfiguration = (Get-Content "$PSHOME/pwsh.runtimeconfig.json" | ConvertFrom-Json).runtimeOptions
    Commit = git rev-parse HEAD; SourceHashes = @(Get-ChildItem "$output/source" -File | Get-FileHash | Select-Object Path,Hash)
    Connection = 'Pooling=False;Cache=Private;Default Timeout=5'; Pragmas = 'WAL; synchronous=FULL; cache_size=-8192; foreign_keys=ON; wal_autocheckpoint=1000'
} | ConvertTo-Json -Depth 8 | Set-Content "$output/metadata.json"
Get-Random -SetSeed $Seed | Out-Null
$monitor = Start-Job -FilePath "$PSScriptRoot/Watch-BenchmarkHost.ps1" -ArgumentList $output
try {
while (!(Test-Path "$output/monitor-ready.txt")) {
    if ($monitor.State -eq 'Failed') { $monitor | Receive-Job; throw 'Monitor failed' }
    Start-Sleep -Milliseconds 25
}
foreach ($shape in @(@(1000,256),@(10000,256),@(10000,2048))) {
    $count,$size = $shape
    $label = "n$count-p$size"
    $fixture = @(New-BenchmarkFixture -Count $count -PayloadSize $size -Seed $Seed)
    $database = Join-Path $output "$label.db"
    Initialize-BenchmarkDatabase -Path $database -Fixture $fixture
    $connection = Open-BenchmarkDatabase $database
    try {
        $diagnostics = [ordered]@{ Shape = $label; Database = $database; FixtureRows = $count; PayloadCharacters = $size
            Engine = Invoke-BenchmarkSql $connection 'SELECT sqlite_version() AS Version, sqlite_source_id() AS SourceId'
            Provider = [Microsoft.Data.Sqlite.SqliteConnection].Assembly.FullName
            CompileOptions = @(Invoke-BenchmarkSql $connection 'PRAGMA compile_options')
            Settings = @{}; Plans = @{}
        }
        foreach ($pragma in 'journal_mode','synchronous','page_size','cache_size','wal_autocheckpoint','foreign_keys','mmap_size') {
            $diagnostics.Settings[$pragma] = @(Invoke-BenchmarkSql $connection "PRAGMA $pragma")
        }
        $cases = 'row-key','document-key','row-filter','document-filter-scan','document-filter-index','row-offset','row-seek'
        foreach ($case in $cases) { $diagnostics.Plans[$case] = @(Invoke-BenchmarkSql $connection (('EXPLAIN QUERY PLAN ' + (Get-BenchmarkQuery $case $count)).Replace('@category', "'group-2'").Replace('@after', "$([int]($count / 2))").Replace('@id', "$([int]($count / 2))"))) }
        $expectedFilter = @($fixture.Record | Where-Object { $_.Category -eq 'group-2' -and $_.Enabled -eq 1 })
        foreach ($block in 0..$Repetitions) {
            $plan = @($cases | ForEach-Object { foreach ($mode in 'reuse','new') { [pscustomobject]@{ Case = $_; Mode = $mode } } }) | Get-Random -Shuffle
            foreach ($entry in $plan) {
                $parameters = @{ Path = $database; Case = $entry.Case; Count = $count }
                if ($entry.Mode -eq 'reuse') { $parameters.Connection = $connection }
                $result = Read-BenchmarkRecord @parameters
                $expected = switch -Wildcard ($entry.Case) {
                    '*-key' { @($fixture[[int]($count / 2) - 1].Record) }
                    'row-offset' { @($expectedFilter | Select-Object -Skip ([int]($count / 40)) -First 20) }
                    'row-seek' { @($expectedFilter | Where-Object Id -gt ($count / 2) | Select-Object -First 20) }
                    default { $expectedFilter }
                }
                Assert-BenchmarkRecord -Actual $result.Records -Expected @($expected)
                @{ Shape = $label; Block = $block; Warmup = ($block -eq 0); Case = $entry.Case; Mode = $entry.Mode; Metrics = $result.Metrics; Correct = $true } |
                    ConvertTo-Json -Depth 6 -Compress | Add-Content "$output/reads.jsonl"
            }
        }
        $batchFixture = @($fixture | Select-Object -First 100)
        foreach ($block in 0..$Repetitions) {
            foreach ($case in ('rows','documents','refresh-rows','refresh-documents','autocommit-rows' | Get-Random -Shuffle)) {
                $null = Invoke-BenchmarkSql $connection 'DELETE FROM batch_records; DELETE FROM batch_documents;'
                if ($case -eq 'refresh-rows') { $null = Write-BenchmarkBatch $connection $batchFixture rows batch_records }
                if ($case -eq 'refresh-documents') { $null = Write-BenchmarkBatch $connection $batchFixture documents batch_documents }
                $table = if ($case -like '*documents') { 'batch_documents' } else { 'batch_records' }
                $kind = if ($case -eq 'autocommit-rows') { 'rows' } else { $case }
                $result = Write-BenchmarkBatch $connection $batchFixture $kind $table -Autocommit:($case -eq 'autocommit-rows')
                $actual = @(Invoke-BenchmarkSql $connection "SELECT * FROM $table ORDER BY Id")
                if ($table -eq 'batch_documents') { $actual = @($actual | ForEach-Object { $_.Body | ConvertFrom-Json }) }
                $expected = @($batchFixture | ForEach-Object {
                    $record = $_.Record | Select-Object *
                    if ($case -like 'refresh-*') { $record.Revision = 1 }
                    $record
                })
                Assert-BenchmarkRecord $actual $expected
                if ($result.Affected -ne 100) { throw 'Wrong affected count' }
                @{ Shape = $label; Block = $block; Warmup = ($block -eq 0); Case = $case; Metrics = $result; Correct = $true } |
                    ConvertTo-Json -Depth 5 -Compress | Add-Content "$output/writes.jsonl"
            }
        }
        $diagnostics.Integrity = Invoke-BenchmarkSql $connection 'PRAGMA integrity_check'
        $diagnostics.Checkpoint = @(Invoke-BenchmarkSql $connection 'PRAGMA wal_checkpoint(TRUNCATE)')
        $diagnostics | ConvertTo-Json -Depth 15 | Set-Content "$output/$label-conditions.json"
    } finally { $connection.Dispose() }
    Get-Item $database | Select-Object Name,Length | ConvertTo-Json | Set-Content "$output/$label-storage.json"
    Write-Output "Completed $label; all results checked."
}
} finally {
    Set-Content "$output/monitor-stop.txt" (Get-Date).ToUniversalTime().ToString('o')
    $null = $monitor | Wait-Job -Timeout 5
    $monitor | Receive-Job
    $monitor | Stop-Job
    $monitor | Remove-Job
}
Write-Output "Evidence: $output"
