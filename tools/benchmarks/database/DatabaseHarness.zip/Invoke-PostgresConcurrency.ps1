# Experimental only.
<#
.SYNOPSIS
Measures gated one/four-reader, one/four-writer and mixed PostgreSQL bursts.
.PARAMETER Pass
Existing direct pass. Creates concurrency/ once.
.PARAMETER Iterations
Operations per warmed independent process; default 200, matching SQLite.
.NOTES
Each new worker checks ten operations of its assigned role before readiness.
The parent checks and resets warm-up increments before the gate. One excluded
burst block and three shuffled measured blocks follow. Connections are reused. Writers
share ten keys; readers query unchanged records in the same database. No retries.
Each burst wall interval counts once; per-request latencies are correlated.
Counts are checked for every operation and final fields/revisions after each burst.
#>
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]{1,24}$')][string] $Pass,
    [ValidateRange(10,1000)][int] $Iterations = 200)
. "$PSScriptRoot/Postgres.ps1"
. "$PSScriptRoot/DatabaseFixture.ps1"
$root = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
$output = "$root/concurrency"
if (Test-Path $output) { throw 'Concurrency pass exists' }
New-Item "$output/source" -ItemType Directory -Force | Out-Null
Copy-Item "$PSScriptRoot/*Postgres*.ps1","$PSScriptRoot/DatabaseFixture.ps1" "$output/source"
$database = Get-PostgresDatabaseName $Pass n10000-p256
$monitor = Start-Job -FilePath "$PSScriptRoot/Watch-PostgresHost.ps1" -ArgumentList $output
Get-Random -SetSeed 1108 | Out-Null
try {
while (!(Test-Path "$output/monitor-ready.txt")) {
    if ($monitor.State -eq 'Failed') { $monitor | Receive-Job; throw 'Monitor failed' }
    Start-Sleep -Milliseconds 25
}
$fixture = @(New-BenchmarkFixture 100 256)
$workerPath = "$PSScriptRoot/Invoke-PostgresWorker.ps1"
foreach ($block in 0..3) {
    foreach ($location in @('direct')) {
        $scenarios = @(@{ Roles = @('reader') }, @{ Roles = @('writer') }, @{ Roles = @('reader','reader','reader','reader') }, @{ Roles = @('reader','reader','reader','writer') }, @{ Roles = @('writer','writer','writer','writer') })
        foreach ($scenario in ($scenarios | Get-Random -Shuffle)) {
            $roles = $scenario.Roles
            $label = "$location-r$(@($roles | Where-Object {$_ -eq 'reader'}).Count)-w$(@($roles | Where-Object {$_ -eq 'writer'}).Count)-b$block"
            $directory = "$output/$label"
            New-Item $directory -ItemType Directory | Out-Null
            $connection = Open-PostgresDatabase $database
            try { $null = Invoke-PostgresSql $connection 'DELETE FROM batch_records'; $null = Write-PostgresBatch $connection $fixture rows batch_records } finally { $connection.Dispose() }
            $jobs = @()
            try {
                $jobs = @(for ($id = 0; $id -lt $roles.Count; $id++) {
                    $workerSettings = @{ Id = $id; Role = $roles[$id]; Location = $location; Pass = $Pass; Database = $database; Directory = $directory; Iterations = $Iterations }
                    Start-Job -ScriptBlock { param($path,$configuration); & $path -Settings $configuration } -ArgumentList $workerPath,$workerSettings
                })
                $readyTimer = Get-Date
                while (@(Get-ChildItem "$directory/ready-*.txt").Count -ne $roles.Count) {
                    if (((Get-Date) - $readyTimer).TotalSeconds -gt 30 -or @($jobs | Where-Object State -eq Failed).Count) { $jobs | Receive-Job; throw "Workers failed readiness: $label" }
                    Start-Sleep -Milliseconds 25
                }
                $warmupRevisions = 10 * 10 * @($roles | Where-Object { $_ -eq 'writer' }).Count
                $connection = Open-PostgresDatabase $database
                try {
                    $beforeReset = @(Invoke-PostgresSql $connection 'SELECT sum(Revision) AS Revisions FROM batch_records')[0].Revisions
                    if ($beforeReset -ne $warmupRevisions) { throw 'Warm-up revision total mismatch' }
                    $null = Invoke-PostgresSql $connection 'UPDATE batch_records SET Revision=0'
                    $afterReset = @(Invoke-PostgresSql $connection 'SELECT sum(Revision) AS Revisions FROM batch_records')[0].Revisions
                    if ($afterReset -ne 0) { throw 'Warm-up reset failed' }
                    @{ OperationsPerWorker=10; RoleSpecific=$true; AllWorkersReady=$true; BeforeReset=$beforeReset; AfterReset=$afterReset; Correct=$true } |
                        ConvertTo-Json -Compress | Set-Content "$directory/warmup-reset.json"
                } finally { $connection.Dispose() }
                # Rename a complete file so workers never read a partially written gate.
                Set-Content "$directory/gate.tmp" ((Get-Date).AddSeconds(1).ToUniversalTime().ToString('o'))
                Move-Item "$directory/gate.tmp" "$directory/gate.txt"
                $null = $jobs | Wait-Job -Timeout 45
                if (@($jobs | Where-Object State -ne Completed).Count) { throw "Workers did not complete: $label" }
                $workers = @($jobs | Receive-Job)
                $workers | ConvertTo-Json -Depth 10 -Compress | Set-Content "$directory/workers.json"
                foreach ($worker in $workers) {
                    if ($worker.Samples.Count -ne $Iterations -or @($worker.Samples | Where-Object Error).Count) { throw "Worker operation failed: $label" }
                    $expectedRows = if ($worker.Role -eq 'writer') { 10 } else { 20 }
                    if (@($worker.Samples | Where-Object Rows -ne $expectedRows).Count) { throw 'Wrong worker result size' }
                }
                $connection = Open-PostgresDatabase $database
                try {
                    $actual = @(Invoke-PostgresSql $connection 'SELECT * FROM batch_records ORDER BY Id')
                    $expected = @($fixture | ForEach-Object { $record = $_.Record | Select-Object *; if ($record.Id -le 10) { $record.Revision = $Iterations * @($roles | Where-Object {$_ -eq 'writer'}).Count }; $record })
                    Assert-BenchmarkRecord $actual $expected
                    $read = Read-PostgresRecord -Connection $connection -Case row-seek -Count 10000
                    $expectedRead = @(New-BenchmarkFixture 10000 256 | Where-Object { $_.Record.Category -eq 'group-2' -and $_.Record.Enabled -eq 1 -and $_.Record.Id -gt 5000 } | Select-Object -First 20)
                    Assert-BenchmarkRecord $read.Records @($expectedRead.Record)
                } finally { $connection.Dispose() }
                $start = ($workers.Started | ForEach-Object { Get-Date $_ } | Sort-Object | Select-Object -First 1)
                $end = ($workers.Ended | ForEach-Object { Get-Date $_ } | Sort-Object | Select-Object -Last 1)
                $latestStart = ($workers.Started | ForEach-Object { Get-Date $_ } | Sort-Object | Select-Object -Last 1)
                $earliestEnd = ($workers.Ended | ForEach-Object { Get-Date $_ } | Sort-Object | Select-Object -First 1)
                @{ Label = $label; Block = $block; Warmup = ($block -eq 0); Location = $location; Readers = @($roles | Where-Object {$_ -eq 'reader'}).Count; Writers = @($roles | Where-Object {$_ -eq 'writer'}).Count; Iterations = $Iterations; WallMs = ($end - $start).TotalMilliseconds; AllWorkersOverlapMs = ($earliestEnd - $latestStart).TotalMilliseconds; Operations = $Iterations * $roles.Count; Correct = $true; WorkersFile = "$label/workers.json" } |
                    ConvertTo-Json -Compress | Add-Content "$output/bursts.jsonl"
            } finally { $jobs | Stop-Job; $jobs | Remove-Job }
        }
    }
    Write-Output "Concurrency block $block checked."
}

} finally {
    Set-Content "$output/monitor-stop.txt" 'stop'
    $null = $monitor | Wait-Job -Timeout 5
    $monitor | Receive-Job
    $monitor | Stop-Job
    $monitor | Remove-Job
}
Write-Output "Concurrent PostgreSQL evidence checked: $output"
