# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Measures selected PSU reads/imports, synchronized short read/write bursts and an orchestration control.
.PARAMETER Pass
Existing direct evidence pass with the SQLite preview installed. Adds followup/ once.
.PARAMETER Repetitions
Measured blocks after one warm-up for sequential endpoints/imports. Bursts use three
measured blocks and one warm-up; control uses three alternating pairs.
.NOTES
Requires designated local API token. Concurrency uses independent pwsh processes;
ten assigned-role warm-ups precede readiness, followed by a verified revision reset
before the common gate. No tools or console output during blocks.
Resets only dedicated batch tables. Result checks run after clocks stop.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]+$')][string] $Pass,
    [ValidateRange(1,15)][int] $Repetitions = 7,
    [ValidateRange(10,1000)][int] $Iterations = 200)
. "$PSScriptRoot/Sqlite.ps1"
$root = "C:/repos/psu-agent-reference/tools/output/database/$Pass"
$output = "$root/followup"
if (Test-Path $output) { throw 'Follow-up exists' }
New-Item "$output/source" -ItemType Directory -Force | Out-Null
Copy-Item "$PSScriptRoot/*.ps1" "$output/source"
$monitor = Start-Job -FilePath "$PSScriptRoot/Watch-BenchmarkHost.ps1" -ArgumentList $output
try {
while (!(Test-Path "$output/monitor-ready.txt")) {
    if ($monitor.State -eq 'Failed') { $monitor | Receive-Job; throw 'Monitor failed' }
    Start-Sleep -Milliseconds 25
}
$token = Get-Secret -Name dev-psu-codex-mgmt-api -AsPlainText
$headers = @{ Authorization = "Bearer $token" }
$schema = Invoke-RestMethod http://127.0.0.1:5100/swagger/v1/swagger.json -Headers $headers -MaximumRedirection 0
if (!$schema.paths.'/api/v1/script/{id}'.post) { throw 'Job submission route unavailable' }
$schema.components.schemas.'PowerShellUniversal.JobContext' | ConvertTo-Json -Depth 15 | Set-Content "$output/job-context-schema.json"
$settingsResponse = Invoke-RestMethod http://127.0.0.1:5100/api/v1/settings -Headers $headers -MaximumRedirection 0
$settings = @($settingsResponse)[0]
@{ Utc = (Get-Date).ToUniversalTime().ToString('o'); Iterations = $Iterations; Repetitions = $Repetitions; Seed = 1108
    Protocol = 'review-corrected-v2'; WorkerWarmupOperations = 10
    Version = Invoke-RestMethod http://127.0.0.1:5100/api/v1/version -Headers $headers -MaximumRedirection 0
    Environments = Invoke-RestMethod http://127.0.0.1:5100/api/v1/environment -Headers $headers -MaximumRedirection 0
    Settings = $settings | Select-Object apiSecurityModel,concurrentJobLimit,maxJobMemory,logLevel,scriptBaseFolder,gitSyncEnabled
    PreviewHashes = @(Get-ChildItem C:/dev-psu/Repository/scripts/benchmarks/database -File | Get-FileHash | Select-Object Path,Hash)
} | ConvertTo-Json -Depth 15 | Set-Content "$output/metadata.json"
Get-Random -SetSeed 1108 | Out-Null
foreach ($shape in 'n1000-p256','n10000-p256','n10000-p2048') {
    $count = if ($shape -eq 'n1000-p256') { 1000 } else { 10000 }
    $size = if ($shape -eq 'n10000-p2048') { 2048 } else { 256 }
    $fixture = @(New-BenchmarkFixture $count $size)
    foreach ($block in 0..$Repetitions) {
        foreach ($case in ('row-key','document-key','row-seek','row-filter','document-filter-index' | Get-Random -Shuffle)) {
            $result = & "$PSScriptRoot/Invoke-SqliteClient.ps1" -Request @{ Pass = $Pass; Shape = $shape; Case = $case } -Headers $headers
            $expected = switch -Wildcard ($case) {
                '*-key' { @($fixture[[int]($count / 2) - 1].Record) }
                'row-seek' { @($fixture.Record | Where-Object { $_.Category -eq 'group-2' -and $_.Enabled -eq 1 -and $_.Id -gt ($count / 2) } | Select-Object -First 20) }
                default { @($fixture.Record | Where-Object { $_.Category -eq 'group-2' -and $_.Enabled -eq 1 }) }
            }
            Assert-BenchmarkRecord @($result.Response.Result.Records) @($expected)
            @{ Block = $block; Warmup = ($block -eq 0); Shape = $shape; Case = $case; ClientMs = $result.ClientMs; HttpMs = $result.HttpMs; ParseMs = $result.ParseMs; Bytes = $result.ResponseBytes; HandlerMs = $result.Response.HandlerMs; Metrics = $result.Response.Result.Metrics; Engine = $result.Response.Engine; PowerShell = $result.Response.PowerShell; Correct = $true } |
                ConvertTo-Json -Depth 7 -Compress | Add-Content "$output/endpoints.jsonl"
        }
    }
}
Write-Output 'Endpoint blocks checked.'
$fixture = @(New-BenchmarkFixture 1000 256)
$fixture | ConvertTo-Json -Depth 6 -Compress | Set-Content "$root/import-fixture.json"
$scripts = Invoke-RestMethod http://127.0.0.1:5100/api/v1/script -Headers $headers -MaximumRedirection 0
$scriptId = ($scripts | Where-Object name -eq 'Invoke-SqliteImport.ps1').id
if (!$scriptId) { throw 'Import script unavailable' }
$database = "$root/n10000-p256.db"
foreach ($block in 0..$Repetitions) {
    foreach ($location in ('direct','job' | Get-Random -Shuffle)) {
        $Pass | Export-Clixml "$output/job-parameter.clixml"
        $body = @{ jobParameters = @(@{ name = 'Pass'; type = 'System.String'; value = Get-Content "$output/job-parameter.clixml" -Raw; stringValue = $Pass }) } | ConvertTo-Json -Depth 6 -Compress
        $timer = [System.Diagnostics.Stopwatch]::StartNew()
        if ($location -eq 'direct') {
            $result = & "$PSScriptRoot/Invoke-SqliteImport.ps1" -Pass $Pass | ConvertFrom-Json
            $completedMs = $timer.Elapsed.TotalMilliseconds
        } else {
            $acceptedId = Invoke-RestMethod "http://127.0.0.1:5100/api/v1/script/$scriptId" -Method Post -Headers $headers -ContentType application/json -Body $body -MaximumRedirection 0
            $job = @{ id = $acceptedId }
            do {
                if ($timer.Elapsed.TotalSeconds -gt 30) { throw 'Import job timeout' }
                Start-Sleep -Milliseconds 50
                $status = Invoke-RestMethod "http://127.0.0.1:5100/api/v1/job/$($job.id)" -Headers $headers -MaximumRedirection 0
            } while ($status.status -in 0,1)
            $completedMs = $timer.Elapsed.TotalMilliseconds
            if ($status.status -ne 2) { throw "Import job status: $($status.status)" }
            $pipeline = Invoke-RestMethod "http://127.0.0.1:5100/api/v1/job/$($job.id)/pipelineOutput" -Headers $headers -MaximumRedirection 0
            if (@($pipeline).Count -ne 1) { throw 'Unexpected import pipeline count' }
            @($pipeline)[0].data | Set-Content "$output/job-result.clixml"
            $result = Import-Clixml "$output/job-result.clixml" | ConvertFrom-Json
        }
        $clientMs = $timer.Elapsed.TotalMilliseconds
        if ($result.Metrics.Affected -ne 1000) { throw 'Wrong reported import count' }
        $connection = Open-BenchmarkDatabase $database
        try { $actual = @(Invoke-BenchmarkSql $connection 'SELECT * FROM batch_records ORDER BY Id') } finally { $connection.Dispose() }
        Assert-BenchmarkRecord $actual @($fixture.Record)
        @{ Block = $block; Warmup = ($block -eq 0); Location = $location; CompletedMs = $completedMs; ClientMs = $clientMs; Result = $result; JobId = $(if ($location -eq 'job') { $job.id }); Correct = $true } |
            ConvertTo-Json -Depth 15 -Compress | Add-Content "$output/imports.jsonl"
    }
}
Write-Output 'Import blocks checked.'
$fixture = @(New-BenchmarkFixture 100 256)
$workerPath = "$PSScriptRoot/Invoke-SqliteWorker.ps1"
foreach ($block in 0..3) {
    foreach ($location in ('direct','endpoint' | Get-Random -Shuffle)) {
        $scenarios = @(@{ Roles = @('reader') }, @{ Roles = @('writer') }, @{ Roles = @('reader','reader','reader','reader') }, @{ Roles = @('reader','reader','reader','writer') }, @{ Roles = @('writer','writer','writer','writer') })
        foreach ($scenario in ($scenarios | Get-Random -Shuffle)) {
            $roles = $scenario.Roles
            $label = "$location-r$(@($roles | Where-Object {$_ -eq 'reader'}).Count)-w$(@($roles | Where-Object {$_ -eq 'writer'}).Count)-b$block"
            $directory = "$output/$label"
            New-Item $directory -ItemType Directory | Out-Null
            $connection = Open-BenchmarkDatabase $database
            try { $null = Invoke-BenchmarkSql $connection 'DELETE FROM batch_records'; $null = Write-BenchmarkBatch $connection $fixture rows batch_records } finally { $connection.Dispose() }
            $jobs = @()
            try {
                $jobs = @(for ($id = 0; $id -lt $roles.Count; $id++) {
                    $workerSettings = @{ Id = $id; Role = $roles[$id]; Location = $location; Pass = $Pass; Database = $database; Directory = $directory; Iterations = $Iterations; Headers = $headers }
                    Start-Job -ScriptBlock { param($path,$configuration); & $path -Settings $configuration } -ArgumentList $workerPath,$workerSettings
                })
                $readyTimer = [System.Diagnostics.Stopwatch]::StartNew()
                while (@(Get-ChildItem "$directory/ready-*.txt").Count -ne $roles.Count) {
                    if ($readyTimer.Elapsed.TotalSeconds -gt 30 -or @($jobs | Where-Object State -eq Failed).Count) { $jobs | Receive-Job; throw "Workers failed readiness: $label" }
                    Start-Sleep -Milliseconds 25
                }
                $warmupRevisions = 10 * 10 * @($roles | Where-Object { $_ -eq 'writer' }).Count
                $connection = Open-BenchmarkDatabase $database
                try {
                    $beforeReset = @(Invoke-BenchmarkSql $connection 'SELECT sum(Revision) AS Revisions FROM batch_records')[0].Revisions
                    if ($beforeReset -ne $warmupRevisions) { throw 'Warm-up revision total mismatch' }
                    $null = Invoke-BenchmarkSql $connection 'UPDATE batch_records SET Revision=0'
                    $afterReset = @(Invoke-BenchmarkSql $connection 'SELECT sum(Revision) AS Revisions FROM batch_records')[0].Revisions
                    if ($afterReset -ne 0) { throw 'Warm-up reset failed' }
                    @{ OperationsPerWorker=10; RoleSpecific=$true; AllWorkersReady=$true; BeforeReset=$beforeReset; AfterReset=$afterReset; Correct=$true } |
                        ConvertTo-Json -Compress | Set-Content "$directory/warmup-reset.json"
                } finally { $connection.Dispose() }
                # Rename a complete file so workers never read a partially written gate.
                Set-Content "$directory/gate.tmp" ((Get-Date).AddSeconds(1).ToUniversalTime().ToString('o'))
                Move-Item "$directory/gate.tmp" "$directory/gate.txt"
                $null = $jobs | Wait-Job -Timeout 45
                if (@($jobs | Where-Object State -ne Completed).Count) { throw "Workers did not complete: $label" }
                $workers = @($jobs | Receive-Job)
                $workers | ConvertTo-Json -Depth 10 -Compress | Set-Content "$directory/workers.json"
                foreach ($worker in $workers) {
                    if ($worker.Samples.Count -ne $Iterations -or @($worker.Samples | Where-Object Error).Count) { throw "Worker operation failed: $label" }
                    $expectedRows = if ($worker.Role -eq 'writer') { 10 } else { 20 }
                    if (@($worker.Samples | Where-Object Rows -ne $expectedRows).Count) { throw 'Wrong worker result size' }
                }
                $connection = Open-BenchmarkDatabase $database
                try {
                    $actual = @(Invoke-BenchmarkSql $connection 'SELECT * FROM batch_records ORDER BY Id')
                    $expected = @($fixture | ForEach-Object { $record = $_.Record | Select-Object *; if ($record.Id -le 10) { $record.Revision = $Iterations * @($roles | Where-Object {$_ -eq 'writer'}).Count }; $record })
                    Assert-BenchmarkRecord $actual $expected
                    $read = Read-BenchmarkRecord -Connection $connection -Case row-seek -Count 10000 -SkipSerialization
                    $expectedRead = @(New-BenchmarkFixture 10000 256 | Where-Object { $_.Record.Category -eq 'group-2' -and $_.Record.Enabled -eq 1 -and $_.Record.Id -gt 5000 } | Select-Object -First 20)
                    Assert-BenchmarkRecord $read.Records @($expectedRead.Record)
                } finally { $connection.Dispose() }
                $start = ($workers.Started | ForEach-Object { Get-Date $_ } | Sort-Object | Select-Object -First 1)
                $end = ($workers.Ended | ForEach-Object { Get-Date $_ } | Sort-Object | Select-Object -Last 1)
                $latestStart = ($workers.Started | ForEach-Object { Get-Date $_ } | Sort-Object | Select-Object -Last 1)
                $earliestEnd = ($workers.Ended | ForEach-Object { Get-Date $_ } | Sort-Object | Select-Object -First 1)
                @{ Label = $label; Block = $block; Warmup = ($block -eq 0); Location = $location; Readers = @($roles | Where-Object {$_ -eq 'reader'}).Count; Writers = @($roles | Where-Object {$_ -eq 'writer'}).Count; Iterations = $Iterations; WallMs = ($end - $start).TotalMilliseconds; AllWorkersOverlapMs = ($earliestEnd - $latestStart).TotalMilliseconds; Operations = $Iterations * $roles.Count; Correct = $true; WorkersFile = "$label/workers.json" } |
                    ConvertTo-Json -Compress | Add-Content "$output/bursts.jsonl"
            } finally { $jobs | Stop-Job; $jobs | Remove-Job }
        }
    }
    Write-Output "Concurrency block $block checked."
}

Write-Output 'Starting orchestration control.'
$connection = Open-BenchmarkDatabase $database
try {
    foreach ($block in 1..3) {
        # Alternate order to expose drift. Activity mimics small tool-side reads and JSON handling.
        $conditions = if ($block % 2) { 'quiet','activity' } else { 'activity','quiet' }
        foreach ($condition in $conditions) {
            $activity = $null
            $activityDirectory = "$output/control-$block-$condition"
            New-Item $activityDirectory -ItemType Directory | Out-Null
            try {
                if ($condition -eq 'activity') {
                    $activity = Start-Job -ScriptBlock {
                        param($directory,$source)
                        Set-Content "$directory/ready.txt" $PID
                        $cycles = 0
                        while (!(Test-Path "$directory/stop.txt")) {
                            $null = Get-Content $source -Raw
                            $null = 1..100 | ForEach-Object { [pscustomobject]@{ Id = $_; Value = 'synthetic-control' } } | ConvertTo-Json -Compress
                            $cycles++
                            Start-Sleep -Milliseconds 20
                        }
                        $cycles
                    } -ArgumentList $activityDirectory,"$PSScriptRoot/Sqlite.ps1"
                    $readyTimer = [System.Diagnostics.Stopwatch]::StartNew()
                    while (!(Test-Path "$activityDirectory/ready.txt")) {
                        if ($readyTimer.Elapsed.TotalSeconds -gt 15) { throw 'Activity control timeout' }
                        Start-Sleep -Milliseconds 25
                    }
                }
                $null = Read-BenchmarkRecord -Connection $connection -Case row-filter -Count 10000 -SkipSerialization
                $timer = [System.Diagnostics.Stopwatch]::StartNew()
                $times = @(for ($i = 0; $i -lt 100; $i++) {
                    $result = Read-BenchmarkRecord -Connection $connection -Case row-filter -Count 10000 -SkipSerialization
                    $result.Metrics.TotalMs
                })
                $wallMs = $timer.Elapsed.TotalMilliseconds
                $expected = @(New-BenchmarkFixture 10000 256 | Where-Object { $_.Record.Category -eq 'group-2' -and $_.Record.Enabled -eq 1 })
                Assert-BenchmarkRecord $result.Records @($expected.Record)
                $cycles = 0
                if ($activity) {
                    Set-Content "$activityDirectory/stop.txt" 'stop'
                    $null = $activity | Wait-Job -Timeout 5
                    $cycles = [int]($activity | Receive-Job)
                }
                @{ Block = $block; Condition = $condition; Operations = 100; WallMs = $wallMs; TotalMs = $times; ActivityCycles = $cycles; Correct = $true } |
                    ConvertTo-Json -Depth 5 -Compress | Add-Content "$output/control.jsonl"
            } finally { if ($activity) { $activity | Stop-Job; $activity | Remove-Job } }
        }
    }
} finally { $connection.Dispose() }
} finally {
    Set-Content "$output/monitor-stop.txt" (Get-Date).ToUniversalTime().ToString('o')
    $null = $monitor | Wait-Job -Timeout 5
    $monitor | Receive-Job
    $monitor | Stop-Job
    $monitor | Remove-Job
}
Write-Output "Follow-up evidence checked: $output"
