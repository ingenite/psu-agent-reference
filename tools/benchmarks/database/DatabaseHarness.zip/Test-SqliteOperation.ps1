# Experimental only; not reference material for creating production PSU resources.
<#
.SYNOPSIS
Checks SQLite operational behavior in a new diagnostic file, outside performance workloads.
.PARAMETER Pass
Existing evidence pass. Creates operations/ once, including diagnostic and backup databases.
.NOTES
Checks a held writer/timeout, WAL reader snapshot/checkpoint, explicit rollback,
database-aware backup, reopen and integrity. Does not simulate power loss or crashes.
#>
param([Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9-]+$')][string] $Pass)
. "$PSScriptRoot/Sqlite.ps1"
$output = "C:/repos/psu-agent-reference/tools/output/database/$Pass/operations"
if (Test-Path $output) { throw 'Operations directory exists' }
New-Item "$output/source" -ItemType Directory -Force | Out-Null
Copy-Item "$PSScriptRoot/*.ps1" "$output/source"
$fixture = @(New-BenchmarkFixture 1000 256)
$database = "$output/diagnostic.db"
Initialize-BenchmarkDatabase $database $fixture
$readerConnection = Open-BenchmarkDatabase $database
$writerConnection = Open-BenchmarkDatabase $database
$results = [ordered]@{}
try {
    $null = Write-BenchmarkBatch $writerConnection $fixture rows batch_records
    $null = Invoke-BenchmarkSql $writerConnection 'PRAGMA wal_checkpoint(TRUNCATE)'
    $before = Invoke-BenchmarkSql $readerConnection 'BEGIN; SELECT sum(Revision) AS Revisions FROM batch_records'
    $null = Invoke-BenchmarkIncrement $writerConnection
    $during = Invoke-BenchmarkSql $readerConnection 'SELECT sum(Revision) AS Revisions FROM batch_records'
    $checkpointDuring = Invoke-BenchmarkSql $writerConnection 'PRAGMA wal_checkpoint(PASSIVE)'
    $null = Invoke-BenchmarkSql $readerConnection 'COMMIT'
    $after = Invoke-BenchmarkSql $readerConnection 'SELECT sum(Revision) AS Revisions FROM batch_records'
    $checkpointAfter = Invoke-BenchmarkSql $writerConnection 'PRAGMA wal_checkpoint(TRUNCATE)'
    if ($before.Revisions -ne 0 -or $during.Revisions -ne 0 -or $after.Revisions -ne 10 -or $checkpointDuring.log -le $checkpointDuring.checkpointed) { throw 'WAL snapshot/checkpoint check failed' }
    $results.Snapshot = @{ Before = $before; During = $during; After = $after; CheckpointDuring = $checkpointDuring; CheckpointAfter = $checkpointAfter; Correct = $true }
    $held = $writerConnection.BeginTransaction()
    try {
        $readerConnection.DefaultTimeout = 1
        $timer = [System.Diagnostics.Stopwatch]::StartNew()
        $code = $null
        try { $unexpected = $readerConnection.BeginTransaction(); $unexpected.Dispose(); throw 'Expected lock timeout' }
        catch { $code = $_.Exception.InnerException.SqliteErrorCode; $message = $_.Exception.Message }
        $waitMs = $timer.Elapsed.TotalMilliseconds
        if ($code -ne 5) { throw "Unexpected busy result: $message" }
        $results.WriteLock = @{ TimeoutSeconds = 1; WaitMs = $waitMs; SqliteErrorCode = $code; Message = $message; Correct = $true }
    } finally { $held.Rollback(); $held.Dispose() }
    $transaction = $writerConnection.BeginTransaction()
    $command = $writerConnection.CreateCommand()
    try {
        $command.Transaction = $transaction
        $command.CommandText = 'UPDATE batch_records SET Revision=Revision+1000 WHERE Id=1'
        $null = $command.ExecuteNonQuery()
        $transaction.Rollback()
    } finally { $command.Dispose(); $transaction.Dispose() }
    $revision = Invoke-BenchmarkSql $writerConnection 'SELECT sum(Revision) AS Revisions FROM batch_records'
    if ($revision.Revisions -ne 10) { throw 'Rollback failed' }
    $results.Rollback = @{ Revisions = $revision.Revisions; Correct = $true }
    $command = $writerConnection.CreateCommand()
    $backup = "$output/backup.db"
    try {
        $command.CommandText = 'VACUUM INTO @path'
        $null = $command.Parameters.AddWithValue('@path', $backup)
        $timer = [System.Diagnostics.Stopwatch]::StartNew()
        $null = $command.ExecuteNonQuery()
        $backupMs = $timer.Elapsed.TotalMilliseconds
    } finally { $command.Dispose() }
    $results.Backup = @{ Path = $backup; ElapsedMs = $backupMs }
} finally { $readerConnection.Dispose(); $writerConnection.Dispose() }
foreach ($path in $database,$backup) {
    $connection = Open-BenchmarkDatabase $path
    try {
        $integrity = Invoke-BenchmarkSql $connection 'PRAGMA integrity_check'
        if ($integrity.integrity_check -ne 'ok') { throw 'Integrity check failed' }
        Assert-BenchmarkRecord @(Invoke-BenchmarkSql $connection 'SELECT * FROM records ORDER BY Id') @($fixture.Record)
        $documents = @(Invoke-BenchmarkSql $connection 'SELECT Body FROM documents ORDER BY Id' | ForEach-Object { $_.Body | ConvertFrom-Json })
        Assert-BenchmarkRecord $documents @($fixture.Record)
        $revision = Invoke-BenchmarkSql $connection 'SELECT sum(Revision) AS Revisions FROM batch_records'
        if ($revision.Revisions -ne 10) { throw 'Reopen/backup revision mismatch' }
        $results[$(if ($path -eq $database) { 'Reopen' } else { 'BackupVerification' })] = @{ Integrity = 'ok'; Rows = $fixture.Count; Documents = $documents.Count; Revisions = $revision.Revisions; Correct = $true }
    } finally { $connection.Dispose() }
}
$results.Files = @(Get-ChildItem $output -File | Select-Object Name,Length)
$results | ConvertTo-Json -Depth 10 | Set-Content "$output/checks.json"
Write-Output "Operational checks passed: $output/checks.json"
